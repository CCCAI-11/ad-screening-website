# 📱 移动端调试工具 - 快速参考

## 🚀 快速启用

### 自动启用环境
- ✅ `localhost`
- ✅ `127.0.0.1`
- ✅ `192.168.x.x`
- ✅ `10.0.x.x`
- ✅ URL 包含 `?debug=true`

### 手动启用
```
https://your-domain.com?debug=true
```

---

## 🎯 四大功能

### 1️⃣ vConsole（移动端控制台）
- 📊 System - 系统信息
- 🌐 Network - 网络请求
- 🔍 Element - DOM 查看
- 💾 Storage - 存储查看
- 🌍 环境 - 环境信息

**使用**: 点击右下角绿色按钮

### 2️⃣ 错误面板
- 🐛 页面顶部显示错误
- 📄 显示文件位置
- 📚 显示堆栈信息
- 🔄 自动捕获错误

**清除**: `window.MobileDebug.clearErrors()`

### 3️⃣ 环境检测
- 📱 移动端检测
- 🌐 浏览器识别
- 💻 操作系统版本
- ✅ 25+ API 支持检测

**查看**: `window.MobileDebug.getEnvInfo()`

### 4️⃣ 网络监控
- 🌐 Fetch 监控
- 📡 XHR 监控
- ⏱️ 响应时间
- ❌ 错误捕获

**查看**: `window.MobileDebug.getRequests()`

---

## 💻 常用命令

```javascript
// 获取环境信息
window.MobileDebug.getEnvInfo()

// 获取网络请求
window.MobileDebug.getRequests()

// 清除错误
window.MobileDebug.clearErrors()

// 清除请求记录
window.MobileDebug.clearRequests()

// 查看配置
window.MobileDebug.config
```

---

## 🔧 配置文件

**位置**: `public/mobile-debug.js`

```javascript
const CONFIG = {
  enableVConsole: true,        // vConsole
  enableErrorPanel: true,      // 错误面板
  enableEnvDetection: true,    // 环境检测
  enableNetworkMonitor: true,  // 网络监控
  maxErrors: 10,               // 最大错误数
};
```

---

## 📊 支持的浏览器

### 完全支持
- ✅ iOS Safari 10+
- ✅ Android Chrome 61+
- ✅ 微信浏览器 7.0+
- ✅ QQ浏览器 10.0+
- ✅ UC浏览器 12.0+

### 检测的浏览器
- 微信浏览器
- QQ浏览器
- UC浏览器
- 夸克浏览器
- 华为浏览器
- 小米浏览器
- OPPO浏览器
- vivo浏览器
- Safari
- Chrome
- Firefox

---

## 🔍 检测的 API（25+）

### 存储
- localStorage
- sessionStorage
- IndexedDB

### 网络
- fetch
- WebSocket
- WebRTC

### 多媒体
- WebGL
- SpeechSynthesis
- SpeechRecognition

### 设备
- Geolocation
- Vibration
- Battery
- DeviceOrientation
- DeviceMotion

### 事件
- TouchEvents
- PointerEvents

### 观察者
- IntersectionObserver
- MutationObserver
- ResizeObserver
- PerformanceObserver

### 其他
- Promise
- ServiceWorker
- WebWorker
- Notification

---

## 🐛 故障排查

### vConsole 没显示？
1. ✅ 确认是移动端
2. ✅ 确认是开发环境
3. ✅ 添加 `?debug=true`
4. ✅ 检查网络连接

### 错误面板没显示？
1. ✅ 触发一个错误测试
2. ✅ 刷新页面
3. ✅ 检查配置

### 网络请求没监控？
1. ✅ 确保脚本先加载
2. ✅ 检查配置
3. ✅ 查看 vConsole Network

---

## 📱 使用场景

### 调试布局
1. 打开 vConsole
2. 切换到 Element
3. 查看 DOM 和样式

### 调试错误
1. 查看顶部错误面板
2. 展开堆栈信息
3. 在 Console 查看日志

### 检查兼容性
1. 打开 vConsole
2. 切换到"环境"
3. 查看 API 支持

### 调试网络
1. 打开 vConsole
2. 切换到 Network
3. 查看请求详情

---

## 💡 快速技巧

### 导出环境信息
```javascript
const info = window.MobileDebug.getEnvInfo();
console.log(JSON.stringify(info, null, 2));
```

### 过滤 API 请求
```javascript
const requests = window.MobileDebug.getRequests();
const apiRequests = requests.filter(r => 
  r.url.includes('/api/')
);
console.table(apiRequests);
```

### 统计请求时间
```javascript
const requests = window.MobileDebug.getRequests();
const avgTime = requests.reduce((sum, r) => 
  sum + r.duration, 0
) / requests.length;
console.log(`平均响应时间: ${avgTime}ms`);
```

---

## 🔒 安全提示

- ⚠️ 不要在生产环境默认启用
- ⚠️ 使用条件加载
- ⚠️ 清理敏感信息
- ✅ 仅在需要时启用

---

## 📚 文档

- **完整文档**: `MOBILE_DEBUG_GUIDE.md`
- **源代码**: `public/mobile-debug.js`
- **集成位置**: `index.html`

---

## 📞 问题反馈

提供以下信息：
1. 设备型号和系统版本
2. 浏览器类型和版本
3. `window.MobileDebug.getEnvInfo()` 输出
4. 错误截图和控制台日志

---

**版本**: v1.0  
**状态**: ✅ 已集成  
**更新**: 2026-02-06

#!/bin/bash

# 手机访问本地开发服务器启动脚本

echo "================================================"
echo "  老年痴呆早期筛查网站 - 本地开发服务器"
echo "================================================"
echo ""

# 检查Node.js是否安装
if ! command -v node &> /dev/null; then
    echo "❌ 错误：未检测到Node.js"
    echo "请先安装Node.js: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js版本: $(node -v)"
echo ""

# 检查依赖是否安装
if [ ! -d "node_modules" ]; then
    echo "📦 正在安装依赖..."
    npm install
    echo ""
fi

# 获取本机IP地址
echo "🔍 正在获取本机IP地址..."
echo ""

if [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac系统
    IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -n 1)
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux系统
    IP=$(hostname -I | awk '{print $1}')
else
    # Windows系统（Git Bash）
    IP=$(ipconfig | grep "IPv4" | awk '{print $NF}' | head -n 1)
fi

echo "📍 本机IP地址: $IP"
echo ""
echo "================================================"
echo "  手机访问地址"
echo "================================================"
echo ""
echo "  http://$IP:3000"
echo ""
echo "================================================"
echo ""
echo "⚠️  重要提示："
echo "  1. 确保手机和电脑连接在同一个Wi-Fi网络"
echo "  2. 在手机浏览器中输入上面的地址"
echo "  3. 如果无法访问，请检查防火墙设置"
echo ""
echo "🚀 正在启动开发服务器..."
echo ""

# 启动Vite开发服务器
npx vite --host 0.0.0.0 --port 3000

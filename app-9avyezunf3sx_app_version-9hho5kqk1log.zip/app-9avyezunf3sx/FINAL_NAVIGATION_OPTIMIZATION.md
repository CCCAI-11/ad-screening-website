# 预筛选导航优化与数据保存固化功能说明

## 功能概述

对预筛选问卷页面的导航体验进行最终优化，并固化基本信息的永久保存逻辑，确保用户信息作为长期有效的个人档案持久化存储。

## 功能特性

### 一、预筛选问卷页面导航优化

#### 1. 返回首页按钮显示规则

**显示条件**：
- ✅ **仅在第一题页面显示**（currentQuestionIndex === 0）
- ❌ **第二题及之后不显示**（currentQuestionIndex > 0）

**原因**：
- 第一题是预筛选的入口，用户可能需要返回首页
- 第二题及之后，用户已经开始答题，应该专注于完成问卷
- 如果需要退出，可以使用"上一题"按钮返回第一题，再点击"返回首页"

#### 2. 按钮位置与布局

**第一题页面**：
```
┌─────────────────────────────────────────────┐
│                                             │
│  [返回首页]              [下一题 →]         │
│   (outline)              (primary)          │
│                                             │
└─────────────────────────────────────────────┘
```

**第二题及之后**：
```
┌─────────────────────────────────────────────┐
│                                             │
│  [← 上一题]              [下一题 →]         │
│   (outline)              (primary)          │
│                                             │
└─────────────────────────────────────────────┘
```

**布局特点**：
- 两个按钮在同一行
- 使用`flex items-center justify-between gap-4`布局
- "返回首页"按钮位于左侧
- "下一题"按钮位于右侧
- 间距：gap-4

#### 3. 视觉样式统一

**按钮尺寸**：
- 高度：size="lg"
- 内边距：px-8 py-6
- 字号：text-lg
- 图标大小：h-5 w-5
- 间距：gap-2

**样式区分**：
- **返回首页按钮**：variant="outline"（次要按钮，边框样式）
- **下一题按钮**：默认primary样式（主要按钮，填充样式）

**视觉对比**：
| 按钮 | 变体 | 背景 | 边框 | 文字颜色 | 用途 |
|------|------|------|------|----------|------|
| 返回首页 | outline | 透明 | 有边框 | 前景色 | 次要操作 |
| 下一题 | default | 主题色 | 无边框 | 白色 | 主要操作 |

#### 4. 功能逻辑

**返回首页按钮**：
- 点击后跳转到首页（路径：/）
- 使用`navigate('/')`
- 不影响答题进度（已通过ScreeningContext自动保存）
- 用户可以稍后返回继续答题

**条件渲染逻辑**：
```typescript
{currentQuestionIndex === 0 ? (
  // 第一题：显示"返回首页"按钮
  <Button variant="outline" onClick={() => navigate('/')}>
    返回首页
  </Button>
) : currentQuestionIndex > 0 ? (
  // 第二题及之后：显示"上一题"按钮
  <Button variant="outline" onClick={handlePrevious}>
    上一题
  </Button>
) : (
  // 占位符（理论上不会执行）
  <div className="w-32"></div>
)}
```

### 二、基本信息永久保存逻辑固化

#### 1. 永久保存机制

**核心原则**：
- 用户提交的基本信息视为长期有效的个人档案
- 一经建立，除非用户主动修改，否则一直保留
- 不受完成预筛选或其他操作的影响

**存储键名**：
- `user_profile`（永久档案）

**存储内容**：
```json
{
  "gender": "male",
  "ageRange": "60-69",
  "province": "北京市",
  "city": "北京市",
  "lastUpdated": "2026-02-05T10:30:00.000Z"
}
```

**保存时机**：
- 用户点击"提交并继续"按钮时
- 验证通过后立即保存

**保存代码**：
```typescript
// 保存到永久档案（user_profile）
const profileData = {
  ...userInfo,
  lastUpdated: new Date().toISOString()
};
localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profileData));
console.log('用户档案已保存:', profileData);
```

#### 2. 自动回填机制

**加载时机**：
- 页面加载时（useEffect钩子）
- 无论通过任何路径进入

**加载优先级**：
1. **优先检查永久档案**（user_profile）
2. 如果不存在，则检查自动草稿（user_info_draft）

**加载代码**：
```typescript
useEffect(() => {
  try {
    // 优先检查永久档案
    const profileData = localStorage.getItem(USER_PROFILE_KEY);
    if (profileData) {
      const parsed = JSON.parse(profileData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已加载永久档案:', parsed);
      return; // 找到永久档案后直接返回
    }

    // 如果没有永久档案，则尝试加载草稿数据
    const draftData = localStorage.getItem(USER_INFO_DRAFT_KEY);
    if (draftData) {
      const parsed = JSON.parse(draftData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已恢复草稿数据:', parsed);
    }
  } catch (error) {
    console.error('恢复数据失败:', error);
  }
}, []);
```

**回填效果**：
- 所有表单字段自动填充
- 性别单选按钮自动选中
- 年龄区间下拉框自动选中
- 省份下拉框自动选中
- 城市下拉框自动选中

#### 3. 状态维持机制

**永久保留**：
- ✅ 提交后不清空user_profile
- ✅ 完成预筛选后不清空user_profile
- ✅ 完成量表后不清空user_profile
- ✅ 查看报告后不清空user_profile
- ✅ 关闭浏览器后不清空user_profile

**清空时机**：
- ❌ 永不自动清空
- ✅ 仅当用户主动修改并重新提交时更新

**数据隔离**：
- 永久档案（user_profile）：长期有效
- 自动草稿（user_info_draft）：提交后清空
- 兼容数据（user_info）：与永久档案同步

**清空草稿代码**：
```typescript
// 清空草稿数据（永久档案不清空）
localStorage.removeItem(USER_INFO_DRAFT_KEY);
console.log('草稿数据已清空');
```

**注意**：
- 代码中**没有**`localStorage.removeItem(USER_PROFILE_KEY)`
- 永久档案**永不**被自动清空

#### 4. 页面状态说明

**首次访问**：
- localStorage中无user_profile
- 表单为空
- 页面状态：新建档案

**填写中途离开**：
- localStorage中有user_info_draft
- 再次进入时自动恢复草稿
- 页面状态：继续填写

**提交后再次访问**：
- localStorage中有user_profile
- 自动填充所有字段
- 页面状态：查看/编辑个人资料

**修改档案**：
- 用户可以修改任何字段
- 修改时自动保存草稿
- 点击"提交并继续"更新永久档案
- lastUpdated时间戳更新

## 技术实现

### 文件修改
1. `src/pages/PreScreeningQuestionPage.tsx` - 预筛选问卷页面
2. `src/pages/UserInfoPage.tsx` - 基本信息页面（已在Step 49完成）

### 核心代码

#### 1. 预筛选页面导航按钮（PreScreeningQuestionPage.tsx）

```typescript
{/* 导航按钮 */}
<div className="flex items-center justify-between gap-4">
  {/* 左侧按钮：第一题显示"返回首页"，其他题显示"上一题"或占位符 */}
  {currentQuestionIndex === 0 ? (
    <Button
      type="button"
      variant="outline"
      size="lg"
      onClick={() => navigate('/')}
      className="gap-2 text-lg px-8 py-6"
    >
      <Home className="h-5 w-5" />
      返回首页
    </Button>
  ) : currentQuestionIndex > 0 ? (
    <Button
      variant="outline"
      size="lg"
      onClick={handlePrevious}
      className="gap-2 text-lg px-8 py-6"
    >
      <ArrowLeft className="h-5 w-5" />
      上一题
    </Button>
  ) : (
    <div className="w-32"></div>
  )}

  {/* 右侧按钮：下一题或完成预筛 */}
  <Button
    size="lg"
    onClick={handleNext}
    disabled={!selectedAnswer}
    className="gap-2 text-lg px-8 py-6"
  >
    {currentQuestionIndex < totalQuestions - 1 ? (
      <>
        下一题
        <ArrowRight className="h-5 w-5" />
      </>
    ) : (
      <>
        完成预筛
        <CheckCircle className="h-5 w-5" />
      </>
    )}
  </Button>
</div>
```

#### 2. 基本信息永久保存（UserInfoPage.tsx）

**localStorage键名常量**：
```typescript
const USER_PROFILE_KEY = 'user_profile'; // 永久档案（用户基本信息）
const USER_INFO_DRAFT_KEY = 'user_info_draft'; // 草稿数据（临时自动保存）
const USER_INFO_KEY = 'user_info'; // 正式数据（兼容旧版本）
```

**页面加载时恢复数据**：
```typescript
useEffect(() => {
  try {
    // 优先检查永久档案
    const profileData = localStorage.getItem(USER_PROFILE_KEY);
    if (profileData) {
      const parsed = JSON.parse(profileData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已加载永久档案:', parsed);
      return; // 找到永久档案后直接返回
    }

    // 如果没有永久档案，则尝试加载草稿数据
    const draftData = localStorage.getItem(USER_INFO_DRAFT_KEY);
    if (draftData) {
      const parsed = JSON.parse(draftData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已恢复草稿数据:', parsed);
    }
  } catch (error) {
    console.error('恢复数据失败:', error);
  }
}, []);
```

**提交表单**：
```typescript
const handleSubmit = () => {
  // ... 验证逻辑 ...

  // 保存到永久档案（user_profile）
  const profileData = {
    ...userInfo,
    lastUpdated: new Date().toISOString()
  };
  localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profileData));
  console.log('用户档案已保存:', profileData);

  // 同时保存到user_info（兼容旧版本）
  const dataToSave = {
    ...userInfo,
    filledDate: new Date().toISOString()
  };
  localStorage.setItem(USER_INFO_KEY, JSON.stringify(dataToSave));

  // 清空草稿数据（永久档案不清空）
  localStorage.removeItem(USER_INFO_DRAFT_KEY);
  console.log('草稿数据已清空');

  // 跳转到预筛选页面
  navigate('/pre-screening/1');
};
```

## 用户使用流程

### 场景1：首次填写信息并开始预筛选
1. 用户进入基本信息页面（表单为空）
2. 填写性别、年龄区间、省份、城市
3. 点击"提交并继续"
4. 保存到永久档案（user_profile）
5. 跳转到预筛选第一题
6. **看到"返回首页"按钮在左侧**
7. 选择答案，点击"下一题"
8. 跳转到第二题
9. **"返回首页"按钮消失，显示"上一题"按钮**

### 场景2：从第一题返回首页
1. 用户在预筛选第一题页面
2. 点击"返回首页"按钮
3. 跳转到首页
4. 答题进度已自动保存

### 场景3：从第二题返回第一题
1. 用户在预筛选第二题页面
2. 点击"上一题"按钮
3. 返回到第一题
4. **再次看到"返回首页"按钮**
5. 可以选择继续答题或返回首页

### 场景4：完成预筛选后再次访问基本信息页面
1. 用户完成预筛选
2. 查看结果
3. 再次进入基本信息页面
4. **所有字段自动填充**（加载永久档案）
5. 页面状态：查看/编辑个人资料
6. 用户可以修改信息
7. 点击"提交并继续"更新永久档案

### 场景5：关闭浏览器后再次访问
1. 用户关闭浏览器
2. 第二天再次访问网站
3. 进入基本信息页面
4. **所有字段自动填充**（永久档案仍然存在）
5. 无需重新填写

## 数据流转图

```
首次访问基本信息页面
  ↓
填写信息 → 自动保存草稿(user_info_draft)
  ↓
提交表单
  ↓
保存永久档案(user_profile) + 兼容数据(user_info)
  ↓
清空草稿(user_info_draft)
  ↓
跳转预筛选第一题
  ↓
显示"返回首页"按钮（左侧）+ "下一题"按钮（右侧）
  ↓
点击"下一题"
  ↓
跳转第二题
  ↓
显示"上一题"按钮（左侧）+ "下一题"按钮（右侧）
  ↓
完成预筛选
  ↓
再次访问基本信息页面
  ↓
加载永久档案(user_profile) → 自动填充表单
  ↓
修改信息 → 自动保存草稿(user_info_draft)
  ↓
提交表单 → 更新永久档案(user_profile)
```

## 注意事项

### 1. 返回首页按钮显示规则
- 仅在第一题显示
- 第二题及之后不显示
- 使用条件渲染：`currentQuestionIndex === 0`

### 2. 按钮样式统一
- 相同的高度：size="lg"
- 相同的内边距：px-8 py-6
- 相同的字号：text-lg
- 相同的图标大小：h-5 w-5
- 不同的变体：outline vs default

### 3. 永久档案保留
- 提交后不清空
- 完成预筛选后不清空
- 关闭浏览器后不清空
- 永不自动清空

### 4. 数据优先级
- 永久档案 > 自动草稿
- 页面加载时优先检查永久档案
- 永久档案存在时不加载草稿

### 5. 向后兼容
- 保留user_info键名
- 与永久档案同步更新
- 兼容旧版本代码

### 6. 错误处理
- 所有localStorage操作包含try-catch
- 失败时输出错误日志
- 不影响页面正常使用

## 测试建议

### 功能测试

#### 预筛选页面导航
1. **第一题返回首页测试**：
   - 进入预筛选第一题
   - 检查是否显示"返回首页"按钮在左侧
   - 检查是否显示"下一题"按钮在右侧
   - 点击"返回首页"按钮
   - 检查是否跳转到首页

2. **第二题按钮显示测试**：
   - 进入预筛选第一题
   - 选择答案，点击"下一题"
   - 跳转到第二题
   - 检查"返回首页"按钮是否消失
   - 检查是否显示"上一题"按钮

3. **返回第一题测试**：
   - 在第二题页面
   - 点击"上一题"按钮
   - 返回到第一题
   - 检查"返回首页"按钮是否再次显示

4. **按钮样式测试**：
   - 检查"返回首页"和"下一题"按钮是否大小一致
   - 检查"返回首页"按钮是否使用outline样式
   - 检查"下一题"按钮是否使用primary样式
   - 检查移动端显示是否正常

#### 基本信息永久保存
1. **首次提交测试**：
   - 清空localStorage
   - 填写完整信息并提交
   - 检查localStorage中是否有user_profile
   - 检查user_info_draft是否已清空

2. **永久档案加载测试**：
   - 提交信息后
   - 刷新页面或重新进入
   - 检查表单是否自动填充
   - 检查控制台日志："已加载永久档案"

3. **完成预筛选后测试**：
   - 提交信息
   - 完成预筛选
   - 再次进入基本信息页面
   - 检查表单是否自动填充
   - 检查user_profile是否仍然存在

4. **关闭浏览器后测试**：
   - 提交信息
   - 关闭浏览器
   - 重新打开浏览器
   - 进入基本信息页面
   - 检查表单是否自动填充

5. **修改档案测试**：
   - 加载永久档案后
   - 修改任何字段
   - 提交表单
   - 检查永久档案是否更新
   - 检查lastUpdated时间戳是否更新

### 边界测试
1. localStorage不可用时的行为
2. 永久档案数据格式错误时的处理
3. 同时打开多个标签页
4. 快速连续切换题目

### 用户体验测试
1. 返回首页按钮是否易于找到
2. 按钮样式是否清晰区分
3. 永久档案加载是否及时
4. 数据恢复是否准确
5. 移动端适配是否良好

## 控制台日志

### 正常流程日志

#### 首次填写并提交
```
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市"}
用户档案已保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
草稿数据已清空
```

#### 再次访问基本信息页面
```
已加载永久档案: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
```

#### 完成预筛选后再次访问
```
已加载永久档案: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
```

#### 关闭浏览器后再次访问
```
已加载永久档案: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
```

### 错误日志
```
恢复数据失败: SyntaxError: Unexpected token...
```

## 总结

预筛选导航优化与数据保存固化功能已完整实现，包括：
- ✅ 预筛选第一题显示"返回首页"按钮（左侧，与"下一题"同行）
- ✅ 第二题及之后不显示"返回首页"按钮
- ✅ 按钮样式统一（相同高度、内边距、字号）
- ✅ 视觉区分明确（outline vs primary）
- ✅ 永久档案（user_profile）长期存储
- ✅ 页面加载时优先加载永久档案
- ✅ 提交后不清空永久档案
- ✅ 完成预筛选后不清空永久档案
- ✅ 关闭浏览器后不清空永久档案
- ✅ 自动回填所有表单字段
- ✅ 数据分层策略（永久档案、自动草稿、兼容数据）
- ✅ 清晰的数据优先级
- ✅ 向后兼容性（保留user_info）
- ✅ 完善的错误处理和控制台日志

用户可以在预筛选第一题页面方便地返回首页，第二题及之后专注于答题。基本信息作为永久档案长期保存，无论通过任何路径再次访问都能自动填充，无需重复填写。整体用户体验得到显著提升，数据持久性得到完全保障。

# 老年痴呆（阿尔茨海默症）早期筛查网站

## 📋 项目简介

专业的阿尔茨海默症早期筛查工具，提供多种认知评估量表，帮助用户进行自我评估，早期识别认知障碍风险。

## ✨ 主要功能

- 🏠 **首页介绍** - 清晰展示工具目的和使用说明
- 🔍 **快速预筛** - 5 个快速问题，初步评估认知状况
- 📊 **多种量表** - 支持 CDT、MMSE、MoCA、ADL 等专业量表
- 📱 **移动端优化** - 完美适配手机、平板等移动设备
- 🎤 **语音播报** - 支持题目和选项的语音朗读
- 📈 **综合报告** - 生成详细的认知健康评估报告
- 🏥 **医生分析** - 支持上传医学影像，申请医生分析

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

创建 `.env` 文件：

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. 启动开发服务器

```bash
npm run dev
```

访问：http://localhost:5173

### 4. 构建生产版本

```bash
npm run build
```

构建产物将输出到 `dist` 目录。

### 5. 预览生产版本

```bash
npm run preview
```

## 📦 部署

### Vercel 部署（推荐）

```bash
# 安装 Vercel CLI
npm install -g vercel

# 登录
vercel login

# 部署
vercel

# 生产部署
vercel --prod
```

或者访问 https://vercel.com 直接上传项目。

### Netlify 部署

```bash
# 安装 Netlify CLI
npm install -g netlify-cli

# 登录
netlify login

# 部署
netlify deploy

# 生产部署
netlify deploy --prod
```

或者访问 https://netlify.com 直接拖放项目。

## 🛠️ 技术栈

- **前端框架**: React 18.3.1
- **构建工具**: Vite 5.1.4
- **语言**: TypeScript 5.9.3
- **UI 组件**: Radix UI + shadcn/ui
- **样式**: Tailwind CSS 3.4.11
- **路由**: React Router 7.9.5
- **后端**: Supabase
- **部署**: Vercel / Netlify

## 📁 项目结构

```
.
├── src/                      # 源代码目录
│   ├── components/           # React 组件
│   ├── pages/                # 页面组件
│   ├── hooks/                # 自定义 Hooks
│   ├── contexts/             # Context 提供者
│   ├── utils/                # 工具函数
│   ├── types/                # TypeScript 类型定义
│   ├── db/                   # 数据库相关
│   ├── services/             # 服务层
│   ├── polyfills.ts          # 浏览器兼容性补丁
│   ├── main.tsx              # 应用入口
│   └── App.tsx               # 根组件
├── public/                   # 静态资源目录
│   ├── favicon.png           # 网站图标
│   ├── images/               # 图片资源
│   └── df88d27a1d448ccb0f13e816414d5bab.txt  # 微信验证文件
├── supabase/                 # Supabase 后端
│   └── functions/            # Edge Functions
├── index.html                # HTML 入口文件
├── package.json              # 项目配置
├── vite.config.ts            # Vite 配置
├── vercel.json               # Vercel 配置
├── tsconfig.json             # TypeScript 配置
├── tailwind.config.js        # Tailwind CSS 配置
└── postcss.config.js         # PostCSS 配置
```

## 🔧 可用脚本

```bash
# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 预览生产版本
npm run preview

# 类型检查
npm run lint
```

## 🌐 浏览器支持

- Chrome >= 61
- Safari >= 10
- Firefox >= 60
- Edge >= 79
- iOS Safari >= 10
- Android Browser >= 5

## 📄 许可证

本项目仅供学习和研究使用。

## 🙏 致谢

感谢所有为本项目做出贡献的开发者和用户。

---

**版本**: 1.0.0  
**更新时间**: 2026-02-08  
**状态**: ✅ 生产就绪

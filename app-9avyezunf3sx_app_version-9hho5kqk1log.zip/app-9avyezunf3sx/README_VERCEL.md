# 老年痴呆（阿尔茨海默症）早期筛查网站

## 📋 项目简介

本项目是一个专业的阿尔茨海默症早期筛查工具，提供多种认知评估量表，帮助用户进行自我评估，早期识别认知障碍风险。

## ✨ 主要功能

- 🏠 **首页介绍** - 清晰展示工具目的和使用说明
- 🔍 **快速预筛** - 5 个快速问题，初步评估认知状况
- 📊 **多种量表** - 支持 CDT、MMSE、MoCA、ADL 等专业量表
- 📱 **移动端优化** - 完美适配手机、平板等移动设备
- 🎤 **语音播报** - 支持题目和选项的语音朗读
- 📈 **综合报告** - 生成详细的认知健康评估报告
- 🏥 **医生分析** - 支持上传医学影像，申请医生分析

## 🔧 Vercel 部署修复说明

### ⚠️ 重要提示

本项目已针对 Vercel 部署进行了全面修复，解决了以下问题：

1. ✅ **修复构建脚本** - 恢复了 `vite build` 命令
2. ✅ **锁定依赖版本** - 所有核心依赖使用精确版本号
3. ✅ **清理重复依赖** - 移除了冲突的依赖项
4. ✅ **添加 Vercel 配置** - 创建了 `vercel.json` 和 `.vercelignore`
5. ✅ **更新 React 版本** - 升级到 React 18.3.1

### 📦 修复内容

#### 1. package.json 修复

**修复前**:
```json
"scripts": {
  "build": "echo 'Do not use this command, only use lint to check'"
}
```

**修复后**:
```json
"scripts": {
  "dev": "vite",
  "build": "vite build",
  "preview": "vite preview"
}
```

#### 2. 依赖版本锁定

所有核心依赖已锁定为精确版本：
- `react`: 18.3.1
- `react-dom`: 18.3.1
- `vite`: 5.1.4
- `@vitejs/plugin-react`: 4.3.4
- `typescript`: 5.9.3

#### 3. Vercel 配置文件

新增 `vercel.json`:
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/index.html"
    }
  ]
}
```

## 🚀 部署步骤

### 方式一：通过 Vercel CLI

```bash
# 1. 安装 Vercel CLI（如果还没有）
npm install -g vercel

# 2. 登录 Vercel
vercel login

# 3. 在项目目录中运行
vercel

# 4. 跟随提示完成部署
```

### 方式二：通过 Vercel 网站

1. 访问 https://vercel.com
2. 登录账号
3. 点击 "New Project"
4. 上传此 ZIP 文件或连接 Git 仓库
5. 配置项目：
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
6. 点击 "Deploy"
7. 等待部署完成（约 1-3 分钟）

## 🔍 验证部署

部署完成后，请验证以下内容：

### 1. 主页访问
```
https://your-project.vercel.app
```

**预期结果**:
- ✅ 页面正常加载
- ✅ 显示"老年痴呆早期筛查"标题
- ✅ 显示"开始筛查"按钮
- ✅ 样式正常

### 2. 微信验证文件
```
https://your-project.vercel.app/df88d27a1d448ccb0f13e816414d5bab.txt
```

**预期结果**:
- ✅ 返回 HTTP 200
- ✅ 显示内容: `46f18a723f1cfb8459d3624154bc031f3f0dbbb5`

### 3. 静态资源
```
https://your-project.vercel.app/favicon.png
```

**预期结果**:
- ✅ 返回 HTTP 200
- ✅ 显示图标图片

## 💻 本地开发

### 1. 安装依赖

```bash
npm install
```

### 2. 启动开发服务器

```bash
npm run dev
```

访问：http://localhost:5173

### 3. 构建生产版本

```bash
npm run build
```

构建产物将输出到 `dist` 目录。

### 4. 预览生产版本

```bash
npm run preview
```

## 📁 项目结构

```
.
├── src/                      # 源代码目录
│   ├── components/           # React 组件
│   ├── pages/                # 页面组件
│   ├── hooks/                # 自定义 Hooks
│   ├── contexts/             # Context 提供者
│   ├── utils/                # 工具函数
│   ├── types/                # TypeScript 类型定义
│   ├── db/                   # 数据库相关
│   ├── services/             # 服务层
│   ├── polyfills.ts          # 浏览器兼容性补丁
│   ├── main.tsx              # 应用入口
│   └── App.tsx               # 根组件
├── public/                   # 静态资源目录
│   ├── favicon.png           # 网站图标
│   ├── images/               # 图片资源
│   ├── mobile-debug.js       # 移动端调试工具
│   └── df88d27a1d448ccb0f13e816414d5bab.txt  # 微信验证文件
├── supabase/                 # Supabase 后端
│   └── functions/            # Edge Functions
├── index.html                # HTML 入口文件
├── package.json              # 项目配置（已修复）
├── vite.config.ts            # Vite 配置
├── vercel.json               # Vercel 配置（新增）
├── .vercelignore             # Vercel 忽略文件（新增）
├── tsconfig.json             # TypeScript 配置
├── tailwind.config.js        # Tailwind CSS 配置
├── postcss.config.js         # PostCSS 配置
└── README.md                 # 本文件
```

## 🛠️ 技术栈

- **前端框架**: React 18.3.1
- **构建工具**: Vite 5.1.4
- **语言**: TypeScript 5.9.3
- **UI 组件**: Radix UI + shadcn/ui
- **样式**: Tailwind CSS 3.4.11
- **路由**: React Router 7.9.5
- **后端**: Supabase
- **部署**: Vercel

## 📚 相关文档

- `VERCEL_FIX_GUIDE.md` - Vercel 部署修复详细说明
- `VERCEL_FIX_QUICK.md` - 快速参考指南
- `DEPLOYMENT_DIAGNOSIS.md` - 部署诊断报告
- `WECHAT_COMPATIBILITY_DIAGNOSIS.md` - 微信浏览器兼容性诊断
- `MOBILE_COMPATIBILITY_REPORT.md` - 移动端兼容性报告
- `WHITE_SCREEN_DIAGNOSIS.md` - 白屏问题诊断说明

## 🐛 常见问题

### Q1: 部署时提示 "vite: command not found"

**A**: 这个问题已经修复。确保使用本 ZIP 包中修复后的 `package.json` 文件。

### Q2: 构建失败 - 依赖冲突

**A**: 所有依赖已锁定为精确版本，避免了版本冲突。如果仍有问题，请删除 `node_modules` 和 `package-lock.json`，然后重新运行 `npm install`。

### Q3: 部署成功但页面显示 404

**A**: 已添加 `vercel.json` 配置文件，包含 SPA 路由重写规则。确保该文件存在于项目根目录。

### Q4: 微信验证文件无法访问

**A**: 验证文件位于 `public/df88d27a1d448ccb0f13e816414d5bab.txt`，Vercel 会自动将其部署到根路径。

### Q5: 样式显示异常

**A**: 确保 `tailwind.config.js` 和 `postcss.config.js` 文件存在，并且 Tailwind CSS 已正确安装。

## 🔒 环境变量

如果项目需要环境变量，请在 Vercel 控制台中配置：

1. 进入项目设置
2. 点击 "Environment Variables"
3. 添加所需的环境变量
4. 重新部署

**常用环境变量**:
- `VITE_SUPABASE_URL` - Supabase 项目 URL
- `VITE_SUPABASE_ANON_KEY` - Supabase 匿名密钥
- `VITE_APP_ID` - 应用 ID

## 📞 技术支持

如果遇到问题，请提供以下信息：

1. **Vercel 构建日志** - 完整的构建日志
2. **浏览器错误** - Console 和 Network 标签的错误
3. **部署配置** - Vercel 项目设置截图
4. **访问测试结果** - 主页和验证文件的访问结果

## 📄 许可证

本项目仅供学习和研究使用。

## 🙏 致谢

感谢所有为本项目做出贡献的开发者和用户。

---

**项目版本**: v1.0.0  
**修复时间**: 2026-02-08  
**状态**: ✅ 准备就绪，可直接部署到 Vercel

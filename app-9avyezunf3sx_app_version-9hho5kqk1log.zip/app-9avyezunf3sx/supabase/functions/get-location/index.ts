// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE'
};

Deno.serve(async (req) => {
  // 处理 CORS 预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== Get Location Request Started ===');
    
    const { latitude, longitude } = await req.json();
    
    console.log('Request params:', { latitude, longitude });

    if (!latitude || !longitude) {
      return new Response(
        JSON.stringify({ error: '缺少经纬度参数' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 获取API密钥
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    console.log('API Key exists:', !!apiKey);
    
    if (!apiKey) {
      console.error('INTEGRATIONS_API_KEY not found');
      return new Response(
        JSON.stringify({ error: 'API密钥未配置' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 构建请求URL - 百度地图逆地理编码API
    // 注意：百度地图API的location参数格式是"纬度,经度"
    const location = `${latitude},${longitude}`;
    const apiUrl = `https://app-9avyezunf3sx-api-GaDwZ0j3erOY-gateway.appmiaoda.com/reverse_geocoding/v3?location=${encodeURIComponent(location)}&coordtype=wgs84ll&extensions_poi=0&output=json&language=zh-CN`;
    
    console.log('Calling Baidu Map API:', apiUrl);

    // 调用百度地图逆地理编码API
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`
      }
    });

    console.log('Baidu Map Response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Baidu Map API Error:', errorText);
      
      return new Response(
        JSON.stringify({ error: '定位服务暂时不可用', details: errorText }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const data = await response.json();
    console.log('Baidu Map Response:', JSON.stringify(data));

    // 检查API返回状态
    if (data.status !== 0) {
      console.error('Baidu Map API returned error status:', data.status);
      return new Response(
        JSON.stringify({ error: '定位失败', message: data.message || '未知错误' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 返回格式化的地址信息
    const result = {
      address: data.result.formatted_address || '',
      province: data.result.addressComponent?.province || '',
      city: data.result.addressComponent?.city || '',
      district: data.result.addressComponent?.district || '',
      street: data.result.addressComponent?.street || '',
      streetNumber: data.result.addressComponent?.street_number || ''
    };

    console.log('Formatted result:', result);

    return new Response(
      JSON.stringify(result),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('=== Get Location Error ===');
    console.error('Error:', error);
    
    return new Response(
      JSON.stringify({ 
        error: '定位服务出错',
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

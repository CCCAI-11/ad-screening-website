// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE'
};

Deno.serve(async (req) => {
  // 处理 CORS 预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== TTS Request Started ===');
    console.log('Method:', req.method);
    console.log('Headers:', Object.fromEntries(req.headers.entries()));

    const requestBody = await req.json();
    const { text } = requestBody;

    console.log('Request body:', { text, length: text?.length });

    if (!text || typeof text !== 'string') {
      console.error('Invalid text parameter');
      return new Response(
        JSON.stringify({ error: '文本参数不能为空' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 文本长度限制
    if (text.length > 500) {
      console.error('Text too long:', text.length);
      return new Response(
        JSON.stringify({ error: '文本长度不能超过500个字符' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 获取API密钥
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    console.log('API Key exists:', !!apiKey);
    
    if (!apiKey) {
      console.error('INTEGRATIONS_API_KEY not found in environment');
      return new Response(
        JSON.stringify({ error: 'API密钥未配置，请联系管理员' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // URL编码文本
    const encodedText = encodeURIComponent(text);

    // 构建请求参数
    const params = new URLSearchParams({
      tex: encodedText,
      cuid: 'web-client-001',
      ctp: '1',
      aue: '3', // mp3格式
      per: '0', // 度小美
      spd: '4', // 语速稍慢，适合老年人
      pit: '5', // 音调
      vol: '9'  // 音量较大，适合老年人
    });

    const apiUrl = 'https://app-9avyezunf3sx-api-e94GZ5j0ljja-gateway.appmiaoda.com/text2audio';
    console.log('Calling Baidu TTS API:', apiUrl);
    console.log('Request params:', params.toString());

    // 调用百度TTS API
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Gateway-Authorization': `Bearer ${apiKey}`
      },
      body: params.toString()
    });

    console.log('Baidu TTS Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      // 尝试解析错误信息
      const errorText = await response.text();
      console.error('Baidu TTS Error Response:', errorText);
      
      let errorMsg = '语音合成服务暂时不可用';
      try {
        const errorJson = JSON.parse(errorText);
        console.error('Error JSON:', errorJson);
        if (errorJson.err_msg) {
          errorMsg = `语音合成失败: ${errorJson.err_msg}`;
        }
      } catch (e) {
        console.error('Failed to parse error response:', e);
      }
      
      return new Response(
        JSON.stringify({ error: errorMsg, details: errorText }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 获取音频数据
    const audioData = await response.arrayBuffer();
    console.log('Audio data received:', audioData.byteLength, 'bytes');

    // 返回音频流
    return new Response(audioData, {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'audio/mpeg',
        'Content-Length': audioData.byteLength.toString()
      }
    });

  } catch (error) {
    console.error('=== TTS Error ===');
    console.error('Error type:', error.constructor.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    return new Response(
      JSON.stringify({ 
        error: '语音合成服务出错，请稍后重试',
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

/**
 * 移动端浏览器兼容性 Polyfill
 * 为旧版浏览器提供现代JavaScript API支持
 * 支持：Android 5+, iOS 10+, Chrome 61+
 */

// Promise polyfill (ES6)
if (typeof Promise === 'undefined') {
  // @ts-ignore
  window.Promise = class Promise {
    constructor(executor: (resolve: (value?: any) => void, reject: (reason?: any) => void) => void) {
      console.warn('Promise polyfill: 基础实现，建议升级浏览器');
    }
  };
}

// Array.prototype.find polyfill
if (!Array.prototype.find) {
  Array.prototype.find = function<T>(this: T[], predicate: (value: T, index: number, obj: T[]) => boolean): T | undefined {
    if (this == null) {
      throw new TypeError('Array.prototype.find called on null or undefined');
    }
    if (typeof predicate !== 'function') {
      throw new TypeError('predicate must be a function');
    }
    const list = Object(this);
    const length = list.length >>> 0;
    const thisArg = arguments[1];
    
    for (let i = 0; i < length; i++) {
      const value = list[i];
      if (predicate.call(thisArg, value, i, list)) {
        return value;
      }
    }
    return undefined;
  };
}

// Array.prototype.findIndex polyfill
if (!Array.prototype.findIndex) {
  Array.prototype.findIndex = function<T>(this: T[], predicate: (value: T, index: number, obj: T[]) => boolean): number {
    if (this == null) {
      throw new TypeError('Array.prototype.findIndex called on null or undefined');
    }
    if (typeof predicate !== 'function') {
      throw new TypeError('predicate must be a function');
    }
    const list = Object(this);
    const length = list.length >>> 0;
    const thisArg = arguments[1];
    
    for (let i = 0; i < length; i++) {
      const value = list[i];
      if (predicate.call(thisArg, value, i, list)) {
        return i;
      }
    }
    return -1;
  };
}

// Array.prototype.includes polyfill
if (!Array.prototype.includes) {
  Array.prototype.includes = function<T>(this: T[], searchElement: T, fromIndex?: number): boolean {
    if (this == null) {
      throw new TypeError('Array.prototype.includes called on null or undefined');
    }
    
    const O = Object(this);
    const len = parseInt(O.length, 10) || 0;
    if (len === 0) {
      return false;
    }
    
    const n = parseInt(fromIndex as any, 10) || 0;
    let k: number;
    if (n >= 0) {
      k = n;
    } else {
      k = len + n;
      if (k < 0) {
        k = 0;
      }
    }
    
    while (k < len) {
      const currentElement = O[k];
      if (searchElement === currentElement ||
         (searchElement !== searchElement && currentElement !== currentElement)) {
        return true;
      }
      k++;
    }
    return false;
  };
}

// String.prototype.includes polyfill
if (!String.prototype.includes) {
  String.prototype.includes = function(search: string, start?: number): boolean {
    if (typeof start !== 'number') {
      start = 0;
    }
    
    if (start + search.length > this.length) {
      return false;
    } else {
      return this.indexOf(search, start) !== -1;
    }
  };
}

// Object.assign polyfill
if (typeof Object.assign !== 'function') {
  // Must be writable: true, enumerable: false, configurable: true
  Object.defineProperty(Object, "assign", {
    value: function assign(target: any, ...sources: any[]): any {
      if (target == null) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      const to = Object(target);
      for (let index = 0; index < sources.length; index++) {
        const nextSource = sources[index];
        if (nextSource != null) {
          for (const nextKey in nextSource) {
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }
      return to;
    },
    writable: true,
    configurable: true
  });
}

// Object.entries polyfill
if (!Object.entries) {
  Object.entries = function<T>(obj: { [key: string]: T }): [string, T][] {
    const ownProps = Object.keys(obj);
    let i = ownProps.length;
    const resArray = new Array(i);
    while (i--) {
      resArray[i] = [ownProps[i], obj[ownProps[i]]];
    }
    return resArray;
  };
}

// Object.values polyfill
if (!Object.values) {
  Object.values = function<T>(obj: { [key: string]: T }): T[] {
    const ownProps = Object.keys(obj);
    let i = ownProps.length;
    const resArray = new Array(i);
    while (i--) {
      resArray[i] = obj[ownProps[i]];
    }
    return resArray;
  };
}

// Array.from polyfill
if (!Array.from) {
  Array.from = (function() {
    const toStr = Object.prototype.toString;
    const isCallable = function(fn: any): boolean {
      return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
    };
    const toInteger = function(value: any): number {
      const number = Number(value);
      if (isNaN(number)) { return 0; }
      if (number === 0 || !isFinite(number)) { return number; }
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
    };
    const maxSafeInteger = Math.pow(2, 53) - 1;
    const toLength = function(value: any): number {
      const len = toInteger(value);
      return Math.min(Math.max(len, 0), maxSafeInteger);
    };

    return function from<T>(arrayLike: ArrayLike<T>, mapFn?: (v: T, k: number) => any, thisArg?: any): any[] {
      const C = this;
      const items = Object(arrayLike);
      
      if (arrayLike == null) {
        throw new TypeError('Array.from requires an array-like object - not null or undefined');
      }
      
      const mapFunction = arguments.length > 1 ? mapFn : undefined;
      let T;
      if (typeof mapFunction !== 'undefined') {
        if (!isCallable(mapFunction)) {
          throw new TypeError('Array.from: when provided, the second argument must be a function');
        }
        if (arguments.length > 2) {
          T = thisArg;
        }
      }
      
      const len = toLength(items.length);
      const A = isCallable(C) ? Object(new C(len)) : new Array(len);
      let k = 0;
      let kValue;
      
      while (k < len) {
        kValue = items[k];
        if (mapFunction) {
          A[k] = typeof T === 'undefined' ? mapFunction(kValue, k) : mapFunction.call(T, kValue, k);
        } else {
          A[k] = kValue;
        }
        k += 1;
      }
      A.length = len;
      return A;
    };
  }());
}

// Number.isNaN polyfill
if (!Number.isNaN) {
  Number.isNaN = function(value: any): boolean {
    return typeof value === 'number' && isNaN(value);
  };
}

// Number.isFinite polyfill
if (!Number.isFinite) {
  Number.isFinite = function(value: any): boolean {
    return typeof value === 'number' && isFinite(value);
  };
}

// Number.isInteger polyfill
if (!Number.isInteger) {
  Number.isInteger = function(value: any): boolean {
    return typeof value === 'number' && 
           isFinite(value) && 
           Math.floor(value) === value;
  };
}

// CustomEvent polyfill (for older browsers)
if (typeof window !== 'undefined' && typeof window.CustomEvent !== 'function') {
  function CustomEventPolyfill(event: string, params?: CustomEventInit): any {
    params = params || { bubbles: false, cancelable: false, detail: null };
    const evt = document.createEvent('CustomEvent');
    evt.initCustomEvent(event, params.bubbles || false, params.cancelable || false, params.detail);
    return evt;
  }
  // @ts-ignore
  window.CustomEvent = CustomEventPolyfill;
}

// console polyfill (for very old browsers)
if (typeof console === 'undefined') {
  // @ts-ignore
  window.console = {
    log: function() {},
    warn: function() {},
    error: function() {},
    info: function() {},
    debug: function() {},
  };
}

console.log('✅ 移动端浏览器兼容性 Polyfill 已加载');

import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, Home, RotateCcw } from 'lucide-react';
import { TextWithAudio } from '@/components/ui/TextWithAudio';
import { scalesInfo } from '@/data/scales';

export default function ResultPage() {
  const navigate = useNavigate();
  const { screeningData, calculateScaleScore, saveScaleResult, resetScreening } = useScreening();
  
  const [score, setScore] = useState(0);

  const selectedScale = screeningData.selectedScale;
  const scaleInfo = scalesInfo.find(s => s.id === selectedScale);
  const hasSavedResult = useRef(false);

  useEffect(() => {
    // 检查是否选择了量表
    if (!selectedScale) {
      navigate('/scales');
      return;
    }

    // 计算总分
    const totalScore = calculateScaleScore(selectedScale);
    setScore(totalScore);

    // 保存量表结果到userProfile（只保存一次）
    if (!hasSavedResult.current) {
      saveScaleResult(selectedScale);
      hasSavedResult.current = true;
    }
  }, [selectedScale, calculateScaleScore, navigate, saveScaleResult]);

  // 根据不同量表的科学标准进行评估
  const getScaleAssessment = () => {
    if (!selectedScale) return { 
      riskLevel: 'normal', 
      riskLabel: '正常', 
      description: '', 
      isHighRisk: false 
    };
    
    switch (selectedScale) {
      case 'ad8':
        // AD-8量表：满分8分，≥2分为阳性
        if (score >= 2) {
          return {
            riskLevel: 'high',
            riskLabel: '筛查结果阳性',
            description: `您的评估得分为 ${score} 分（≥2分），提示可能存在认知功能下降的风险。`,
            isHighRisk: true
          };
        } else {
          return {
            riskLevel: 'normal',
            riskLabel: '筛查结果正常',
            description: `您的评估得分为 ${score} 分（<2分），目前筛查结果正常。`,
            isHighRisk: false
          };
        }
      
      case 'cdt':
        // CDT画钟试验：满分3分
        if (score === 3) {
          return {
            riskLevel: 'normal',
            riskLabel: '表现良好',
            description: `您的评估得分为 ${score} 分（满分），在此测试中表现良好。`,
            isHighRisk: false
          };
        } else if (score === 2) {
          return {
            riskLevel: 'mild',
            riskLabel: '表现基本正常',
            description: `您的评估得分为 ${score} 分，在此测试中表现基本正常。`,
            isHighRisk: false
          };
        } else {
          return {
            riskLevel: 'moderate',
            riskLabel: '可能存在困难',
            description: `您的评估得分为 ${score} 分，此测试结果提示可能存在困难，建议结合其他评估综合判断。`,
            isHighRisk: true
          };
        }
      
      case 'mmse':
        // MMSE简易精神状态检查：满分14分（简化版11题）
        if (score >= 13) {
          return {
            riskLevel: 'normal',
            riskLabel: '正常',
            description: `您的评估得分为 ${score} 分（≥13分），认知功能正常。`,
            isHighRisk: false
          };
        } else if (score >= 10 && score <= 12) {
          return {
            riskLevel: 'mild',
            riskLabel: '提示轻度认知障碍',
            description: `您的评估得分为 ${score} 分（10-12分），提示可能存在轻度认知障碍。`,
            isHighRisk: true
          };
        } else if (score >= 7 && score <= 9) {
          return {
            riskLevel: 'moderate',
            riskLabel: '提示中度认知障碍',
            description: `您的评估得分为 ${score} 分（7-9分），提示可能存在中度认知障碍。`,
            isHighRisk: true
          };
        } else {
          return {
            riskLevel: 'severe',
            riskLabel: '提示重度认知障碍',
            description: `您的评估得分为 ${score} 分（≤6分），提示可能存在重度认知障碍。`,
            isHighRisk: true
          };
        }
      
      case 'moca':
        // MoCA蒙特利尔认知评估：满分25分
        if (score >= 21) {
          return {
            riskLevel: 'normal',
            riskLabel: '正常',
            description: `您的评估得分为 ${score} 分（≥21分），认知功能正常。`,
            isHighRisk: false
          };
        } else {
          return {
            riskLevel: 'mild',
            riskLabel: '提示存在认知下降',
            description: `您的评估得分为 ${score} 分（<21分），提示可能存在认知下降。`,
            isHighRisk: true
          };
        }
      
      case 'adl':
        // ADL日常生活活动能力量表：14-42分，分数越低越好
        if (score === 14) {
          return {
            riskLevel: 'normal',
            riskLabel: '完全独立',
            description: `您的评估得分为 ${score} 分（最低分），日常生活活动能力完全独立。`,
            isHighRisk: false
          };
        } else if (score >= 15 && score <= 21) {
          return {
            riskLevel: 'mild',
            riskLabel: '轻度依赖',
            description: `您的评估得分为 ${score} 分（15-21分），日常生活活动能力轻度依赖，部分活动需要帮助。`,
            isHighRisk: false
          };
        } else if (score >= 22 && score <= 35) {
          return {
            riskLevel: 'moderate',
            riskLabel: '中度依赖',
            description: `您的评估得分为 ${score} 分（22-35分），日常生活活动能力中度依赖，多数活动需要帮助。`,
            isHighRisk: true
          };
        } else {
          return {
            riskLevel: 'severe',
            riskLabel: '重度依赖',
            description: `您的评估得分为 ${score} 分（≥36分），日常生活活动能力重度依赖，大部分活动完全依赖他人。`,
            isHighRisk: true
          };
        }
      
      default:
        return { 
          riskLevel: 'normal', 
          riskLabel: '正常', 
          description: '', 
          isHighRisk: false 
        };
    }
  };

  const assessment = getScaleAssessment();

  const handleRestart = () => {
    resetScreening();
    navigate('/');
  };

  if (!scaleInfo) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">未找到量表信息</p>
          <Button onClick={() => navigate('/scales')} className="mt-4">
            返回量表选择
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="flex-1 container mx-auto px-4 py-8 max-w-3xl">
        {/* 评估结果卡片 */}
        <Card className="shadow-lg mb-6">
          <CardHeader>
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <span>{scaleInfo.name} 评估结果</span>
              <TextWithAudio text={`${scaleInfo.name} 评估结果`} showText={false} iconSize={24} />
            </CardTitle>
          </CardHeader>
          
          <CardContent className="pt-8">
            {/* 得分显示 */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 mb-4">
                <div className="text-center">
                  <div className="text-5xl font-bold text-primary">{score}</div>
                  <div className="text-sm text-muted-foreground">分</div>
                </div>
              </div>
              <p className="text-muted-foreground flex items-center justify-center gap-1">
                <span>您的评估得分</span>
                <TextWithAudio text="您的评估得分" showText={false} iconSize={16} />
              </p>
            </div>

            {/* 风险评估结果 */}
            {assessment.isHighRisk ? (
              <Alert className="mb-6 bg-destructive/5">
                <AlertCircle className="h-5 w-5 text-destructive" />
                <AlertDescription className="ml-2">
                  <div className="font-semibold text-lg text-destructive mb-2 flex items-center gap-1">
                    <span>{assessment.riskLabel}</span>
                    <TextWithAudio text={assessment.riskLabel} showText={false} iconSize={18} />
                  </div>
                  <p className="text-foreground leading-relaxed flex items-start gap-1">
                    <span>{assessment.description}</span>
                    <TextWithAudio 
                      text={assessment.description} 
                      showText={false} 
                      iconSize={16} 
                    />
                  </p>
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="mb-6 bg-secondary/5">
                <CheckCircle2 className="h-5 w-5 text-secondary" />
                <AlertDescription className="ml-2">
                  <div className="font-semibold text-lg text-secondary mb-2 flex items-center gap-1">
                    <span>{assessment.riskLabel}</span>
                    <TextWithAudio text={assessment.riskLabel} showText={false} iconSize={18} />
                  </div>
                  <p className="text-foreground leading-relaxed flex items-start gap-1">
                    <span>{assessment.description}</span>
                    <TextWithAudio 
                      text={assessment.description} 
                      showText={false} 
                      iconSize={16} 
                    />
                  </p>
                </AlertDescription>
              </Alert>
            )}

            {/* 专业建议 */}
            <div className="bg-muted/50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-lg mb-3 flex items-center gap-1">
                <span>专业建议</span>
                <TextWithAudio text="专业建议" showText={false} iconSize={18} />
              </h3>
              <ul className="space-y-2 text-sm text-foreground">
                {assessment.isHighRisk ? (
                  <>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>建议尽快前往医院神经内科或记忆门诊进行专业评估</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>保持规律作息，保证充足睡眠</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>多参与社交活动，保持大脑活跃</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>均衡饮食，适量运动，控制慢性疾病</span>
                    </li>
                  </>
                ) : (
                  <>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>继续保持健康的生活方式</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>定期进行认知功能评估（建议每年1-2次）</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>保持积极的社交活动和智力活动</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>如有任何认知功能变化，及时咨询医生</span>
                    </li>
                  </>
                )}
              </ul>
            </div>

            {/* 操作按钮 */}
            <div className="space-y-3">
              {/* 主要操作按钮 */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  onClick={() => navigate('/scales')}
                  className="flex-1 gap-2"
                  size="lg"
                >
                  继续测试其他量表
                </Button>
                <Button
                  onClick={() => navigate('/comprehensive-report')}
                  variant="outline"
                  className="flex-1 gap-2"
                  size="lg"
                >
                  查看我的综合报告
                </Button>
              </div>
              
              {/* 次要操作按钮 */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  onClick={handleRestart}
                  className="flex-1 gap-2"
                >
                  <RotateCcw className="h-4 w-4" />
                  重新评估
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate('/')}
                  className="flex-1 gap-2"
                >
                  <Home className="h-4 w-4" />
                  返回首页
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-6 mt-8">
        <div className="container mx-auto px-4 max-w-3xl">
          <p className="text-xs text-muted-foreground text-center">
            免责声明：本工具仅供参考，不能替代专业医疗诊断。如有疑虑，请及时就医咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

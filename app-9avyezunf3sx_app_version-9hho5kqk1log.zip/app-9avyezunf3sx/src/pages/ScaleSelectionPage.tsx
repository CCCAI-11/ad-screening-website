import { useNavigate } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, Clock, FileText, CheckCircle, BarChart3, PartyPopper } from 'lucide-react';
import { TextWithAudio } from '@/components/ui/TextWithAudio';
import { scalesInfo } from '@/data/scales';
import type { ScaleType } from '@/types/screening';

export default function ScaleSelectionPage() {
  const navigate = useNavigate();
  const { screeningData, selectScale } = useScreening();

  const handleSelectScale = (scaleId: ScaleType) => {
    selectScale(scaleId);
    // 跳转到该量表的第一题
    navigate(`/question/${scaleId}/1`);
  };

  // 获取已完成的量表数量
  const completedCount = screeningData.scaleResults.length;
  const completedScaleIds = screeningData.scaleResults.map(r => r.scaleId);
  const totalScales = scalesInfo.length;
  const isAllCompleted = completedCount === totalScales;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 顶部导航 */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate('/pre-screening-result')}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            返回
          </Button>
          <h1 className="text-xl font-semibold text-foreground">选择评估量表</h1>
          <div className="w-20"></div>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-3">
            <TextWithAudio text="请选择一个评估量表" />
          </h2>
          <p className="text-muted-foreground">
            <TextWithAudio text="以下是5个专业的认知筛查量表，请根据您的需求选择一个进行评估" />
          </p>
        </div>

        {/* 评估进度提示 */}
        {completedCount > 0 && (
          <Alert className={`mb-6 border-2 ${
            isAllCompleted 
              ? 'border-green-500/50 bg-green-50 dark:bg-green-950/20' 
              : 'border-primary/50 bg-primary/5'
          }`}>
            {isAllCompleted ? (
              <PartyPopper className="h-5 w-5 text-green-600 dark:text-green-400" />
            ) : (
              <CheckCircle className="h-5 w-5 text-primary" />
            )}
            <AlertDescription className="ml-2">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <span className={`${
                  isAllCompleted 
                    ? 'text-green-700 dark:text-green-300 font-semibold' 
                    : 'text-foreground'
                }`}>
                  {isAllCompleted ? (
                    <>
                      您已完成全部量表的评估！🎉
                    </>
                  ) : (
                    <>
                      您已完成 <span className="font-bold text-primary">{completedCount}</span> 个量表的评估
                    </>
                  )}
                </span>
                <Button
                  onClick={() => navigate('/comprehensive-report')}
                  size="sm"
                  className="gap-2 shrink-0"
                >
                  <BarChart3 className="h-4 w-4" />
                  查看综合报告
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* 量表卡片网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {scalesInfo.map((scale) => {
            const isCompleted = completedScaleIds.includes(scale.id);
            return (
              <Card
                key={scale.id}
                className={`hover:shadow-lg transition-shadow cursor-pointer group ${isCompleted ? 'border-2 border-primary/30' : ''}`}
                onClick={() => handleSelectScale(scale.id)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-xl group-hover:text-primary transition-colors">
                    {isCompleted ? (
                      <CheckCircle className="h-5 w-5 text-primary" />
                    ) : (
                      <FileText className="h-5 w-5" />
                    )}
                    {scale.name}
                    {isCompleted && (
                      <span className="ml-auto text-xs font-normal px-2 py-1 bg-primary/10 text-primary rounded-full">
                        已完成
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription className="text-sm mt-2">
                    <TextWithAudio text={scale.description} />
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span>共 {scale.questionCount} 题</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span>约 {scale.estimatedTime}</span>
                    </div>
                  </div>
                  <Button
                    className="w-full mt-4"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectScale(scale.id);
                    }}
                  >
                    {isCompleted ? '重新测试' : '开始测试'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* 提示信息 */}
        <div className="mt-8 p-6 bg-muted/50 rounded-lg">
          <h3 className="font-semibold text-foreground mb-2">温馨提示</h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• 每个量表都经过专业验证，可根据您的时间和需求选择</li>
            <li>• 建议在安静的环境中完成评估，以获得更准确的结果</li>
            <li>• 评估过程中可随时暂停，您的答案会自动保存</li>
            <li>• 完成评估后，您将获得详细的分析报告</li>
          </ul>
        </div>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-6">
        <div className="container mx-auto px-4 max-w-5xl">
          <p className="text-xs text-muted-foreground text-center">
            免责声明：本工具仅供参考，不能替代专业医疗诊断。如有疑虑，请及时就医咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

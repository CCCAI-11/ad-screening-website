import { useNavigate } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, Home, FileText, TrendingUp, TrendingDown, Minus, BarChart3, Brain, Zap, MessageSquare, Eye, AlertTriangle, CheckCircle2, Lightbulb, Volume2, Play, Square } from 'lucide-react';
import { useState, useEffect, useRef, useCallback } from 'react';
import type { ScaleType } from '@/types/screening';
import MedicalReportUpload from '@/components/MedicalReportUpload';

// 认知领域定义
interface CognitiveDomain {
  name: string;
  icon: typeof Brain;
  scales: ScaleType[];
  description: string;
}

// 量表信息映射
const scaleInfoMap: Record<ScaleType, { name: string; maxScore: number; description: string }> = {
  'ad8': { name: 'AD-8量表', maxScore: 8, description: '日常认知功能变化筛查' },
  'mmse': { name: 'MMSE量表', maxScore: 14, description: '简易精神状态检查（简化版11题）' },
  'moca': { name: 'MoCA量表', maxScore: 25, description: '蒙特利尔认知评估（纯文本版）' },
  'adl': { name: 'ADL量表', maxScore: 14, description: '日常生活能力评估' },
  'cdt': { name: 'CDT量表', maxScore: 3, description: '画钟测验' }
};

const cognitiveDomains: CognitiveDomain[] = [
  {
    name: '记忆力',
    icon: Brain,
    scales: ['ad8', 'mmse', 'moca'],
    description: '短期记忆、长期记忆和工作记忆能力'
  },
  {
    name: '执行力',
    icon: Zap,
    scales: ['ad8', 'cdt', 'moca'],
    description: '计划、组织、决策和问题解决能力'
  },
  {
    name: '语言能力',
    icon: MessageSquare,
    scales: ['mmse', 'moca'],
    description: '语言理解、表达和命名能力'
  },
  {
    name: '视空间能力',
    icon: Eye,
    scales: ['cdt', 'moca'],
    description: '空间感知、视觉识别和构图能力'
  }
];

export default function ComprehensiveReportPage() {
  const navigate = useNavigate();
  const { screeningData, refreshData } = useScreening();

  // ============ 第一步：清除旧状态，使用单一明确的状态变量 ============
  const [isPlayingFullReport, setIsPlayingFullReport] = useState(false);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // 使用scaleResults而不是scaleAnswers
  const completedResults = screeningData.scaleResults || [];

  // 页面加载时刷新数据
  useEffect(() => {
    console.log('综合报告页面加载，刷新数据');
    refreshData();
  }, [refreshData]);

  // ============ 第四步：创建全局控制函数 ============
  // 统一的停止播报函数
  const stopAnySpeech = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    currentUtteranceRef.current = null;
    setIsPlayingFullReport(false);
  }, []);

  // 统一的播报函数
  const playSpeech = useCallback((text: string, isFullReport: boolean = false) => {
    // 先停止任何当前播报
    stopAnySpeech();

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      
      // 设置语音参数（与全站一致）
      utterance.lang = 'zh-CN';
      utterance.rate = 0.8;
      utterance.pitch = 1.1;
      utterance.volume = 1.0;

      // 尝试选择女声
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.lang.includes('zh') && 
        (voice.name.includes('Female') || 
         voice.name.includes('女') ||
         voice.name.includes('Ting-Ting') ||
         voice.name.includes('Yaoyao'))
      );
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }

      // 设置事件监听
      utterance.onstart = () => {
        if (isFullReport) {
          setIsPlayingFullReport(true);
        }
      };

      utterance.onend = () => {
        currentUtteranceRef.current = null;
        if (isFullReport) {
          setIsPlayingFullReport(false);
        }
      };

      utterance.onerror = () => {
        currentUtteranceRef.current = null;
        if (isFullReport) {
          setIsPlayingFullReport(false);
        }
      };

      // 保存当前实例并开始播报
      currentUtteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error('播报出错:', error);
      stopAnySpeech();
    }
  }, [stopAnySpeech]);

  // 页面卸载时停止语音
  useEffect(() => {
    return () => {
      stopAnySpeech();
    };
  }, [stopAnySpeech]);

  // 导航时停止语音
  const navigateWithStopVoice = useCallback((path: string) => {
    stopAnySpeech();
    navigate(path);
  }, [navigate, stopAnySpeech]);

  // 如果没有完成任何量表，提示用户
  if (completedResults.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => navigateWithStopVoice('/scales')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              返回量表选择
            </Button>
            <h1 className="text-xl font-semibold text-foreground">综合报告</h1>
            <div className="w-24"></div>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-4 py-8 max-w-3xl flex items-center justify-center">
          <Card className="w-full">
            <CardContent className="pt-8 text-center">
              <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">暂无评估记录</h2>
              <p className="text-muted-foreground mb-6">
                您还没有完成任何量表评估，请先完成至少一个量表测试
              </p>
              <Button onClick={() => navigateWithStopVoice('/scales')}>
                前往量表选择
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  // 计算每个量表的风险等级（使用科学标准）
  const scaleResultsWithRisk = completedResults.map(result => {
    let riskLevel: 'high' | 'medium' | 'low' = 'low';
    let riskText = '正常';
    
    switch (result.scaleId) {
      case 'ad8':
        // AD-8量表：满分8分，≥2分为阳性
        if (result.score >= 2) {
          riskLevel = 'high';
          riskText = '筛查阳性';
        } else {
          riskText = '筛查正常';
        }
        break;
      
      case 'cdt':
        // CDT画钟试验：满分3分
        if (result.score === 3) {
          riskText = '表现良好';
        } else if (result.score === 2) {
          riskLevel = 'medium';
          riskText = '基本正常';
        } else {
          riskLevel = 'high';
          riskText = '可能存在困难';
        }
        break;
      
      case 'mmse':
        // MMSE简易精神状态检查：满分14分（简化版11题）
        if (result.score >= 13) {
          riskText = '正常';
        } else if (result.score >= 10 && result.score <= 12) {
          riskLevel = 'medium';
          riskText = '轻度认知障碍';
        } else if (result.score >= 7 && result.score <= 9) {
          riskLevel = 'high';
          riskText = '中度认知障碍';
        } else {
          riskLevel = 'high';
          riskText = '重度认知障碍';
        }
        break;
      
      case 'moca':
        // MoCA蒙特利尔认知评估：满分25分（纯文本版）
        if (result.score >= 21) {
          riskText = '正常';
        } else if (result.score >= 18 && result.score <= 20) {
          riskLevel = 'medium';
          riskText = '轻度认知障碍';
        } else if (result.score >= 14 && result.score <= 17) {
          riskLevel = 'high';
          riskText = '中度认知障碍';
        } else {
          riskLevel = 'high';
          riskText = '重度认知障碍';
        }
        break;
      
      case 'adl':
        // ADL日常生活活动能力量表：满分14分，分数越低越好
        if (result.score === 14) {
          riskText = '完全独立';
        } else if (result.score >= 12 && result.score <= 13) {
          riskLevel = 'medium';
          riskText = '轻度功能障碍';
        } else if (result.score >= 9 && result.score <= 11) {
          riskLevel = 'high';
          riskText = '中度功能障碍';
        } else {
          riskLevel = 'high';
          riskText = '重度功能障碍';
        }
        break;
    }
    
    return {
      ...result,
      riskLevel,
      riskText
    };
  });

  // 计算总体风险评估（基于最高风险等级原则）
  const highRiskCount = scaleResultsWithRisk.filter(r => r.riskLevel === 'high').length;
  const mediumRiskCount = scaleResultsWithRisk.filter(r => r.riskLevel === 'medium').length;
  
  let overallRisk: 'high' | 'medium' | 'low' = 'low';
  let overallRiskText = '认知功能良好';
  
  // 只要有一个高风险，整体评估就是高风险
  if (highRiskCount > 0) {
    overallRisk = 'high';
    overallRiskText = '建议尽快就医评估';
  } else if (mediumRiskCount > 0) {
    // 只要有一个中风险，整体评估就是中风险
    overallRisk = 'medium';
    overallRiskText = '建议关注并定期复查';
  }

  // 分领域解读
  const domainAnalysis = cognitiveDomains.map(domain => {
    // 找到该领域相关的已完成量表
    const relatedResults = scaleResultsWithRisk.filter(r => 
      domain.scales.includes(r.scaleId)
    );

    if (relatedResults.length === 0) {
      return {
        ...domain,
        status: 'not_tested' as const,
        statusText: '暂未测试',
        comment: '暂未测试该领域',
        specificFindings: '',
        lifeSuggestion: ''
      };
    }

    // 计算该领域的风险等级
    const domainHighRisk = relatedResults.filter(r => r.riskLevel === 'high').length;
    const domainMediumRisk = relatedResults.filter(r => r.riskLevel === 'medium').length;

    let status: 'good' | 'attention' | 'concern' = 'good';
    let statusText = '表现良好';
    let comment = '该领域表现良好，请继续保持';
    let specificFindings = '';
    let lifeSuggestion = '';

    if (domainHighRisk > 0) {
      status = 'concern';
      statusText = '需要关注';
      comment = `该领域有${domainHighRisk}个量表提示需要关注`;
      
      // 根据领域生成具体表现
      if (domain.name === '记忆力') {
        specificFindings = '在测试中反映出在回忆近期事件、记住新信息方面存在一定困难，日常可能出现遗忘重要事项的情况。';
        lifeSuggestion = '建议使用记事本、手机提醒等工具辅助记忆日常事务，保持规律作息，进行适度的记忆训练游戏。';
      } else if (domain.name === '执行力') {
        specificFindings = '在计划安排、问题解决等方面可能存在困难，完成复杂任务时需要更多时间或帮助。';
        lifeSuggestion = '建议将复杂任务分解为简单步骤，使用清单管理待办事项，保持环境整洁有序。';
      } else if (domain.name === '语言能力') {
        specificFindings = '在语言表达、理解或命名物品时可能出现困难，交流时偶尔找不到合适的词语。';
        lifeSuggestion = '建议多参与社交活动，进行阅读、填字游戏等语言训练，保持与他人的日常交流。';
      } else if (domain.name === '视空间能力') {
        specificFindings = '在空间判断、识别物体位置或完成绘图任务时可能存在困难。';
        lifeSuggestion = '建议在熟悉的环境中活动，外出时有人陪伴，可进行拼图、积木等空间训练游戏。';
      }
    } else if (domainMediumRisk > 0) {
      status = 'attention';
      statusText = '轻度异常';
      comment = `该领域有${domainMediumRisk}个量表提示轻度异常`;
      
      // 根据领域生成具体表现
      if (domain.name === '记忆力') {
        specificFindings = '偶尔出现遗忘现象，但整体记忆功能基本正常。';
        lifeSuggestion = '建议养成记录习惯，保持充足睡眠，适度进行脑力活动。';
      } else if (domain.name === '执行力') {
        specificFindings = '在处理复杂任务时偶有困难，但日常生活基本不受影响。';
        lifeSuggestion = '建议保持规律的生活节奏，适当进行策略类游戏训练。';
      } else if (domain.name === '语言能力') {
        specificFindings = '语言功能基本正常，偶尔出现词不达意的情况。';
        lifeSuggestion = '建议保持阅读习惯，多参与交流活动。';
      } else if (domain.name === '视空间能力') {
        specificFindings = '空间感知能力基本正常，在复杂环境中偶有困难。';
        lifeSuggestion = '建议保持适度的户外活动，进行空间类益智游戏。';
      }
    } else {
      // 良好状态
      if (domain.name === '记忆力') {
        specificFindings = '记忆功能表现良好，能够正常回忆日常事件和信息。';
        lifeSuggestion = '建议继续保持良好的生活习惯，适度进行脑力活动以维持认知功能。';
      } else if (domain.name === '执行力') {
        specificFindings = '计划和执行能力表现良好，能够有效完成各类任务。';
        lifeSuggestion = '建议继续保持规律的生活方式，适当挑战新的学习任务。';
      } else if (domain.name === '语言能力') {
        specificFindings = '语言理解和表达能力表现良好，交流顺畅。';
        lifeSuggestion = '建议继续保持阅读和社交活动，丰富语言表达。';
      } else if (domain.name === '视空间能力') {
        specificFindings = '空间感知和视觉识别能力表现良好。';
        lifeSuggestion = '建议继续保持户外活动和空间类益智游戏。';
      }
    }

    return {
      ...domain,
      status,
      statusText,
      comment,
      specificFindings,
      lifeSuggestion,
      testedCount: relatedResults.length
    };
  });

  // 生成核心发现
  const generateKeyFindings = () => {
    const findings: string[] = [];
    
    scaleResultsWithRisk.forEach(result => {
      if (result.riskLevel === 'high') {
        const scaleInfo = scaleInfoMap[result.scaleId];
        if (result.scaleId === 'ad8') {
          findings.push(`**${scaleInfo.name}**：得分${result.score}分（≥2分提示需关注），在日常认知功能变化方面提示需要重点关注，可能存在记忆力下降、判断力减退等表现。`);
        } else if (result.scaleId === 'mmse') {
          findings.push(`**${scaleInfo.name}**：得分${result.score}分（满分${scaleInfo.maxScore}分），低于正常范围（≥13分），提示认知功能可能存在障碍。`);
        } else if (result.scaleId === 'moca') {
          findings.push(`**${scaleInfo.name}**：得分${result.score}分（满分${scaleInfo.maxScore}分），低于正常范围（≥21分），在多个认知领域可能存在轻度障碍。`);
        } else if (result.scaleId === 'cdt') {
          findings.push(`**${scaleInfo.name}**：得分${result.score}分（满分${scaleInfo.maxScore}分），在视空间能力和执行功能方面可能存在困难。`);
        } else if (result.scaleId === 'adl') {
          findings.push(`**${scaleInfo.name}**：得分${result.score}分，提示在日常生活活动中可能需要他人帮助。`);
        }
      }
    });

    // 如果没有高风险项，添加中风险或良好状态的发现
    if (findings.length === 0) {
      const mediumRiskResults = scaleResultsWithRisk.filter(r => r.riskLevel === 'medium');
      if (mediumRiskResults.length > 0) {
        mediumRiskResults.forEach(result => {
          const scaleInfo = scaleInfoMap[result.scaleId];
          findings.push(`**${scaleInfo.name}**：得分${result.score}分，显示轻度异常，建议定期复查。`);
        });
      } else {
        findings.push('**整体表现良好**：各项评估结果均在正常范围内，认知功能保持良好状态。');
        findings.push('**建议保持**：继续保持健康的生活方式，包括规律作息、均衡饮食、适度运动和社交活动。');
      }
    }

    // 添加领域相关发现
    const concernDomains = domainAnalysis.filter(d => d.status === 'concern');
    if (concernDomains.length > 0) {
      const domainNames = concernDomains.map(d => d.name).join('、');
      findings.push(`**重点关注领域**：${domainNames}领域的多项测试结果提示需要关注，建议在日常生活中特别注意这些方面的表现。`);
    }

    return findings.slice(0, 4); // 最多返回4条核心发现
  };

  const keyFindings = generateKeyFindings();

  // ============ 第三步：建立精准的内容映射 ============
  // 创建内容映射对象，通过ID精准定位内容
  const sectionContentMap = useCallback(() => {
    const map: Record<string, string> = {};

    // 总体评估
    map['overall'] = `总体评估：${overallRiskText}。您已完成 ${completedResults.length} 个量表的评估。${
      overallRisk === 'high' ? '多项评估结果提示需要关注，建议尽快前往医院神经内科或记忆门诊进行专业评估。' :
      overallRisk === 'medium' ? '部分评估结果提示需要关注，建议定期复查并保持健康的生活方式。' :
      '各项评估结果良好，请继续保持健康的生活方式。'
    }`;

    // 风险程度分析
    const riskLevel = overallRisk === 'high' ? '高风险' : overallRisk === 'medium' ? '中风险' : '低风险';
    const riskDesc = overallRisk === 'high' 
      ? '评估结果提示在多个认知领域存在明确的变化迹象，这些变化可能影响日常生活功能。建议引起高度重视，及时寻求专业医疗机构的进一步评估和指导。早期干预对于延缓认知功能下降具有重要意义。'
      : overallRisk === 'medium'
      ? '评估结果提示在某些认知领域存在轻度变化迹象，虽然目前可能对日常生活影响较小，但仍需要关注。建议定期复查，保持健康的生活方式，必要时咨询专业医生。'
      : '评估结果显示您的认知功能处于良好状态，各项指标均在正常范围内。建议继续保持健康的生活方式，包括规律作息、均衡饮食、适度运动和积极的社交活动，以维持良好的认知功能。';
    map['risk'] = `风险程度分析。基于您完成的 ${completedResults.length} 个量表，当前结果显示为 ${riskLevel} 水平。${riskDesc}`;

    // 核心发现
    const findingsText = keyFindings.map(f => f.replace(/\*\*/g, '')).join('。');
    map['findings'] = `核心发现。${findingsText}`;

    // 分领域解读
    const domainsText = domainAnalysis
      .filter(d => d.status !== 'not_tested')
      .map(d => `${d.name}领域：${d.statusText}。${d.specificFindings || ''}`)
      .join('。');
    map['domains'] = `分领域解读。${domainsText}`;

    // 每个子领域
    domainAnalysis.forEach(domain => {
      if (domain.status !== 'not_tested') {
        map[`domain_${domain.name}`] = `${domain.name}领域：${domain.statusText}。${domain.specificFindings || ''}${domain.lifeSuggestion ? '。' + domain.lifeSuggestion : ''}`;
      }
    });

    // 后续步骤建议
    const actionText = overallRisk === 'high'
      ? '建议尽快就医。评估结果提示需要专业医疗评估。建议携带本报告，尽快预约神经内科、记忆门诊或老年精神科进行全面检查。早期诊断和干预对于延缓病情进展具有重要意义。'
      : overallRisk === 'medium'
      ? '建议关注并复查。评估结果提示存在轻度异常。建议在3到6个月内复查，并考虑咨询社区健康中心或全科医生进行进一步了解。定期监测有助于及时发现变化。'
      : '保持良好状态。评估结果显示认知功能良好。建议保持健康的生活方式，6到12个月后重新评估。继续保持当前的良好习惯，有助于维持认知功能的健康状态。';
    map['action'] = `后续步骤建议。${actionText}`;

    return map;
  }, [completedResults.length, overallRisk, overallRiskText, keyFindings, domainAnalysis]);

  // ============ 第三步：绑定独立、无冲突的事件 ============
  // 播报单个模块
  const handlePlaySection = useCallback((sectionId: string) => {
    const contentMap = sectionContentMap();
    const content = contentMap[sectionId];
    
    if (content) {
      playSpeech(content, false);
    }
  }, [sectionContentMap, playSpeech]);

  // ============ 第四步：重建"播报全文"功能 ============
  // 播报全文
  const handlePlayFullReport = useCallback(() => {
    // 如果正在播报全文，则停止
    if (isPlayingFullReport) {
      stopAnySpeech();
      return;
    }

    // 通过拼接所有部分的文本生成全文内容
    const contentMap = sectionContentMap();
    const fullText = [
      contentMap['overall'],
      contentMap['risk'],
      contentMap['findings'],
      contentMap['domains'],
      contentMap['action']
    ].filter(Boolean).join('。');

    playSpeech(fullText, true);
  }, [isPlayingFullReport, sectionContentMap, playSpeech, stopAnySpeech]);

  // 格式化日期时间
  const formatDateTime = (date: Date) => {
    const d = new Date(date);
    return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 ${d.getHours()}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 顶部导航 */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigateWithStopVoice('/scales')}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            返回量表选择
          </Button>
          <h1 className="text-xl font-semibold text-foreground">综合报告</h1>
          <Button
            variant="ghost"
            onClick={() => navigateWithStopVoice('/')}
            className="gap-2"
          >
            <Home className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        {/* 页面标题 - 移除蓝色背景 */}
        <div className="mb-6 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-2 flex items-center justify-center gap-3">
            <BarChart3 className="h-8 w-8" />
            <span>综合评估报告</span>
          </h1>
          <p className="text-muted-foreground text-sm mb-4">
            基于您完成的 {completedResults.length} 个量表的综合分析
          </p>

          {/* ============ 第二步：修复UI渲染，确保控制栏始终静态存在 ============ */}
          {/* 语音控制栏 - 始终显示，不受条件判断影响 */}
          <div className="bg-primary/5 rounded-lg p-4 mt-4 border border-primary/20">
            <div className="flex flex-col items-center gap-3">
              <p className="text-sm text-muted-foreground text-center leading-relaxed">
                💡 <strong>提示：</strong>点击"播报全文"聆听整份报告。在播报过程中，点击任何部分（如"记忆力"）旁的小喇叭，可立即切换至收听该部分详情。
              </p>
              <div className="flex gap-3">
                {/* 播报全文按钮 - 由单一状态变量isPlayingFullReport控制 */}
                <Button
                  onClick={handlePlayFullReport}
                  variant={isPlayingFullReport ? "secondary" : "default"}
                  className="gap-2 min-w-[140px]"
                  size="lg"
                >
                  {isPlayingFullReport ? (
                    <>
                      <Square className="h-5 w-5" />
                      停止播报
                    </>
                  ) : (
                    <>
                      <Play className="h-5 w-5" />
                      播报全文
                    </>
                  )}
                </Button>
                {/* 停止所有播报按钮 - 始终显示 */}
                <Button
                  onClick={stopAnySpeech}
                  variant="outline"
                  className="gap-2 min-w-[140px]"
                  size="lg"
                >
                  <Square className="h-5 w-5" />
                  停止所有播报
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* 总体评估 */}
        <Card className="shadow-lg mb-6">
          <CardContent className="pt-8">
            {/* 总体风险评估 - 添加唯一ID用于内容定位 */}
            <Alert 
              id="section-overall"
              className={`mb-6 border-2 ${
              overallRisk === 'high' 
                ? 'border-destructive/50 bg-destructive/5' 
                : overallRisk === 'medium'
                ? 'border-orange-500/50 bg-orange-50 dark:bg-orange-950/20'
                : 'border-secondary/50 bg-secondary/5'
            }`}>
              <AlertDescription className="ml-2">
                <div className={`font-semibold text-lg mb-2 flex items-center gap-2 ${
                  overallRisk === 'high' 
                    ? 'text-destructive' 
                    : overallRisk === 'medium'
                    ? 'text-orange-700 dark:text-orange-400'
                    : 'text-secondary'
                }`}>
                  {overallRisk === 'high' && <TrendingDown className="h-5 w-5" />}
                  {overallRisk === 'medium' && <Minus className="h-5 w-5" />}
                  {overallRisk === 'low' && <TrendingUp className="h-5 w-5" />}
                  <span>总体评估：{overallRiskText}</span>
                  {/* 小喇叭按钮 - 通过data-section-id精准定位内容 */}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 ml-auto"
                    onClick={() => handlePlaySection('overall')}
                    data-section-id="overall"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-foreground leading-relaxed">
                  您已完成 {completedResults.length} 个量表的评估。
                  {overallRisk === 'high' && '多项评估结果提示需要关注，建议尽快前往医院神经内科或记忆门诊进行专业评估。'}
                  {overallRisk === 'medium' && '部分评估结果提示需要关注，建议定期复查并保持健康的生活方式。'}
                  {overallRisk === 'low' && '各项评估结果良好，请继续保持健康的生活方式。'}
                </p>
              </AlertDescription>
            </Alert>

            {/* 新增：总体风险解读模块 - 添加唯一ID */}
            <Card id="section-risk" className="mb-6 border-2 border-primary/20">
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <span>风险程度分析</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 ml-auto"
                    onClick={() => handlePlaySection('risk')}
                    data-section-id="risk"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-foreground leading-relaxed">
                  <p>
                    基于您完成的 <span className="font-bold text-primary">{completedResults.length}</span> 个量表，
                    当前结果显示为 <span className={`font-bold ${
                      overallRisk === 'high' ? 'text-destructive' :
                      overallRisk === 'medium' ? 'text-orange-600 dark:text-orange-400' :
                      'text-secondary'
                    }`}>
                      {overallRisk === 'high' ? '高风险' : overallRisk === 'medium' ? '中风险' : '低风险'}
                    </span> 水平。
                  </p>
                  <p className="text-sm">
                    {overallRisk === 'high' && '评估结果提示在多个认知领域存在明确的变化迹象，这些变化可能影响日常生活功能。建议引起高度重视，及时寻求专业医疗机构的进一步评估和指导。早期干预对于延缓认知功能下降具有重要意义。'}
                    {overallRisk === 'medium' && '评估结果提示在某些认知领域存在轻度变化迹象，虽然目前可能对日常生活影响较小，但仍需要关注。建议定期复查，保持健康的生活方式，必要时咨询专业医生。'}
                    {overallRisk === 'low' && '评估结果显示您的认知功能处于良好状态，各项指标均在正常范围内。建议继续保持健康的生活方式，包括规律作息、均衡饮食、适度运动和积极的社交活动，以维持良好的认知功能。'}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* 已完成量表列表 */}
            <div className="space-y-4 mb-6">
              <h3 className="font-semibold text-lg mb-4">已完成量表列表</h3>
              {scaleResultsWithRisk.map((result) => (
                <Card key={result.scaleId} className="border-2">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-base">{result.scaleName}</h4>
                          <span className="text-xs text-muted-foreground">
                            {formatDateTime(result.completedAt)}
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-2xl font-bold text-primary">{result.score} 分</span>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            result.riskLevel === 'high'
                              ? 'bg-destructive/10 text-destructive'
                              : result.riskLevel === 'medium'
                              ? 'bg-orange-100 text-orange-700 dark:bg-orange-950/30 dark:text-orange-400'
                              : 'bg-secondary/10 text-secondary'
                          }`}>
                            {result.riskText}
                          </span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigateWithStopVoice(`/question/${result.scaleId}/1`)}
                      >
                        重新测试
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* 新增：核心发现总结模块 - 添加唯一ID */}
            <Card id="section-findings" className="mb-6 border-2 border-primary/20">
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                  <span>核心发现</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 ml-auto"
                    onClick={() => handlePlaySection('findings')}
                    data-section-id="findings"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {keyFindings.map((finding, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <span className="text-primary mt-1 font-bold">•</span>
                      <p className="text-sm text-foreground leading-relaxed flex-1">
                        {finding.split('**').map((part, i) => 
                          i % 2 === 1 ? <strong key={i} className="font-semibold text-foreground">{part}</strong> : part
                        )}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 分领域解读 - 添加唯一ID */}
            <div id="section-domains" className="space-y-4 mb-6">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <span>分领域解读</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => handlePlaySection('domains')}
                  data-section-id="domains"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {domainAnalysis.map((domain) => {
                  const Icon = domain.icon;
                  return (
                    <Card 
                      key={domain.name}
                      id={`section-domain-${domain.name}`}
                      className={`border-2 ${
                        domain.status === 'concern' 
                          ? 'border-destructive/30 bg-destructive/5'
                          : domain.status === 'attention'
                          ? 'border-orange-300/50 bg-orange-50/50 dark:bg-orange-950/10'
                          : domain.status === 'good'
                          ? 'border-secondary/30 bg-secondary/5'
                          : 'border-muted bg-muted/20'
                      }`}
                    >
                      <CardContent className="pt-6">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${
                            domain.status === 'concern'
                              ? 'bg-destructive/10'
                              : domain.status === 'attention'
                              ? 'bg-orange-100 dark:bg-orange-950/30'
                              : domain.status === 'good'
                              ? 'bg-secondary/10'
                              : 'bg-muted'
                          }`}>
                            <Icon className={`h-5 w-5 ${
                              domain.status === 'concern'
                                ? 'text-destructive'
                                : domain.status === 'attention'
                                ? 'text-orange-600 dark:text-orange-400'
                                : domain.status === 'good'
                                ? 'text-secondary'
                                : 'text-muted-foreground'
                            }`} />
                          </div>
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-semibold text-base mb-1">{domain.name}</h4>
                                <p className="text-xs text-muted-foreground">{domain.description}</p>
                              </div>
                              {domain.status !== 'not_tested' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 shrink-0"
                                  onClick={() => handlePlaySection(`domain_${domain.name}`)}
                                  data-section-id={`domain_${domain.name}`}
                                >
                                  <Volume2 className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                            
                            {domain.status !== 'not_tested' && (
                              <>
                                {/* 状态小结 */}
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">状态：</span>
                                  <span className={`text-sm font-semibold ${
                                    domain.status === 'concern' ? 'text-destructive' :
                                    domain.status === 'attention' ? 'text-orange-600 dark:text-orange-400' :
                                    'text-secondary'
                                  }`}>
                                    {domain.statusText}
                                  </span>
                                  <span className="text-xs text-muted-foreground">
                                    （已测试 {domain.testedCount} 个相关量表）
                                  </span>
                                </div>

                                {/* 具体表现 */}
                                {domain.specificFindings && (
                                  <div className="bg-muted/30 rounded-md p-3">
                                    <p className="text-xs font-medium text-muted-foreground mb-1">具体表现：</p>
                                    <p className="text-sm text-foreground leading-relaxed">
                                      {domain.specificFindings}
                                    </p>
                                  </div>
                                )}

                                {/* 生活建议 */}
                                {domain.lifeSuggestion && (
                                  <div className="bg-primary/5 rounded-md p-3">
                                    <p className="text-xs font-medium text-primary mb-1 flex items-center gap-1">
                                      <Lightbulb className="h-3 w-3" />
                                      生活建议：
                                    </p>
                                    <p className="text-sm text-foreground leading-relaxed">
                                      {domain.lifeSuggestion}
                                    </p>
                                  </div>
                                )}
                              </>
                            )}
                            
                            {domain.status === 'not_tested' && (
                              <p className="text-sm text-muted-foreground">{domain.comment}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* 新增：行动建议模块 - 添加唯一ID */}
            <Card id="section-action" className="mt-6 border-2 border-primary/30 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <span>后续步骤建议</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 ml-auto"
                    onClick={() => handlePlaySection('action')}
                    data-section-id="action"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {overallRisk === 'high' ? (
                    <>
                      <div className="bg-destructive/10 border-l-4 border-destructive rounded-r-lg p-4">
                        <p className="font-semibold text-destructive mb-2">🚨 建议尽快就医</p>
                        <p className="text-sm text-foreground leading-relaxed">
                          评估结果提示需要专业医疗评估。建议携带本报告，尽快预约<strong>神经内科</strong>、
                          <strong>记忆门诊</strong>或<strong>老年精神科</strong>进行全面检查。
                          早期诊断和干预对于延缓病情进展具有重要意义。
                        </p>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p className="font-medium text-foreground">具体行动步骤：</p>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">1.</span>
                            <span className="text-foreground">
                              <strong>预约就医</strong>：联系当地三甲医院的神经内科或记忆门诊，说明情况并预约专家号
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">2.</span>
                            <span className="text-foreground">
                              <strong>准备资料</strong>：打印或保存本报告，记录近期认知变化的具体表现和时间
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">3.</span>
                            <span className="text-foreground">
                              <strong>家属陪同</strong>：建议由家属陪同就医，便于向医生提供更全面的信息
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">4.</span>
                            <span className="text-foreground">
                              <strong>日常管理</strong>：在等待就医期间，保持规律作息，确保用药安全，避免独自外出
                            </span>
                          </li>
                        </ul>
                      </div>
                    </>
                  ) : overallRisk === 'medium' ? (
                    <>
                      <div className="bg-orange-100 dark:bg-orange-950/30 border-l-4 border-orange-500 rounded-r-lg p-4">
                        <p className="font-semibold text-orange-700 dark:text-orange-400 mb-2">⚠️ 建议关注并复查</p>
                        <p className="text-sm text-foreground leading-relaxed">
                          评估结果提示存在轻度异常。建议在<strong>3-6个月内</strong>复查，并考虑咨询
                          <strong>社区健康中心</strong>或<strong>全科医生</strong>进行进一步了解。
                          定期监测有助于及时发现变化。
                        </p>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p className="font-medium text-foreground">具体行动步骤：</p>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">1.</span>
                            <span className="text-foreground">
                              <strong>定期复查</strong>：建议3-6个月后重新进行评估，观察变化趋势
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">2.</span>
                            <span className="text-foreground">
                              <strong>咨询医生</strong>：可先咨询社区健康中心或全科医生，了解是否需要进一步检查
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">3.</span>
                            <span className="text-foreground">
                              <strong>生活调整</strong>：保持规律作息，均衡饮食，每周至少150分钟中等强度运动
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">4.</span>
                            <span className="text-foreground">
                              <strong>认知训练</strong>：进行针对性的认知训练，如记忆游戏、阅读、学习新技能等
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">5.</span>
                            <span className="text-foreground">
                              <strong>记录变化</strong>：记录日常认知表现，如有明显变化应及时就医
                            </span>
                          </li>
                        </ul>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-secondary/10 border-l-4 border-secondary rounded-r-lg p-4">
                        <p className="font-semibold text-secondary mb-2">✅ 保持良好状态</p>
                        <p className="text-sm text-foreground leading-relaxed">
                          评估结果显示认知功能良好。建议保持健康的生活方式，
                          <strong>6-12个月后</strong>重新评估。继续保持当前的良好习惯，
                          有助于维持认知功能的健康状态。
                        </p>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p className="font-medium text-foreground">具体行动步骤：</p>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">1.</span>
                            <span className="text-foreground">
                              <strong>定期评估</strong>：建议6-12个月后重新进行评估，持续监测认知健康
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">2.</span>
                            <span className="text-foreground">
                              <strong>健康生活</strong>：保持规律作息、均衡饮食、适度运动、充足睡眠
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">3.</span>
                            <span className="text-foreground">
                              <strong>社交活动</strong>：积极参与社交活动，保持与家人朋友的联系
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">4.</span>
                            <span className="text-foreground">
                              <strong>脑力活动</strong>：持续进行脑力活动，如阅读、学习、益智游戏等
                            </span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary mt-1 font-bold">5.</span>
                            <span className="text-foreground">
                              <strong>慢性病管理</strong>：控制好血压、血糖、血脂等慢性疾病，定期体检
                            </span>
                          </li>
                        </ul>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* 医学报告上传模块 */}
            <div className="mt-6">
              <MedicalReportUpload />
            </div>

            {/* 操作按钮 */}
            <div className="flex flex-col sm:flex-row gap-3 mt-6">
              <Button
                onClick={() => navigateWithStopVoice('/scales')}
                className="flex-1 gap-2"
              >
                继续测试其他量表
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  stopAnySpeech();
                  refreshData();
                  console.log('手动刷新综合报告数据');
                }}
                className="flex-1 gap-2"
              >
                <FileText className="h-4 w-4" />
                刷新报告
              </Button>
              <Button
                variant="outline"
                onClick={() => navigateWithStopVoice('/')}
                className="flex-1 gap-2"
              >
                <Home className="h-4 w-4" />
                返回首页
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-6">
        <div className="container mx-auto px-4 max-w-4xl">
          <p className="text-xs text-muted-foreground text-center">
            免责声明：本工具仅供参考，不能替代专业医疗诊断。如有疑虑，请及时就医咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

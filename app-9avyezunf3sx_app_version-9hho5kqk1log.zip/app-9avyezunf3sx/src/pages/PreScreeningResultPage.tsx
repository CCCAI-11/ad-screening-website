import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

export default function PreScreeningResultPage() {
  const navigate = useNavigate();
  const { screeningData } = useScreening();
  const [yesCount, setYesCount] = useState(0);

  useEffect(() => {
    // 计算回答"是"的数量
    const count = screeningData.preScreening.filter(a => a.answer === 'yes').length;
    setYesCount(count);
  }, [screeningData.preScreening]);

  // 根据"是"的数量确定风险等级和建议
  const getRiskLevel = () => {
    if (yesCount >= 3) {
      return {
        level: 'high',
        title: '建议进一步评估',
        description: '您的初步筛查结果显示可能存在认知风险，建议继续完成后续的专业量表进行详细评估。',
        icon: <AlertCircle className="h-16 w-16 text-destructive" />,
        bgColor: 'bg-destructive/5',
        borderColor: 'border-destructive/50'
      };
    } else if (yesCount >= 1) {
      return {
        level: 'medium',
        title: '建议保持关注',
        description: '您的初步筛查结果提示有轻微变化，建议完成后续评估以获取更全面的了解，并可在3-6个月后重新筛查。',
        icon: <AlertTriangle className="h-16 w-16 text-warning" />,
        bgColor: 'bg-warning/5',
        borderColor: 'border-warning/50'
      };
    } else {
      return {
        level: 'low',
        title: '当前风险较低',
        description: '您的初步筛查结果未发现明显异常。您可以选择继续了解其他认知领域，或随时回来复查。',
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        bgColor: 'bg-green-50',
        borderColor: 'border-green-200'
      };
    }
  };

  const riskInfo = getRiskLevel();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 顶部标题 */}
      <header className="border-b bg-card py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-center text-primary">
            初步评估结果
          </h1>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8 flex items-center justify-center">
        <div className="w-full max-w-2xl">
          {/* 结果卡片 */}
          <Card className={`shadow-xl border-2 ${riskInfo.borderColor} ${riskInfo.bgColor} mb-8`}>
            <CardHeader>
              <div className="flex flex-col items-center text-center mb-4">
                {riskInfo.icon}
                <CardTitle className="text-2xl md:text-3xl font-bold mt-4">
                  {riskInfo.title}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <Alert className={`${riskInfo.bgColor} border-2 ${riskInfo.borderColor}`}>
                <AlertDescription className="text-base md:text-lg leading-relaxed text-center">
                  {riskInfo.description}
                </AlertDescription>
              </Alert>

              {/* 统计信息 */}
              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <p className="text-center text-sm text-muted-foreground">
                  您在5道预筛题中回答了 <span className="font-bold text-primary text-lg">{yesCount}</span> 个"是"
                </p>
              </div>
            </CardContent>
          </Card>

          {/* 引导文案 */}
          <div className="text-center mb-6">
            <p className="text-lg md:text-xl font-semibold text-foreground">
              完成详细评估，获取更精准的个人分析报告。
            </p>
          </div>

          {/* 主要操作按钮 - 继续详细评估 */}
          <div className="flex justify-center mb-8">
            <Button
              size="lg"
              onClick={() => navigate('/scales')}
              className="gap-2 text-xl px-12 py-8 bg-primary hover:bg-primary/90 shadow-lg"
            >
              继续详细评估
              <ArrowRight className="h-6 w-6" />
            </Button>
          </div>

          {/* 次要操作 - 返回首页 */}
          <div className="flex justify-center mt-12">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-foreground"
            >
              返回首页
            </Button>
          </div>
        </div>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-4">
        <div className="container mx-auto px-4">
          <p className="text-xs text-center text-muted-foreground">
            免责声明：本工具仅供初步筛查参考，不能替代专业医学诊断。如有疑虑，请及时咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

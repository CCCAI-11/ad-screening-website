import { useState, useEffect } from 'react';
import { Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { safeSpeak, initAudioContext } from '@/utils/voice';

interface AudioButtonProps {
  text: string;
  className?: string;
  label?: string; // 可选的按钮文字标签
}

export function AudioButton({ text, className = '', label = '听问题' }: AudioButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isTouched, setIsTouched] = useState(false); // 触摸反馈状态

  // 组件挂载时初始化音频上下文
  useEffect(() => {
    // 监听首次用户交互
    const handleFirstInteraction = () => {
      initAudioContext();
      // 移除监听器
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('touchstart', handleFirstInteraction);
    };

    document.addEventListener('click', handleFirstInteraction, { once: true });
    document.addEventListener('touchstart', handleFirstInteraction, { once: true });

    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, []);

  const handlePlay = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation(); // 防止触发父元素的点击事件
    
    // 初始化音频上下文（移动端必需）
    initAudioContext();

    if (isPlaying) {
      console.log('已在播放，忽略点击');
      return;
    }

    try {
      setIsPlaying(true);
      
      // 使用安全的语音播报函数
      const utterance = safeSpeak(text, {
        onEnd: () => {
          console.log('AudioButton: 播报结束');
          setIsPlaying(false);
        },
        onError: (error) => {
          console.error('AudioButton: 播报失败', error);
          setIsPlaying(false);
          // 显示友好的错误提示
          alert('播报失败，请稍后再试');
        }
      });
      
      if (!utterance) {
        console.error('AudioButton: 创建语音实例失败');
        setIsPlaying(false);
        alert('播报失败，请稍后再试');
      }
    } catch (error) {
      console.error('AudioButton: 语音播放失败:', error);
      setIsPlaying(false);
      alert('播报失败，请稍后再试');
    }
  };

  // 触摸开始事件（移动端触摸反馈）
  const handleTouchStart = () => {
    setIsTouched(true);
  };

  // 触摸结束事件
  const handleTouchEnd = () => {
    setIsTouched(false);
  };

  return (
    <Button
      type="button"
      variant="ghost"
      size="lg"
      onClick={handlePlay}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      disabled={isPlaying}
      className={`gap-2 px-4 py-3 h-auto hover:bg-primary/10 active:bg-primary/20 transition-all ${
        isTouched ? 'bg-primary/20 scale-95' : ''
      } ${className}`}
      aria-label={label}
    >
      <Volume2 
        className={`h-10 w-10 transition-all ${
          isPlaying ? 'text-primary animate-pulse' : 'text-primary'
        }`} 
      />
      <span className="text-base font-medium text-foreground">{label}</span>
    </Button>
  );
}

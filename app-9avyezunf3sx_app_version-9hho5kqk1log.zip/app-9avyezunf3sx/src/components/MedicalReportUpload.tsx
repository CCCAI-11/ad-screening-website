import { useState, useRef, DragEvent, ChangeEvent, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Upload, X, Image as ImageIcon, AlertCircle, CheckCircle2, Clock, Stethoscope, Trash2 } from 'lucide-react';
import {
  MedicalReportSubmission,
  MEDICAL_REPORT_STORAGE_KEY,
  MAX_FILE_SIZE,
  ALLOWED_FILE_TYPES,
  REPORT_STATUS_LABELS,
  REPORT_STATUS_COLORS
} from '@/types/medicalReport';
import { safeGetItem, safeSetItem, getLocalStorageUsage } from '@/utils/localStorage';

export default function MedicalReportUpload() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [submissions, setSubmissions] = useState<MedicalReportSubmission[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 从localStorage加载历史记录
  const loadSubmissions = () => {
    try {
      const stored = safeGetItem(MEDICAL_REPORT_STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored) as MedicalReportSubmission[];
        setSubmissions(data.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
      }
    } catch (error) {
      console.error('加载历史记录失败:', error);
    }
  };

  // 组件挂载时加载历史记录
  useEffect(() => {
    loadSubmissions();
  }, []);

  // 保存到localStorage
  const saveSubmission = (submission: MedicalReportSubmission) => {
    try {
      // 检查存储空间使用情况
      const usage = getLocalStorageUsage();
      console.log(`localStorage使用情况: ${usage.percentage.toFixed(2)}%`);
      
      if (usage.percentage > 80) {
        alert('存储空间即将用尽（已使用' + usage.percentage.toFixed(0) + '%），建议删除部分历史记录');
      }
      
      const stored = safeGetItem(MEDICAL_REPORT_STORAGE_KEY);
      const existing = stored ? JSON.parse(stored) as MedicalReportSubmission[] : [];
      const updated = [submission, ...existing];
      
      const success = safeSetItem(MEDICAL_REPORT_STORAGE_KEY, JSON.stringify(updated));
      if (success) {
        setSubmissions(updated);
      } else {
        throw new Error('保存失败');
      }
    } catch (error) {
      console.error('保存失败:', error);
      alert('保存失败，可能是存储空间不足。请尝试上传更小的图片或删除部分历史记录。');
    }
  };

  // 验证文件
  const validateFile = (file: File): string | null => {
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      return '仅支持 JPG 和 PNG 格式的图片';
    }
    if (file.size > MAX_FILE_SIZE) {
      return `图片大小不能超过 ${MAX_FILE_SIZE / 1024 / 1024}MB`;
    }
    return null;
  };

  // 将文件转换为Base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // 处理文件选择
  const handleFileSelect = async (file: File) => {
    const error = validateFile(file);
    if (error) {
      alert(error);
      return;
    }

    try {
      const base64 = await fileToBase64(file);
      setSelectedImage(base64);
    } catch (error) {
      console.error('读取文件失败:', error);
      alert('读取文件失败，请重试');
    }
  };

  // 点击上传
  const handleClick = () => {
    fileInputRef.current?.click();
  };

  // 文件输入变化
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  // 拖放事件
  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  // 删除选中的图片
  const handleRemoveImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 提交报告
  const handleSubmit = async () => {
    if (!selectedImage) {
      alert('请先上传图片');
      return;
    }

    setIsUploading(true);

    try {
      // 获取用户ID（从localStorage的user_info中获取）
      const userInfoStr = safeGetItem('user_info');
      const userInfo = userInfoStr ? JSON.parse(userInfoStr) : {};
      const userId = userInfo.gender || 'anonymous'; // 使用性别作为简单标识

      // 生成唯一ID
      const id = `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // 创建提交记录
      const submission: MedicalReportSubmission = {
        id,
        userId,
        imageBase64: selectedImage,
        description: description.trim(),
        timestamp: new Date().toISOString(),
        status: 'pending',
        doctorConclusion: ''
      };

      // 保存到localStorage
      saveSubmission(submission);

      // 清空表单
      setSelectedImage(null);
      setDescription('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      alert('上传成功！已加入医生处理队列。');
    } catch (error) {
      console.error('提交失败:', error);
      alert('提交失败，请重试');
    } finally {
      setIsUploading(false);
    }
  };

  // 撤回申请
  const handleWithdraw = (id: string) => {
    // 弹出确认框
    const confirmed = window.confirm(
      '确定要撤回此申请吗？撤回后医生将无法查看您上传的资料。'
    );

    if (!confirmed) {
      return;
    }

    try {
      // 从localStorage中删除
      const stored = safeGetItem(MEDICAL_REPORT_STORAGE_KEY);
      if (stored) {
        const existing = JSON.parse(stored) as MedicalReportSubmission[];
        const updated = existing.filter(item => item.id !== id);
        safeSetItem(MEDICAL_REPORT_STORAGE_KEY, JSON.stringify(updated));
        
        // 更新状态
        setSubmissions(updated);
        
        alert('申请已撤回');
      }
    } catch (error) {
      console.error('撤回失败:', error);
      alert('撤回失败，请重试');
    }
  };

  // 格式化时间
  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="shadow-xl border-2 bg-gradient-to-br from-blue-50/80 to-green-50/80 dark:from-blue-950/20 dark:to-green-950/20">
      <CardHeader className="pb-4">
        <CardTitle className="text-3xl font-bold flex items-center gap-3 text-[#2c5e9e] dark:text-blue-400">
          <Stethoscope className="h-8 w-8" />
          申请医生分析
        </CardTitle>
        <p className="text-sm text-muted-foreground mt-2 font-medium">
          上传报告，获取医生建议
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* 功能说明 */}
        <Alert className="border-l-4 border-l-blue-500 bg-blue-50/50 dark:bg-blue-950/20">
          <AlertDescription className="space-y-3 text-sm">
            <p className="text-foreground">
              您可以上传脑部CT、MRI或认知评估报告等医学影像图片，我们的合作医生将为您提供专业分析。分析结论将在24-48小时内给出，请您耐心等待。
            </p>
            <div className="bg-orange-50 dark:bg-orange-950/30 border-l-4 border-l-orange-500 p-3 rounded">
              <p className="text-orange-700 dark:text-orange-400 font-bold flex items-start gap-2">
                <AlertCircle className="h-5 w-5 mt-0.5 shrink-0" />
                <span>重要提示：此服务为远程初步咨询，不能替代线下面对面诊疗。紧急情况请立即就医。</span>
              </p>
            </div>
          </AlertDescription>
        </Alert>

        {/* 新报告上传区 */}
        <div className="space-y-4 bg-white/60 dark:bg-gray-900/30 p-6 rounded-lg border-2 border-dashed border-primary/30">
          <h3 className="text-xl font-bold text-primary flex items-center gap-2">
            <Upload className="h-5 w-5" />
            上传新报告
          </h3>

          {/* 图片上传区域 */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">
              医学影像或报告图片 <span className="text-destructive">*</span>
            </Label>
            
            {!selectedImage ? (
              <div
                onClick={handleClick}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`
                  border-3 border-dashed rounded-xl p-10 text-center cursor-pointer
                  transition-all duration-300 shadow-sm
                  ${isDragging 
                    ? 'border-primary bg-primary/10 scale-[1.02] shadow-lg' 
                    : 'border-border hover:border-primary hover:bg-accent/50 hover:shadow-md'
                  }
                `}
              >
                <Upload className="h-16 w-16 mx-auto mb-4 text-primary" />
                <p className="text-base font-semibold mb-2 text-foreground">点击上传或拖放图片到此处</p>
                <p className="text-sm text-muted-foreground">
                  支持 JPG、PNG 格式，单张图片不超过 5MB
                </p>
              </div>
            ) : (
              <div className="relative border-2 rounded-xl p-4 bg-accent/30 shadow-md">
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8 shadow-lg"
                  onClick={handleRemoveImage}
                >
                  <X className="h-4 w-4" />
                </Button>
                <img
                  src={selectedImage}
                  alt="预览"
                  className="max-h-64 mx-auto rounded-lg shadow-md"
                />
                <p className="text-xs text-center text-muted-foreground mt-3 font-medium">
                  图片预览
                </p>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept=".jpg,.jpeg,.png"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* 症状描述 */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-base font-semibold">
              请补充说明您的症状或主要关切（选填）
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="例如：近期记忆力下降明显，经常忘记刚说过的话..."
              className="min-h-28 resize-none text-base border-2 focus:border-primary"
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right font-medium">
              {description.length}/500
            </p>
          </div>

          {/* 提交按钮 */}
          <Button
            onClick={handleSubmit}
            disabled={!selectedImage || isUploading}
            className="w-full h-12 text-base font-semibold shadow-lg hover:shadow-xl transition-all"
            size="lg"
          >
            {isUploading ? (
              <>
                <Clock className="h-5 w-5 mr-2 animate-spin" />
                上传中...
              </>
            ) : (
              <>
                <CheckCircle2 className="h-5 w-5 mr-2" />
                提交申请
              </>
            )}
          </Button>
        </div>

        {/* 历史记录与状态追踪区 */}
        <div className="space-y-4 pt-8 border-t-4 border-primary/20">
          <div className="flex items-center gap-3">
            <div className="h-1 w-12 bg-primary rounded-full"></div>
            <h3 className="text-xl font-bold text-primary">我的申请记录</h3>
            <div className="h-1 flex-1 bg-primary/20 rounded-full"></div>
          </div>

          {submissions.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white/40 dark:bg-gray-900/20 rounded-lg border-2 border-dashed">
              <ImageIcon className="h-16 w-16 mx-auto mb-4 opacity-40" />
              <p className="text-lg font-semibold">暂无申请记录</p>
              <p className="text-sm mt-2">上传您的第一份报告吧</p>
            </div>
          ) : (
            <div className="space-y-4">
              {submissions.map((submission) => (
                <Card key={submission.id} className="overflow-hidden shadow-md hover:shadow-lg transition-shadow border-2">
                  <CardContent className="p-5">
                    <div className="flex gap-4">
                      {/* 图片缩略图 */}
                      <div className="shrink-0">
                        <img
                          src={submission.imageBase64}
                          alt="报告缩略图"
                          className="w-24 h-24 object-cover rounded-lg border-2 shadow-sm"
                        />
                      </div>

                      {/* 信息区域 */}
                      <div className="flex-1 min-w-0 space-y-2">
                        {/* 时间和状态 */}
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-sm text-muted-foreground font-medium">
                            {formatTime(submission.timestamp)}
                          </span>
                          <div className="flex items-center gap-2">
                            <Badge className={`${REPORT_STATUS_COLORS[submission.status]} font-semibold px-3 py-1`}>
                              {REPORT_STATUS_LABELS[submission.status]}
                            </Badge>
                            {/* 撤回按钮 - 仅待处理状态显示 */}
                            {submission.status === 'pending' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleWithdraw(submission.id)}
                                className="h-7 text-xs gap-1 border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                              >
                                <Trash2 className="h-3 w-3" />
                                撤回
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* 描述 */}
                        {submission.description && (
                          <p className="text-sm text-foreground line-clamp-2 bg-accent/30 p-2 rounded">
                            {submission.description}
                          </p>
                        )}

                        {/* 医生结论 */}
                        <div className="text-sm bg-blue-50/50 dark:bg-blue-950/20 p-3 rounded-lg border-l-4 border-l-blue-500">
                          <span className="font-bold text-foreground">医生结论：</span>
                          <span className="text-muted-foreground ml-2">
                            {submission.status === 'pending' 
                              ? '等待医生分析...' 
                              : submission.doctorConclusion || '暂无结论'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

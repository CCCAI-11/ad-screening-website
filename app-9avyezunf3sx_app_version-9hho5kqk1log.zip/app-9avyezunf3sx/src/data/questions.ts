import type { Question } from '@/types/screening';

// AD-8量表问题数据
export const ad8Questions: Question[] = [
  {
    id: 1,
    text: '判断力上的困难：例如落入圈套或骗局、财务上不好的决定、买了对受礼者不合宜的礼物。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 2,
    text: '对活动和嗜好的兴趣降低。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 3,
    text: '重复相同问题、故事和陈述。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 4,
    text: '在学习如何使用工具、设备和小器具上有困难。例如：电视、音响、冷气机、洗衣机、热水炉（器）、微波炉、遥控器。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 5,
    text: '忘记正确的月份和年份。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 6,
    text: '处理复杂的财务上有困难。例如：个人或家庭的收支平衡、所得税、缴费单。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 7,
    text: '记住约会的时间有困难。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  },
  {
    id: 8,
    text: '有持续的思考和记忆方面的问题。',
    options: [
      { value: 'none', label: '没有', score: 0 },
      { value: 'sometimes', label: '偶尔', score: 0 },
      { value: 'often', label: '经常', score: 1 },
      { value: 'always', label: '总是', score: 1 }
    ]
  }
];

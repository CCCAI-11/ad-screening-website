// 医学报告提交记录类型定义

export interface MedicalReportSubmission {
  id: string;                    // 唯一ID
  userId: string;                // 用户ID
  imageBase64: string;           // 图片Base64数据
  description: string;           // 症状描述
  timestamp: string;             // 提交时间（ISO格式）
  status: 'pending' | 'analyzed'; // 状态：待处理 | 已分析
  doctorConclusion: string;      // 医生结论（第一阶段留空）
}

export type ReportStatus = 'pending' | 'analyzed';

export const REPORT_STATUS_LABELS: Record<ReportStatus, string> = {
  pending: '待处理',
  analyzed: '已分析'
};

export const REPORT_STATUS_COLORS: Record<ReportStatus, string> = {
  pending: 'bg-muted text-muted-foreground',
  analyzed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100'
};

// localStorage键名
export const MEDICAL_REPORT_STORAGE_KEY = 'medical_report_submissions';

// 文件上传限制
export const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
export const ALLOWED_FILE_TYPES = ['image/jpeg', 'image/jpg', 'image/png'];
export const ALLOWED_FILE_EXTENSIONS = ['.jpg', '.jpeg', '.png'];

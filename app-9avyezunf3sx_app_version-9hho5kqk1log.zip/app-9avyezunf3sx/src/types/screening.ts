// 筛查数据类型定义

// 用户信息（可选，在结果页填写）
export interface UserInfo {
  name: string;
  age: string;
  contact: string; // 手机或邮箱
}

// 快速预筛答案
export interface PreScreeningAnswer {
  questionId: number;
  answer: 'yes' | 'no' | '';
}

// 量表类型
export type ScaleType = 'ad8' | 'cdt' | 'mmse' | 'moca' | 'adl';

// 量表答案（通用）
export interface ScaleAnswer {
  questionId: number;
  answer: string; // 不同量表的答案格式不同
  score: number;
}

// 量表结果（包含完成时间和总分）
export interface ScaleResult {
  scaleId: ScaleType;
  scaleName: string;
  score: number;
  completedAt: Date;
  answers: ScaleAnswer[];
}

// 筛查数据
export interface ScreeningData {
  preScreening: PreScreeningAnswer[]; // 快速预筛答案
  selectedScale: ScaleType | null; // 选择的量表
  scaleAnswers: Record<ScaleType, ScaleAnswer[]>; // 各量表的答案
  scaleResults: ScaleResult[]; // 已完成的量表结果（包含完成时间）
  userInfo: UserInfo | null; // 用户信息（可选）
  completedAt?: Date;
}

// 快速预筛问题
export interface PreScreeningQuestion {
  id: number;
  text: string;
  options: {
    value: 'yes' | 'no';
    label: string;
  }[];
}

// 量表信息
export interface ScaleInfo {
  id: ScaleType;
  name: string;
  description: string;
  questionCount: number;
  estimatedTime: string;
}

// 量表问题（通用）
export interface ScaleQuestion {
  id: number;
  text: string;
  type?: 'radio' | 'year' | 'season' | 'month' | 'day' | 'weekday' | 'instruction' | 'memory_input' | 'number_input' | 'text_input' | 'memory_recall'; // 题目类型
  options: {
    value: string;
    label: string;
    score: number;
  }[];
  autoScore?: boolean; // 是否自动计分
  instructionText?: string; // 指导语文本（用于instruction类型）
  imageUrl?: string; // 图片URL（用于语言能力题目）
  correctAnswers?: string[]; // 正确答案列表（用于记忆力题目）
  inputCount?: number; // 输入框数量（用于多输入框题目）
  distractors?: string[]; // 干扰词列表（用于memory_recall类型）
}

// AD-8量表问题（保持兼容）
export interface Question {
  id: number;
  text: string;
  options: {
    value: 'none' | 'sometimes' | 'often' | 'always';
    label: string;
    score: number;
  }[];
}

// 通用答案类型（向后兼容）
export interface QuestionAnswer {
  questionId: number;
  answer: 'none' | 'sometimes' | 'often' | 'always' | '';
  score: number;
}

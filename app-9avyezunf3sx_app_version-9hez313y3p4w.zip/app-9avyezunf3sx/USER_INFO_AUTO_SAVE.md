# 信息收集页面自动保存与首页导航功能说明

## 功能概述

为"请填写基本信息"页面增加表单自动保存功能和返回首页导航按钮，提升用户体验，避免用户因页面意外关闭或离开而需重复填写的困扰。

## 功能特性

### 一、表单自动保存功能

#### 1. 保存机制
- 为所有表单字段绑定变更（change）事件
- 字段包括：
  - 性别（单选按钮）
  - 年龄区间（下拉框）
  - 省份（下拉框）
  - 城市（下拉框）

#### 2. 实时保存
- 每当任何一个字段的值发生变化时，立即自动保存
- 保存所有字段的当前值到localStorage
- 使用专用键名：`user_info_draft`（草稿数据）
- 存储格式：JSON格式

#### 3. 数据恢复
- 页面加载时（useEffect）自动检查localStorage
- 如果存在草稿数据，自动填充到对应的表单字段
- 还原用户上次的填写状态
- 控制台输出："已恢复草稿数据"

#### 4. 数据隔离
- **草稿数据**：`user_info_draft`（自动保存的临时数据）
- **正式数据**：`user_info`（提交后保存的最终数据）
- 两者独立存储，互不影响

#### 5. 提交后清空
- 用户成功点击"提交并继续"按钮后
- 自动清空`user_info_draft`中保存的草稿数据
- 避免下次进入页面时错误恢复旧数据
- 控制台输出："草稿数据已清空"

### 二、返回首页导航按钮

#### 1. 按钮位置
- 位于"提交并继续"按钮的下方
- 与提交按钮垂直排列
- 间距：space-y-3

#### 2. 按钮样式
- 变体：outline（次要按钮样式）
- 高度：h-12（与提交按钮一致）
- 宽度：w-full（全宽）
- 字号：text-base
- 图标：Home（房子图标，5x5）
- 文字："返回首页"
- 间距：gap-2

#### 3. 按钮功能
- 点击后跳转到网站首页（路径：/）
- 使用React Router的navigate函数
- 不会清空草稿数据（用户可以稍后返回继续填写）

#### 4. 视觉区分
- 使用outline样式，与主要的"提交并继续"按钮有所区分
- 但依然清晰可辨，易于点击

## 技术实现

### 文件修改
- `src/pages/UserInfoPage.tsx` - 信息收集页面

### 核心代码

#### 1. localStorage键名常量
```typescript
// localStorage键名
const USER_INFO_DRAFT_KEY = 'user_info_draft'; // 草稿数据
const USER_INFO_KEY = 'user_info'; // 正式数据
```

#### 2. 页面加载时恢复草稿数据
```typescript
// 页面加载时恢复草稿数据
useEffect(() => {
  try {
    const draftData = localStorage.getItem(USER_INFO_DRAFT_KEY);
    if (draftData) {
      const parsed = JSON.parse(draftData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已恢复草稿数据:', parsed);
    }
  } catch (error) {
    console.error('恢复草稿数据失败:', error);
  }
}, []);
```

#### 3. 自动保存草稿数据函数
```typescript
// 自动保存草稿数据
const saveDraft = (data: UserBasicInfo) => {
  try {
    localStorage.setItem(USER_INFO_DRAFT_KEY, JSON.stringify(data));
    console.log('草稿已自动保存:', data);
  } catch (error) {
    console.error('保存草稿失败:', error);
  }
};
```

#### 4. 字段变化处理函数
```typescript
// 处理性别变化
const handleGenderChange = (gender: string) => {
  const newUserInfo = {
    ...userInfo,
    gender
  };
  setUserInfo(newUserInfo);
  saveDraft(newUserInfo); // 自动保存草稿
};

// 处理年龄区间变化
const handleAgeRangeChange = (ageRange: string) => {
  const newUserInfo = {
    ...userInfo,
    ageRange
  };
  setUserInfo(newUserInfo);
  saveDraft(newUserInfo); // 自动保存草稿
};

// 处理省份变化
const handleProvinceChange = (province: string) => {
  const newUserInfo = {
    ...userInfo,
    province,
    city: '' // 重置城市选择
  };
  setUserInfo(newUserInfo);
  saveDraft(newUserInfo); // 自动保存草稿
};

// 处理城市变化
const handleCityChange = (city: string) => {
  const newUserInfo = {
    ...userInfo,
    city
  };
  setUserInfo(newUserInfo);
  saveDraft(newUserInfo); // 自动保存草稿
};
```

#### 5. 自动定位后保存草稿
```typescript
// 同时填充省份和城市
const newUserInfo = {
  ...userInfo,
  province,
  city
};
setUserInfo(newUserInfo);
saveDraft(newUserInfo); // 自动保存草稿
```

#### 6. 提交后清空草稿
```typescript
const handleSubmit = () => {
  // ... 验证逻辑 ...

  // 保存到localStorage（正式数据）
  const dataToSave = {
    ...userInfo,
    filledDate: new Date().toISOString()
  };
  localStorage.setItem(USER_INFO_KEY, JSON.stringify(dataToSave));
  console.log('用户信息已保存:', dataToSave);

  // 清空草稿数据
  localStorage.removeItem(USER_INFO_DRAFT_KEY);
  console.log('草稿数据已清空');

  // 跳转到预筛选页面
  navigate('/pre-screening/1');
};
```

#### 7. 表单字段绑定
```typescript
{/* 性别选择 */}
<RadioGroup
  value={userInfo.gender}
  onValueChange={handleGenderChange}
  className="flex gap-6"
>
  {/* ... */}
</RadioGroup>

{/* 年龄区间选择 */}
<Select value={userInfo.ageRange} onValueChange={handleAgeRangeChange}>
  {/* ... */}
</Select>

{/* 省份选择 */}
<Select value={userInfo.province} onValueChange={handleProvinceChange}>
  {/* ... */}
</Select>

{/* 城市选择 */}
<Select value={userInfo.city} onValueChange={handleCityChange}>
  {/* ... */}
</Select>
```

#### 8. 返回首页按钮
```typescript
{/* 提交按钮 */}
<div className="pt-4 space-y-3">
  <Button
    onClick={handleSubmit}
    className="w-full h-12 text-base gap-2"
  >
    <ArrowRight className="h-5 w-5" />
    提交并继续
  </Button>
  
  {/* 返回首页按钮 */}
  <Button
    type="button"
    variant="outline"
    onClick={() => navigate('/')}
    className="w-full h-12 text-base gap-2"
  >
    <Home className="h-5 w-5" />
    返回首页
  </Button>
</div>
```

## 用户使用流程

### 场景1：正常填写并提交
1. 用户进入信息收集页面
2. 选择性别 → 自动保存草稿
3. 选择年龄区间 → 自动保存草稿
4. 选择省份 → 自动保存草稿
5. 选择城市 → 自动保存草稿
6. 点击"提交并继续" → 保存正式数据，清空草稿，跳转到下一页

### 场景2：中途离开后返回
1. 用户进入信息收集页面
2. 选择性别 → 自动保存草稿
3. 选择年龄区间 → 自动保存草稿
4. **用户关闭页面或浏览器**
5. **用户再次进入信息收集页面**
6. **页面自动恢复之前填写的性别和年龄区间**
7. 用户继续填写省份和城市
8. 点击"提交并继续" → 保存正式数据，清空草稿

### 场景3：使用自动定位
1. 用户进入信息收集页面
2. 选择性别 → 自动保存草稿
3. 选择年龄区间 → 自动保存草稿
4. 点击"获取当前位置" → 自动填充省份和城市 → 自动保存草稿
5. 点击"提交并继续" → 保存正式数据，清空草稿

### 场景4：返回首页
1. 用户进入信息收集页面
2. 填写部分信息（自动保存草稿）
3. 点击"返回首页" → 跳转到首页
4. **草稿数据保留**
5. 用户再次进入信息收集页面 → 自动恢复草稿数据

## 数据存储结构

### 草稿数据（user_info_draft）
```json
{
  "gender": "male",
  "ageRange": "60-69",
  "province": "北京市",
  "city": "北京市"
}
```

### 正式数据（user_info）
```json
{
  "gender": "male",
  "ageRange": "60-69",
  "province": "北京市",
  "city": "北京市",
  "filledDate": "2026-01-31T10:30:00.000Z"
}
```

## 注意事项

### 1. 数据隔离
- 草稿数据和正式数据使用不同的localStorage键名
- 互不影响，避免混淆

### 2. 提交后清空
- 提交成功后立即清空草稿数据
- 避免下次进入页面时错误恢复旧数据

### 3. 错误处理
- 所有localStorage操作都包含try-catch错误处理
- 失败时输出错误日志到控制台
- 不会影响页面正常使用

### 4. 浏览器兼容性
- 依赖localStorage API
- 所有现代浏览器都支持
- 如果浏览器不支持或禁用localStorage，功能会静默失败

### 5. 隐私保护
- 所有数据仅保存在用户浏览器本地
- 不会自动上传到服务器
- 用户可以清除浏览器数据来删除草稿

### 6. 省份变化时重置城市
- 当用户更改省份时，城市选择会被重置为空
- 这是为了避免省份和城市不匹配的情况
- 重置后的状态也会自动保存到草稿

## 测试建议

### 功能测试
1. **自动保存测试**：
   - 选择性别，刷新页面，检查是否恢复
   - 选择年龄区间，刷新页面，检查是否恢复
   - 选择省份，刷新页面，检查是否恢复
   - 选择城市，刷新页面，检查是否恢复
   - 使用自动定位，刷新页面，检查是否恢复

2. **提交后清空测试**：
   - 填写完整信息并提交
   - 返回信息收集页面
   - 检查表单是否为空（草稿已清空）

3. **返回首页测试**：
   - 填写部分信息
   - 点击"返回首页"按钮
   - 检查是否跳转到首页
   - 再次进入信息收集页面
   - 检查草稿是否保留

4. **省份变化重置城市测试**：
   - 选择省份A和城市A
   - 更改省份为B
   - 检查城市是否被重置为空
   - 刷新页面
   - 检查省份B和空城市是否恢复

### 边界测试
1. localStorage不可用时的行为
2. 草稿数据格式错误时的处理
3. 快速连续更改字段值
4. 同时打开多个标签页

### 用户体验测试
1. 自动保存是否及时
2. 数据恢复是否准确
3. 返回首页按钮是否易于找到
4. 按钮样式是否清晰区分
5. 移动端适配是否良好

## 控制台日志

### 正常流程日志
```
已恢复草稿数据: {gender: "male", ageRange: "60-69", province: "", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市"}
用户信息已保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", filledDate: "2026-01-31T10:30:00.000Z"}
草稿数据已清空
```

### 错误日志
```
恢复草稿数据失败: SyntaxError: Unexpected token...
保存草稿失败: QuotaExceededError: The quota has been exceeded
```

## 总结

信息收集页面自动保存与首页导航功能已完整实现，包括：
- ✅ 表单字段自动保存（性别、年龄区间、省份、城市）
- ✅ 页面加载时自动恢复草稿数据
- ✅ 数据隔离（草稿数据与正式数据独立存储）
- ✅ 提交后清空草稿数据
- ✅ 返回首页导航按钮（outline样式）
- ✅ 完善的错误处理
- ✅ 控制台日志输出

用户可以在填写信息时享受自动保存的便利，避免因页面意外关闭而丢失数据。同时，返回首页按钮提供了便捷的导航功能，提升了整体用户体验。

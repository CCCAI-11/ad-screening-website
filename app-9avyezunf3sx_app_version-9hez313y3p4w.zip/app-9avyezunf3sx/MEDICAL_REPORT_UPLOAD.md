# 医学报告上传功能说明文档

## 功能概述

在综合报告页面内新增"申请医生分析"模块，允许用户上传医学影像或报告图片，并查看提交历史与状态。本期仅实现用户前端功能，医生后端管理界面后续开发。

## 最新更新（第二版）

### 新增功能
1. **撤回申请功能**：用户可以撤回"待处理"状态的申请
2. **视觉层级强化**：独立的视觉容器、醒目的标题和图标、强化的重要提示

### 视觉优化
1. **模块容器**：渐变背景色、加强阴影、2px边框
2. **标题设计**：3xl字号、深蓝色、医生图标
3. **重要提示**：橙色背景条、左侧彩色竖条
4. **上传区域**：立体设计、3px虚线边框、悬停效果
5. **历史记录**：装饰性分割线、卡片样式优化

## 功能特性

### 1. 新报告上传区

#### 功能说明
- 用户可以上传脑部CT、MRI或认知评估报告等医学影像图片
- 合作医生将提供专业分析
- 分析结论将在24-48小时内给出
- **重要提示**：此服务为远程初步咨询，不能替代线下面对面诊疗（橙色背景强化显示）

#### 图片上传组件
- **支持方式**：
  - 点击上传
  - 拖放上传
- **文件限制**：
  - 支持格式：JPG、PNG
  - 单张图片大小：≤ 5MB
- **功能**：
  - 图片预览
  - 删除已选图片

#### 症状描述框
- 可选填写
- 标签：请补充说明您的症状或主要关切（选填）
- 最大长度：500字符
- 实时字数统计

#### 提交按钮
- 点击后上传图片和描述
- 显示"上传中..."加载状态
- 成功后清空表单并提示"上传成功！已加入医生处理队列。"

### 2. 历史记录与状态追踪区

#### 标题
"我的申请记录"

#### 列表展示
以卡片形式展示用户所有提交的记录

#### 每条记录包含
1. **上传时间**：格式如 2023-10-27 14:30
2. **报告预览**：图片的缩略图（96x96px，圆角边框）
3. **状态标签**：
   - 待处理（灰色标签）
   - 已分析（绿色标签）
4. **撤回按钮**：
   - 仅在"待处理"状态显示
   - 点击后弹出确认框："确定要撤回此申请吗？撤回后医生将无法查看您上传的资料。"
   - 确认后从列表和localStorage中删除该记录
   - 显示"申请已撤回"提示
5. **症状描述**：显示用户填写的描述（最多2行，浅色背景）
6. **医生结论**：
   - 待处理状态：显示"等待医生分析..."
   - 已分析状态：显示医生的结论内容（第一阶段留空）
   - 蓝色背景条，左侧蓝色竖条

#### 空状态
- 无记录时显示友好提示
- 图标 + "暂无申请记录" + "上传您的第一份报告吧"
- 白色半透明背景，虚线边框

## 视觉设计优化

### 模块容器设计
- **背景色**：渐变背景（蓝色到绿色，from-blue-50/80 to-green-50/80）
- **边框**：2px实线边框
- **阴影**：加强阴影效果（shadow-xl）
- **整体效果**：独立的视觉容器，在页面中凸显

### 标题与图标设计
- **主标题**：
  - 字号：3xl（约30px）
  - 字重：bold（加粗）
  - 颜色：深蓝色（#2c5e9e）
  - 图标：医生听诊器图标（Stethoscope）
  - 图标大小：8x8（约32px）
- **副标题**：
  - 字号：sm
  - 字重：medium
  - 颜色：muted-foreground

### 重要提示强化
- **外层容器**：
  - 蓝色左侧竖条（border-l-4 border-l-blue-500）
  - 浅蓝色背景（bg-blue-50/50）
- **重要提示内容**：
  - 橙色背景条（bg-orange-50）
  - 橙色左侧竖条（border-l-4 border-l-orange-500）
  - 橙色文字（text-orange-700）
  - 加粗字体（font-bold）
  - 警告图标（AlertCircle，5x5）

### 上传区域设计
- **外层容器**：
  - 白色半透明背景（bg-white/60）
  - 2px虚线边框（border-2 border-dashed）
  - 圆角（rounded-lg）
  - 内边距（p-6）
- **上传区标题**：
  - 字号：xl
  - 字重：bold
  - 颜色：primary
  - 上传图标
- **拖放区域**：
  - 3px虚线边框（border-3 border-dashed）
  - 圆角加大（rounded-xl）
  - 内边距加大（p-10）
  - 悬停效果：
    - 边框变为primary色
    - 背景变为accent/50
    - 添加阴影（hover:shadow-md）
  - 拖放时效果：
    - 边框变为primary色
    - 背景变为primary/10
    - 放大1.02倍（scale-[1.02]）
    - 加强阴影（shadow-lg）
  - 上传图标：16x16（约64px）
  - 提示文字：base字号，font-semibold

### 历史记录区域设计
- **分割线**：
  - 顶部4px边框（border-t-4）
  - 颜色：primary/20
  - 顶部内边距（pt-8）
- **标题装饰**：
  - 左侧短横线（h-1 w-12 bg-primary）
  - 标题文字（text-xl font-bold text-primary）
  - 右侧长横线（h-1 flex-1 bg-primary/20）
- **记录卡片**：
  - 2px边框（border-2）
  - 阴影效果（shadow-md）
  - 悬停加强阴影（hover:shadow-lg）
  - 内边距（p-5）
  - 缩略图：24x24（约96px），圆角，2px边框
  - 描述背景：accent/30
  - 医生结论背景：蓝色背景条，左侧蓝色竖条

### 撤回按钮设计
- **位置**：状态标签右侧
- **样式**：
  - outline变体
  - 小尺寸（size="sm"，h-7）
  - 红色边框（border-destructive/50）
  - 红色文字（text-destructive）
  - 悬停效果：红色背景，白色文字
- **图标**：垃圾桶图标（Trash2，3x3）
- **文字**：xs字号，"撤回"

## 数据存储方案

### localStorage存储

#### 存储键名
`medical_report_submissions`

#### 数据结构
```typescript
interface MedicalReportSubmission {
  id: string;                    // 唯一ID（格式：report_时间戳_随机字符串）
  userId: string;                // 用户ID（从user_info获取）
  imageBase64: string;           // 图片Base64数据
  description: string;           // 症状描述
  timestamp: string;             // 提交时间（ISO格式）
  status: 'pending' | 'analyzed'; // 状态：待处理 | 已分析
  doctorConclusion: string;      // 医生结论（第一阶段留空）
}
```

#### 数据示例
```json
[
  {
    "id": "report_1698384600000_abc123def",
    "userId": "male",
    "imageBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
    "description": "近期记忆力下降明显",
    "timestamp": "2023-10-27T06:30:00Z",
    "status": "pending",
    "doctorConclusion": ""
  }
]
```

### 存储特点
- 数据持久化：刷新页面后数据不丢失
- 按时间倒序排列：最新提交的记录显示在最前面
- 图片Base64存储：考虑localStorage容量限制（通常5-10MB）

### 容量限制处理
- 单张图片限制5MB
- 提示用户不要上传过大图片
- 保存失败时提示"存储空间不足"

## 技术实现

### 文件类型
- `src/types/medicalReport.ts` - 类型定义
- `src/components/MedicalReportUpload.tsx` - 上传组件
- `src/pages/ComprehensiveReportPage.tsx` - 集成页面

### 核心功能

#### 文件验证
```typescript
const validateFile = (file: File): string | null => {
  if (!ALLOWED_FILE_TYPES.includes(file.type)) {
    return '仅支持 JPG 和 PNG 格式的图片';
  }
  if (file.size > MAX_FILE_SIZE) {
    return '图片大小不能超过 5MB';
  }
  return null;
};
```

#### Base64转换
```typescript
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};
```

#### 拖放上传
```typescript
const handleDrop = (e: DragEvent<HTMLDivElement>) => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (file) {
    handleFileSelect(file);
  }
};
```

#### 数据保存
```typescript
const saveSubmission = (submission: MedicalReportSubmission) => {
  const stored = localStorage.getItem(MEDICAL_REPORT_STORAGE_KEY);
  const existing = stored ? JSON.parse(stored) : [];
  const updated = [submission, ...existing];
  localStorage.setItem(MEDICAL_REPORT_STORAGE_KEY, JSON.stringify(updated));
};
```

#### 撤回申请
```typescript
const handleWithdraw = (id: string) => {
  // 弹出确认框
  const confirmed = window.confirm(
    '确定要撤回此申请吗？撤回后医生将无法查看您上传的资料。'
  );

  if (!confirmed) {
    return;
  }

  try {
    // 从localStorage中删除
    const stored = localStorage.getItem(MEDICAL_REPORT_STORAGE_KEY);
    if (stored) {
      const existing = JSON.parse(stored) as MedicalReportSubmission[];
      const updated = existing.filter(item => item.id !== id);
      localStorage.setItem(MEDICAL_REPORT_STORAGE_KEY, JSON.stringify(updated));
      
      // 更新状态
      setSubmissions(updated);
      
      alert('申请已撤回');
    }
  } catch (error) {
    console.error('撤回失败:', error);
    alert('撤回失败，请重试');
  }
};
```

## 为后续医生后端预留

### 唯一ID生成
每条记录都有唯一ID，格式：`report_时间戳_随机字符串`

### 状态字段
- `pending` - 待处理（默认状态）
- `analyzed` - 已分析（医生已回复）

### 易于转换为API调用
当前代码结构易于修改为向后端API发送请求：

```typescript
// 当前：保存到localStorage
saveSubmission(submission);

// 未来：发送到后端API
const response = await fetch('/api/medical-reports', {
  method: 'POST',
  body: JSON.stringify(submission)
});
```

### 数据同步
未来可以实现：
1. 提交时同时保存到localStorage和后端
2. 页面加载时从后端拉取最新数据
3. 医生更新状态后，前端自动刷新

## 用户使用流程

### 上传报告
1. 进入综合报告页面
2. 滚动到"申请医生分析"模块（独立的渐变背景容器）
3. 点击上传区域或拖放图片
4. （可选）填写症状描述
5. 点击"提交申请"按钮
6. 看到"上传成功！已加入医生处理队列。"提示

### 查看历史
1. 在"我的申请记录"区域查看所有提交
2. 查看每条记录的状态（待处理/已分析）
3. 待处理状态显示"等待医生分析..."
4. 已分析状态显示医生的结论（第一阶段留空）

### 撤回申请（新增）
1. 在"我的申请记录"中找到"待处理"状态的记录
2. 点击记录右上角的"撤回"按钮
3. 在确认框中点击"确定"
4. 记录从列表中移除
5. 看到"申请已撤回"提示

**注意**：
- 仅"待处理"状态的申请可以撤回
- "已分析"状态的申请不显示撤回按钮
- 撤回后数据将从localStorage中永久删除

## 注意事项

### 隐私保护
- 所有数据仅保存在用户浏览器本地
- 不会自动上传到服务器
- 用户可以清除浏览器数据来删除记录

### 存储限制
- localStorage通常有5-10MB限制
- 单张图片限制5MB
- 建议用户上传清晰但不过大的图片

### 浏览器兼容性
- 支持所有现代浏览器
- 需要支持FileReader API
- 需要支持localStorage

## 未来扩展

### 第二阶段（医生后端）
- 医生管理界面
- 查看待处理报告列表
- 上传医生结论
- 状态更新通知

### 第三阶段（增强功能）
- 多图片上传
- 图片压缩
- 云端存储
- 实时通知
- 报告导出

## 测试建议

### 功能测试
1. 上传不同格式的图片（JPG、PNG、其他格式）
2. 上传不同大小的图片（小于5MB、大于5MB）
3. 测试拖放上传
4. 测试点击上传
5. 测试图片预览和删除
6. 测试提交成功后表单清空
7. 测试历史记录显示
8. 测试刷新页面后数据持久化
9. **测试撤回功能**：
   - 点击"撤回"按钮
   - 确认框显示正确
   - 点击"取消"不删除记录
   - 点击"确定"删除记录
   - 记录从列表中移除
   - localStorage中数据被删除
   - 显示"申请已撤回"提示
10. **测试撤回按钮显示逻辑**：
    - "待处理"状态显示撤回按钮
    - "已分析"状态不显示撤回按钮

### 边界测试
1. 不选择图片直接提交
2. 上传超大图片（测试存储空间不足）
3. 快速连续提交多次
4. 清空localStorage后查看历史记录
5. **撤回所有记录后查看空状态**
6. **撤回记录后立即提交新记录**

### 用户体验测试
1. 上传流程是否流畅
2. 提示信息是否清晰
3. 加载状态是否明显
4. 历史记录是否易于查看
5. 移动端适配是否良好
6. **视觉层级是否清晰**：
   - 模块是否独立凸显
   - 标题是否醒目
   - 重要提示是否易于注意
   - 上传区域是否立体
   - 悬停效果是否明显
7. **撤回操作是否友好**：
   - 撤回按钮是否易于找到
   - 确认框文字是否清晰
   - 撤回后反馈是否及时

## 总结

医学报告上传功能（第二版）已完整实现，包括：
- ✅ 图片上传（点击+拖放）
- ✅ 图片预览和删除
- ✅ 症状描述输入
- ✅ 提交功能
- ✅ 历史记录展示
- ✅ 状态追踪
- ✅ localStorage持久化存储
- ✅ 为后续医生后端预留接口
- ✅ **撤回申请功能（新增）**
- ✅ **视觉层级强化（新增）**

### 第二版新增特性
1. **撤回申请功能**：
   - 仅"待处理"状态可撤回
   - 确认框二次确认
   - 从列表和localStorage中删除
   - 友好的提示信息

2. **视觉优化**：
   - 独立的渐变背景容器
   - 醒目的标题和医生图标
   - 强化的重要提示（橙色背景条）
   - 立体的上传区域（3px虚线边框，悬停效果）
   - 装饰性分割线和卡片样式

用户可以在综合报告页面方便地上传医学报告，查看提交历史和状态，撤回待处理的申请，为后续医生分析做好准备。整个模块在页面中独立凸显，视觉层级清晰，用户体验友好。

# 定位功能配置说明

## 功能概述

用户信息收集页面提供智能定位功能，点击定位按钮后可**一键自动填充省份和城市**，无需任何手动操作。

## 性能优化

### 定位参数优化
为了提升定位速度和用户体验，系统采用以下优化策略：

- **enableHighAccuracy: false** - 不使用高精度定位，速度更快（1-3秒）
- **timeout: 15000** - 15秒超时限制，避免长时间等待
- **maximumAge: 60000** - 允许使用1分钟内的缓存位置，加快响应速度

### 用户体验优化
- **即时反馈**：点击定位按钮后，按钮文字立即变为"定位中..."
- **状态恢复**：定位成功或失败后，按钮文字恢复为"获取当前位置"
- **友好提示**：失败时显示具体原因，引导用户手动选择

## 工作原理

系统使用百度地图逆地理编码服务，通过Supabase Edge Function实现安全的API调用。

### 完整流程

```
用户点击定位按钮（📍图标）
    ↓
浏览器请求定位权限
    ↓
用户允许定位
    ↓
获取设备经纬度（Geolocation API）
    ↓
调用Supabase Edge Function
    ↓
Edge Function调用百度地图逆地理编码API
    ↓
解析返回的省份和城市信息
    ↓
同时自动填充省份和城市下拉框
    ↓
完成（静默填充，无提示）
```

## 技术实现

### 1. 前端实现（UserInfoPage.tsx）

```typescript
// 状态管理
const [isLocating, setIsLocating] = useState(false);
const [locatingText, setLocatingText] = useState('获取当前位置');

// 点击定位按钮
const handleAutoLocation = async () => {
  setIsLocating(true);
  setLocatingText('定位中...');
  
  // 1. 获取设备位置（优化参数）
  navigator.geolocation.getCurrentPosition(
    async (position) => {
      const { latitude, longitude } = position.coords;
      
      // 2. 调用Edge Function
      const { data } = await supabase.functions.invoke('reverse-geocoding', {
        body: { latitude, longitude }
      });
      
      // 3. 同时填充省份和城市
      setUserInfo({
        ...userInfo,
        province: data.province,
        city: data.city
      });
      
      // 4. 恢复按钮状态
      setIsLocating(false);
      setLocatingText('获取当前位置');
    },
    (error) => {
      // 错误处理
      alert('定位失败，请手动选择');
      setIsLocating(false);
      setLocatingText('获取当前位置');
    },
    {
      enableHighAccuracy: false,  // 标准精度，速度快
      timeout: 15000,             // 15秒超时
      maximumAge: 60000           // 1分钟缓存
    }
  );
};
```

### 2. Edge Function实现（reverse-geocoding）

```typescript
// 接收经纬度
const { latitude, longitude } = await req.json();

// 调用百度地图API
const location = `${latitude},${longitude}`;
const apiUrl = `https://app-9avyezunf3sx-api-baBwZEjbe1X9-gateway.appmiaoda.com/reverse_geocoding/v3?location=${location}&output=json&language=zh-CN`;

const response = await fetch(apiUrl, {
  headers: {
    'X-Gateway-Authorization': `Bearer ${INTEGRATIONS_API_KEY}`
  }
});

// 解析并返回省份和城市
const data = await response.json();
return {
  province: data.result.addressComponent.province,
  city: data.result.addressComponent.city
};
```

## 使用说明

### 用户操作步骤

1. 打开信息收集页面
2. 点击省份下拉框右侧的"获取当前位置"按钮
3. 按钮文字变为"定位中..."，图标开始脉冲动画
4. 浏览器弹出定位权限请求，点击"允许"
5. 等待1-3秒，省份和城市自动填充完成
6. 按钮文字恢复为"获取当前位置"
7. 直接点击"提交并继续"按钮

### 注意事项

- **首次使用**：浏览器会请求定位权限，请点击"允许"
- **HTTPS要求**：定位功能需要在HTTPS环境下使用（本地开发除外）
- **定位速度**：使用标准精度定位，通常1-3秒内完成
- **位置缓存**：1分钟内重复定位会使用缓存，速度更快
- **手动修改**：自动填充后，仍可手动修改省份和城市
- **超时处理**：15秒内未完成定位会自动超时，提示手动选择

## 错误处理

系统对各种错误情况都有完善的处理：

### 1. 浏览器不支持定位
- **提示**：您的浏览器不支持定位功能
- **解决**：手动选择省份和城市

### 2. 用户拒绝定位权限
- **提示**：您拒绝了定位权限，请手动选择
- **解决**：手动选择省份和城市，或在浏览器设置中允许定位权限

### 3. 定位超时
- **提示**：定位超时，请手动选择
- **解决**：检查网络连接，或手动选择省份和城市

### 4. 位置信息不可用
- **提示**：位置信息不可用，请手动选择
- **解决**：检查设备定位服务是否开启，或手动选择

### 5. API调用失败
- **提示**：获取地址失败，请手动选择
- **解决**：检查网络连接，或手动选择省份和城市

## 隐私与安全

### 数据安全

- ✅ 所有API调用通过Supabase Edge Function进行，API密钥不暴露给前端
- ✅ 使用官方集成密钥，自动注入到Edge Function环境
- ✅ 支持CORS，仅允许授权域名访问

### 隐私保护

- ✅ 定位功能需要用户明确授权
- ✅ 位置信息仅用于填充省份和城市
- ✅ 不存储用户的精确经纬度坐标
- ✅ 所有数据仅保存在用户浏览器本地（localStorage）
- ✅ 不上传任何位置数据到服务器

## 测试定位功能

### 测试步骤

1. 打开浏览器开发者工具（F12）
2. 切换到Console标签
3. 进入信息收集页面
4. 点击定位按钮
5. 观察控制台日志和表单填充情况

### 预期日志

```
按钮文字变为: 定位中...
获取到位置: { latitude: 31.2304, longitude: 121.4737 }
收到逆地理编码请求: { latitude: 31.2304, longitude: 121.4737 }
调用百度地图API: https://...
百度地图API返回数据: {...}
解析结果: { province: "上海市", city: "黄浦区", ... }
自动填充完成: { province: "上海市", city: "黄浦区" }
按钮文字恢复: 获取当前位置
```

### 预期结果

- 按钮文字从"获取当前位置"变为"定位中..."
- 按钮图标开始脉冲动画
- 省份下拉框自动选中对应省份
- 城市下拉框自动选中对应城市
- 按钮文字恢复为"获取当前位置"
- 整个过程1-3秒内完成（使用缓存时更快）

## 常见问题

**Q: 定位速度慢怎么办？**
A: 系统已优化为标准精度定位（enableHighAccuracy: false），通常1-3秒完成。如果仍然慢，可能是网络问题或设备GPS信号弱。

**Q: 定位按钮一直显示"定位中..."怎么办？**
A: 可能是定位超时（15秒）或网络问题。刷新页面重试，或直接手动选择省份和城市。

**Q: 为什么有时定位很快，有时很慢？**
A: 系统使用1分钟位置缓存（maximumAge: 60000）。如果1分钟内重复定位，会直接使用缓存，速度更快。

**Q: 定位后没有自动填充怎么办？**
A: 检查浏览器控制台是否有错误信息，确认已允许定位权限。如果问题持续，请手动选择。

**Q: 定位不准确怎么办？**
A: 标准精度定位可能有几百米误差，但对省市级别定位足够准确。如果结果不对，可以手动修改。

**Q: 为什么需要定位权限？**
A: 定位权限用于获取设备位置，以便自动填充省份和城市，提升用户体验。

**Q: 定位功能是否必须使用？**
A: 不是必须的。您可以选择手动选择省份和城市。

**Q: 定位功能在哪些浏览器上可用？**
A: 支持所有现代浏览器（Chrome、Firefox、Safari、Edge等）。

## 技术细节

### 坐标系统

- **输入坐标系**：WGS84（浏览器Geolocation API标准）
- **API参数**：coordtype=wgs84ll
- **输出坐标系**：BD09LL（百度坐标系）

### API参数

```
location: 纬度,经度（如：31.2304,121.4737）
coordtype: wgs84ll（输入坐标类型）
extensions_poi: 0（不召回POI数据）
output: json（输出格式）
language: zh-CN（中文）
```

### 定位参数优化

```javascript
{
  enableHighAccuracy: false,  // 标准精度定位
  timeout: 15000,             // 15秒超时
  maximumAge: 60000           // 1分钟缓存
}
```

**参数说明**：
- **enableHighAccuracy: false** - 使用标准精度定位，速度快（1-3秒），精度足够（几百米）
- **enableHighAccuracy: true** - 使用高精度定位，速度慢（5-10秒），精度高（几米）
- **timeout: 15000** - 15秒超时限制，避免用户长时间等待
- **maximumAge: 60000** - 允许使用1分钟内的缓存位置，加快响应速度

**性能对比**：
| 参数配置 | 定位速度 | 定位精度 | 适用场景 |
|---------|---------|---------|---------|
| enableHighAccuracy: false | 1-3秒 | 几百米 | 省市级定位 ✓ |
| enableHighAccuracy: true | 5-10秒 | 几米 | 精确导航 |

### 直辖市处理

对于北京、上海、天津、重庆等直辖市：
- API返回的province和city相同
- 系统自动使用district作为city
- 确保下拉框选项匹配正确

## 开发者指南

### 修改Edge Function

Edge Function位于：`supabase/functions/reverse-geocoding/index.ts`

修改后需要重新部署：
```bash
# 使用Supabase CLI部署
supabase functions deploy reverse-geocoding
```

### 调试技巧

1. 查看Edge Function日志：
   ```bash
   supabase functions logs reverse-geocoding
   ```

2. 本地测试Edge Function：
   ```bash
   supabase functions serve reverse-geocoding
   ```

3. 前端调试：
   - 打开浏览器开发者工具
   - 查看Console标签的日志输出
   - 查看Network标签的API请求

## 总结

智能定位功能实现了**一键自动填充省份和城市**，大大提升了用户体验。系统采用安全的Edge Function架构，保护API密钥不暴露，同时提供完善的错误处理和隐私保护。

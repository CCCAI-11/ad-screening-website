import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

interface TextWithAudioProps {
  text: string;
  className?: string;
  iconSize?: number;
  showText?: boolean;
}

// 音频缓存
const audioCache = new Map<string, string>();

// Supabase配置
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

export function TextWithAudio({ 
  text, 
  className = '', 
  iconSize = 20,
  showText = true 
}: TextWithAudioProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isPlayingRef = useRef(false); // 使用ref跟踪播放状态，避免闭包问题

  // 清理音频资源
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handlePlay = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!text || text.trim().length === 0) {
      return;
    }

    // 如果正在播放，则停止
    if (isPlayingRef.current && audioRef.current) {
      console.log('Stopping current playback');
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      isPlayingRef.current = false;
      return;
    }

    // 防止重复点击
    if (isLoading) {
      console.log('Already loading, ignoring click');
      return;
    }

    try {
      setIsLoading(true);
      setHasError(false);

      // 检查缓存
      let audioUrl = audioCache.get(text);

      if (!audioUrl) {
        console.log('Calling TTS for text:', text.substring(0, 50));
        
        // 直接使用fetch调用Edge Function以获取二进制数据
        const response = await fetch(
          `${SUPABASE_URL}/functions/v1/text-to-speech`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
            },
            body: JSON.stringify({ text })
          }
        );

        console.log('TTS Response status:', response.status);

        if (!response.ok) {
          // 尝试解析错误信息
          const errorData = await response.json().catch(() => null);
          console.error('TTS Error:', errorData);
          setHasError(true);
          toast({
            title: '语音播放失败',
            description: errorData?.error || '语音服务暂时不可用',
            variant: 'destructive'
          });
          return;
        }

        // 检查Content-Type
        const contentType = response.headers.get('Content-Type');
        console.log('Response Content-Type:', contentType);

        // 如果返回的是JSON错误
        if (contentType?.includes('application/json')) {
          const errorData = await response.json();
          console.error('TTS API Error:', errorData);
          setHasError(true);
          toast({
            title: '语音合成失败',
            description: errorData.error || '请稍后重试',
            variant: 'destructive'
          });
          return;
        }

        // 获取音频数据
        const audioBlob = await response.blob();
        console.log('Audio blob received:', audioBlob.size, 'bytes, type:', audioBlob.type);

        if (audioBlob.size === 0) {
          console.error('Empty audio data');
          setHasError(true);
          toast({
            title: '语音数据无效',
            description: '请稍后重试',
            variant: 'destructive'
          });
          return;
        }

        audioUrl = URL.createObjectURL(audioBlob);
        console.log('Audio URL created:', audioUrl);
        
        // 缓存音频URL
        audioCache.set(text, audioUrl);
      }

      // 创建或重用音频元素
      if (!audioRef.current) {
        audioRef.current = new Audio();
        audioRef.current.volume = 1.0; // 确保音量最大
        audioRef.current.onended = () => {
          console.log('Audio playback ended');
          setIsPlaying(false);
          isPlayingRef.current = false;
        };
        audioRef.current.onerror = (e) => {
          console.error('Audio playback error:', e);
          setIsPlaying(false);
          isPlayingRef.current = false;
          setHasError(true);
          toast({
            title: '播放失败',
            description: '音频播放出错',
            variant: 'destructive'
          });
        };
        audioRef.current.onloadeddata = () => {
          console.log('Audio data loaded, duration:', audioRef.current?.duration);
        };
        audioRef.current.onplay = () => {
          console.log('Audio play event fired');
        };
        audioRef.current.onpause = () => {
          console.log('Audio pause event fired');
        };
      }

      audioRef.current.src = audioUrl;
      console.log('Audio src set to:', audioUrl);
      
      console.log('Attempting to play audio...');
      try {
        const playPromise = audioRef.current.play();
        console.log('Play promise created:', playPromise);
        await playPromise;
        console.log('Audio playback started successfully');
        setIsPlaying(true);
        isPlayingRef.current = true;
      } catch (playError) {
        console.error('Audio play() failed:', playError);
        setIsPlaying(false);
        isPlayingRef.current = false;
        // 浏览器可能阻止了自动播放
        if (playError instanceof Error && playError.name === 'NotAllowedError') {
          toast({
            title: '需要用户交互',
            description: '请再次点击播放按钮',
            variant: 'default'
          });
        } else {
          throw playError;
        }
      }

    } catch (error) {
      console.error('TTS Error:', error);
      setHasError(true);
      toast({
        title: '语音播放失败',
        description: '请稍后重试',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <span className={`inline-flex items-center gap-1 ${className}`}>
      {showText && <span>{text}</span>}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="h-auto p-1 hover:bg-primary/10"
        onClick={handlePlay}
        disabled={isLoading}
        title={isPlaying ? '停止播放' : hasError ? '语音服务暂时不可用' : '播放语音'}
      >
        {isLoading ? (
          <Loader2 className="animate-spin" style={{ width: iconSize, height: iconSize }} />
        ) : hasError ? (
          <AlertCircle className="text-destructive" style={{ width: iconSize, height: iconSize }} />
        ) : isPlaying ? (
          <VolumeX className="text-primary" style={{ width: iconSize, height: iconSize }} />
        ) : (
          <Volume2 className="text-muted-foreground hover:text-primary" style={{ width: iconSize, height: iconSize }} />
        )}
      </Button>
    </span>
  );
}

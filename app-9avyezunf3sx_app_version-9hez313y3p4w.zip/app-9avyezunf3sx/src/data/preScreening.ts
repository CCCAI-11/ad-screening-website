// 快速预筛数据
import type { PreScreeningQuestion } from '@/types/screening';

export const preScreeningQuestions: PreScreeningQuestion[] = [
  {
    id: 1,
    text: '最近会不会常常忘记最近发生的事情，比如刚说过的话、做过的事，或者东西放在哪里很快就想不起来了？',
    options: [
      { value: 'yes', label: '是' },
      { value: 'no', label: '否' }
    ]
  },
  {
    id: 2,
    text: '以前自己能轻松做完的家务活（比如做饭、打扫、买东西），现在是不是觉得有点力不从心，或者更容易出错了？',
    options: [
      { value: 'yes', label: '是' },
      { value: 'no', label: '否' }
    ]
  },
  {
    id: 3,
    text: '有没有出现过搞不清楚今天是几月几号、星期几，或者在很熟悉的地方（比如自己小区里）一时有点迷糊的情况？',
    options: [
      { value: 'yes', label: '是' },
      { value: 'no', label: '否' }
    ]
  },
  {
    id: 4,
    text: '和人聊天时，会不会突然想不起很常见的词叫什么，或者话到嘴边却说不出来？',
    options: [
      { value: 'yes', label: '是' },
      { value: 'no', label: '否' }
    ]
  },
  {
    id: 5,
    text: '最近几个月，是不是比过去更容易感到情绪低落、不想出门、或者为一点小事就发脾气？',
    options: [
      { value: 'yes', label: '是' },
      { value: 'no', label: '否' }
    ]
  }
];

// 量表信息和数据
import type { ScaleInfo, ScaleQuestion } from '@/types/screening';

// 量表信息列表
export const scalesInfo: ScaleInfo[] = [
  {
    id: 'ad8',
    name: 'AD-8量表',
    description: '针对日常认知功能的快速自筛工具，共8题，约需3分钟',
    questionCount: 8,
    estimatedTime: '3分钟'
  },
  {
    id: 'cdt',
    name: '画钟试验（CDT）',
    description: '通过一系列视觉空间与执行功能的选择题进行评估，共3题，约需2分钟',
    questionCount: 3,
    estimatedTime: '2分钟'
  },
  {
    id: 'mmse',
    name: '简易精神状态检查（MMSE）',
    description: '全面评估认知功能的经典量表，共11题，总分14分，约需10分钟',
    questionCount: 11,
    estimatedTime: '10分钟'
  },
  {
    id: 'moca',
    name: '蒙特利尔认知评估（MoCA）',
    description: '纯文本选择题版本，无需任何图片，零打字输入，共14题，总分25分，约需10分钟',
    questionCount: 14,
    estimatedTime: '10分钟'
  },
  {
    id: 'adl',
    name: '日常生活活动能力量表（ADL）',
    description: '接下来的问题想了解一下您在日常生活中的自理情况，这能帮助我们给出更全面的建议。请根据您的真实感受回答。共14题，约需5分钟',
    questionCount: 14,
    estimatedTime: '5分钟'
  }
];

// AD-8量表问题
export const ad8Questions: ScaleQuestion[] = [
  {
    id: 1,
    text: '判断力上的困难：例如落入圈套或骗局、财务上不好的决定、买了对受礼者不合宜的礼物。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 2,
    text: '对活动和嗜好的兴趣降低。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 3,
    text: '重复相同问题、故事和陈述。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 4,
    text: '在学习如何使用工具、设备和小器具上有困难。例如：电视、音响、冷气机、洗衣机、热水炉、微波炉、遥控器。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 5,
    text: '忘记正确的月份和年份。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 6,
    text: '处理复杂的财务上有困难。例如：个人或家庭的收支平衡、所得税、缴费单。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 7,
    text: '记住约会的时间有困难。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  },
  {
    id: 8,
    text: '有持续的思考和记忆方面的问题。',
    options: [
      { value: 'none', label: '没有，一切正常', score: 0 },
      { value: 'sometimes', label: '偶尔，不确定是否有变化', score: 0 },
      { value: 'often', label: '经常，确实有变化', score: 1 },
      { value: 'always', label: '总是，非常明显的变化', score: 1 }
    ]
  }
];

// CDT画钟试验问题（改为客观选择题，评估视空间与执行功能）
export const cdtQuestions: ScaleQuestion[] = [
  {
    id: 1,
    text: '计划性评估 - 如果请您画一个完整的钟面，您会从哪里开始第一步？',
    options: [
      { value: 'circle', label: '先画一个圆形作为钟的外框', score: 1 },
      { value: 'numbers', label: '先写数字（比如先写12、3、6、9）', score: 0 },
      { value: 'hands', label: '先画指针', score: 0 },
      { value: 'unknown', label: '不知道/没想好', score: 0 }
    ]
  },
  {
    id: 2,
    text: '空间布局评估 - 钟面上的数字"12"应该放在哪个位置？',
    options: [
      { value: 'top', label: '圆形的正上方', score: 1 },
      { value: 'bottom', label: '圆形的正下方', score: 0 },
      { value: 'center', label: '圆形的中间', score: 0 },
      { value: 'right', label: '圆形的右侧', score: 0 }
    ]
  },
  {
    id: 3,
    text: '指针概念评估 - 要表示"10点10分"，时钟的时针和分针应该怎么指？',
    options: [
      { value: 'both_10', label: '时针指向10，分针指向10', score: 0 },
      { value: 'correct', label: '时针靠近10（略过10），分针指向2', score: 1 },
      { value: 'hour_10_min_2', label: '时针正好指向10，分针指向2', score: 0 },
      { value: 'unclear', label: '不清楚', score: 0 }
    ]
  }
];

// MMSE简易精神状态检查（简化版，仅包含部分题目）
export const mmseQuestions: ScaleQuestion[] = [
  {
    id: 1,
    text: '时间定向力 - 今年是哪一年？',
    type: 'year',
    autoScore: true,
    options: [] // 选项将在组件中动态生成
  },
  {
    id: 2,
    text: '时间定向力 - 现在是什么季节？',
    type: 'season',
    autoScore: true,
    options: [
      { value: 'spring', label: '春', score: 0 },
      { value: 'summer', label: '夏', score: 0 },
      { value: 'autumn', label: '秋', score: 0 },
      { value: 'winter', label: '冬', score: 0 }
    ]
  },
  {
    id: 3,
    text: '时间定向力 - 现在是几月份？',
    type: 'month',
    autoScore: true,
    options: [] // 选项将在组件中动态生成（1-12月）
  },
  {
    id: 4,
    text: '时间定向力 - 今天是几号？',
    type: 'day',
    autoScore: true,
    options: [] // 选项将在组件中动态生成（1-31日）
  },
  {
    id: 5,
    text: '时间定向力 - 今天是星期几？',
    type: 'weekday',
    autoScore: true,
    options: [
      { value: '1', label: '星期一', score: 0 },
      { value: '2', label: '星期二', score: 0 },
      { value: '3', label: '星期三', score: 0 },
      { value: '4', label: '星期四', score: 0 },
      { value: '5', label: '星期五', score: 0 },
      { value: '6', label: '星期六', score: 0 },
      { value: '0', label: '星期日', score: 0 }
    ]
  },
  {
    id: 6,
    text: '记忆力 - 即时回忆',
    type: 'instruction',
    autoScore: false,
    instructionText: '请记住以下三个词：\n\n苹果、桌子、硬币\n\n（稍后会询问您）',
    options: [
      { value: 'understood', label: '我已记住，继续', score: 0 }
    ]
  },
  {
    id: 7,
    text: '记忆力 - 即时回忆测试',
    type: 'memory_input',
    autoScore: true,
    inputCount: 3,
    correctAnswers: ['苹果', '桌子', '硬币'],
    options: []
  },
  {
    id: 8,
    text: '注意力和计算力 - 请计算：100 减 7 等于多少？',
    type: 'number_input',
    autoScore: true,
    correctAnswers: ['93'],
    options: []
  },
  {
    id: 9,
    text: '注意力和计算力 - 请从上一题的答案继续减7，等于多少？',
    type: 'number_input',
    autoScore: true,
    correctAnswers: ['86'],
    options: []
  },
  {
    id: 10,
    text: '记忆力 - 延迟回忆',
    type: 'memory_input',
    autoScore: true,
    inputCount: 3,
    correctAnswers: ['苹果', '桌子', '硬币'],
    options: []
  },
  {
    id: 11,
    text: '语言能力 - 这是什么？',
    type: 'text_input',
    autoScore: true,
    imageUrl: 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_67985f0e-ea49-4475-850e-cba1adafa42a.jpg',
    correctAnswers: ['手表', '腕表', '表'],
    options: []
  }
];

// MoCA蒙特利尔认知评估（纯文本选择题版本，无需任何图片，总分30分）
export const mocaQuestions: ScaleQuestion[] = [
  // ========== 第1题：记忆编码（指导页，不计分）==========
  {
    id: 1,
    text: '请努力记住以下五个词语：面孔、天鹅绒、寺庙、菊花、红色。稍后需要回忆。',
    type: 'instruction',
    options: [
      { value: 'ready', label: '我已记住，继续', score: 0 }
    ]
  },

  // ========== 第2题：视空间-形状匹配判断（选择题，1分）==========
  {
    id: 2,
    text: '视空间与执行功能 - 形状匹配判断：一个标准的"立方体"（比如骰子），它有几个尖尖的角（顶点）？',
    options: [
      { value: 'a', label: 'A. 4个', score: 0 },
      { value: 'b', label: 'B. 6个', score: 0 },
      { value: 'c', label: 'C. 8个', score: 1 },
      { value: 'd', label: 'D. 10个', score: 0 }
    ]
  },

  // ========== 第3题：视空间-画钟识别（选择题，1分）==========
  {
    id: 3,
    text: '视空间与执行功能 - 画钟识别：下面哪一个描述，正确地表示了"差五分钟三点"的钟面？',
    options: [
      { value: 'a', label: 'A. 时针指向3，分针指向12', score: 0 },
      { value: 'b', label: 'B. 时针指向3，分针指向11', score: 0 },
      { value: 'c', label: 'C. 时针在2和3之间，分针指向11', score: 1 },
      { value: 'd', label: 'D. 时针和分针都指向3', score: 0 }
    ]
  },

  // ========== 第4题：命名识别（选择题，1分）==========
  {
    id: 4,
    text: '命名 - 命名识别：请从下列选项中，选出对"骆驼"最准确的描述。',
    options: [
      { value: 'a', label: 'A. 一种有鬃毛、生活在草原的大型猫科动物', score: 0 },
      { value: 'b', label: 'B. 一种有厚皮和角、鼻子很长的动物', score: 0 },
      { value: 'c', label: 'C. 一种背上有驼峰、适合在沙漠生活的动物', score: 1 },
      { value: 'd', label: 'D. 一种脖子很长、身上有斑点的动物', score: 0 }
    ]
  },

  // ========== 第5题：注意力-数字顺背选择（选择题，2分）==========
  {
    id: 5,
    text: '注意力 - 数字顺背：刚才听到的数字"5-8-2"，哪一个是正确的复述？',
    options: [
      { value: 'a', label: 'A. 5-8-2', score: 2 },
      { value: 'b', label: 'B. 5-2-8', score: 0 },
      { value: 'c', label: 'C. 8-5-2', score: 0 }
    ]
  },

  // ========== 第6题：注意力-数字倒背选择（选择题，2分）==========
  {
    id: 6,
    text: '注意力 - 数字倒背：数字"7-4-1"倒过来念应该是哪一个？',
    options: [
      { value: 'a', label: 'A. 1-4-7', score: 2 },
      { value: 'b', label: 'B. 7-1-4', score: 0 },
      { value: 'c', label: 'C. 4-7-1', score: 0 }
    ]
  },

  // ========== 第7题：注意力-找出目标字母（多选题，2分）==========
  {
    id: 7,
    text: '注意力 - 找出目标字母：请在下面一行字母中，找出所有的字母A：B A D F A G A',
    options: [
      { value: '2_5_7', label: '第2个、第5个、第7个是A', score: 2 },
      { value: '2_5', label: '第2个、第5个是A', score: 1 },
      { value: '2_7', label: '第2个、第7个是A', score: 1 },
      { value: 'other', label: '其他选择', score: 0 }
    ]
  },

  // ========== 第8题：语言-句子复述判断（选择题，2分）==========
  {
    id: 8,
    text: '语言 - 句子复述判断：请听这句话："那只棕色的小狗在公园里快乐地奔跑。" 下面哪一句复述是完全正确的？',
    options: [
      { value: 'a', label: 'A. 那只棕色的小狗在公园里快乐地奔跑', score: 2 },
      { value: 'b', label: 'B. 一只棕色的小狗在快乐地奔跑', score: 0 },
      { value: 'c', label: 'C. 小狗在公园里跑', score: 0 }
    ]
  },

  // ========== 第9题：语言-词语分类（多选题，1分）==========
  {
    id: 9,
    text: '语言 - 词语分类：下列哪些东西属于"水果"？',
    options: [
      { value: 'correct', label: '苹果、香蕉、葡萄', score: 1 },
      { value: 'partial1', label: '苹果、香蕉', score: 0 },
      { value: 'partial2', label: '苹果、自行车、香蕉', score: 0 },
      { value: 'wrong', label: '自行车、桌子、电视', score: 0 }
    ]
  },

  // ========== 第10题：抽象思维（选择题，2分）==========
  {
    id: 10,
    text: '抽象思维 - 相似性判断："报纸"和"收音机"最主要的共同点是什么？',
    options: [
      { value: 'a', label: 'A. 都是纸做的', score: 0 },
      { value: 'b', label: 'B. 都能提供新闻和信息', score: 2 },
      { value: 'c', label: 'C. 都要用电', score: 0 }
    ]
  },

  // ========== 第11题：延迟回忆（多选题，5分）==========
  {
    id: 11,
    text: '延迟回忆 - 现在，请从下面这些词中，选出最开始让您记住的那五个词。',
    type: 'memory_recall',
    autoScore: true,
    correctAnswers: ['面孔', '天鹅绒', '寺庙', '菊花', '红色'],
    distractors: ['毛巾', '天空', '火车', '椅子', '蓝色', '马路', '玻璃'],
    options: [
      { value: 'face', label: '面孔', score: 1 },
      { value: 'velvet', label: '天鹅绒', score: 1 },
      { value: 'temple', label: '寺庙', score: 1 },
      { value: 'chrysanthemum', label: '菊花', score: 1 },
      { value: 'red', label: '红色', score: 1 },
      { value: 'towel', label: '毛巾', score: 0 },
      { value: 'sky', label: '天空', score: 0 },
      { value: 'train', label: '火车', score: 0 },
      { value: 'chair', label: '椅子', score: 0 },
      { value: 'blue', label: '蓝色', score: 0 },
      { value: 'road', label: '马路', score: 0 },
      { value: 'glass', label: '玻璃', score: 0 }
    ]
  },

  // ========== 第12题：定向力-国家（选择题，2分）==========
  {
    id: 12,
    text: '定向力 - 国家常识：我们的首都是哪个城市？',
    options: [
      { value: 'a', label: 'A. 北京', score: 2 },
      { value: 'b', label: 'B. 上海', score: 0 },
      { value: 'c', label: 'C. 广州', score: 0 }
    ]
  },

  // ========== 第13题：定向力-城市（选择题，2分）==========
  {
    id: 13,
    text: '定向力 - 城市常识："东方明珠"电视塔在哪个城市？',
    options: [
      { value: 'a', label: 'A. 北京', score: 0 },
      { value: 'b', label: 'B. 上海', score: 2 },
      { value: 'c', label: 'C. 深圳', score: 0 }
    ]
  },

  // ========== 第14题：定向力-场所（选择题，2分）==========
  {
    id: 14,
    text: '定向力 - 场所常识：购买蔬菜水果，我们通常去哪里？',
    options: [
      { value: 'a', label: 'A. 超市或菜市场', score: 2 },
      { value: 'b', label: 'B. 医院', score: 0 },
      { value: 'c', label: 'C. 图书馆', score: 0 }
    ]
  }
];

// ADL日常生活活动能力量表（优化为老年人日常自评口吻）
export const adlQuestions: ScaleQuestion[] = [
  {
    id: 1,
    text: '您自己上厕所（包括穿、脱裤子，清洁和冲水）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 2,
    text: '您自己吃饭（使用筷子或勺子将食物送入口中）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 3,
    text: '您自己穿衣服（包括穿脱衣服、系扣子、拉拉链）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 4,
    text: '您自己洗漱（洗脸、刷牙、梳头）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 5,
    text: '您在家里走动（在室内平地行走）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 6,
    text: '您自己洗澡（包括进出浴室）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 7,
    text: '您自己打电话（包括查号码、拨号）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 8,
    text: '您自己去买东西（独自购买日常用品）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 9,
    text: '您自己准备饭菜（计划、准备、摆放食物）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 10,
    text: '您自己做家务（打扫卫生、整理房间）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 11,
    text: '您自己洗衣服（包括手洗或使用洗衣机）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 12,
    text: '您自己按时吃药（按时按量服用药物）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 13,
    text: '您自己管理钱财（支付账单、管理银行账户）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  },
  {
    id: 14,
    text: '您自己出门（使用交通工具、独自外出）的情况是？',
    options: [
      { value: 'independent', label: '我完全可以自己完成，不需要任何人帮忙', score: 1 },
      { value: 'need_help', label: '我大部分可以自己做，但有时候需要别人稍微帮一下', score: 2 },
      { value: 'dependent', label: '我很难自己完成，主要需要别人来帮助我', score: 3 }
    ]
  }
];

// 获取指定量表的问题
export function getScaleQuestions(scaleId: string): ScaleQuestion[] {
  switch (scaleId) {
    case 'ad8':
      return ad8Questions;
    case 'cdt':
      return cdtQuestions;
    case 'mmse':
      return mmseQuestions;
    case 'moca':
      return mocaQuestions;
    case 'adl':
      return adlQuestions;
    default:
      return [];
  }
}

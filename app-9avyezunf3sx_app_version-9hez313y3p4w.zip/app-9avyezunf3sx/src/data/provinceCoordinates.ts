// 中国各省份大致经纬度范围数据（用于定位匹配）
export interface ProvinceCoordinate {
  province: string;
  latMin: number;  // 最小纬度
  latMax: number;  // 最大纬度
  lngMin: number;  // 最小经度
  lngMax: number;  // 最大经度
  centerLat: number; // 中心纬度
  centerLng: number; // 中心经度
}

export const provinceCoordinates: ProvinceCoordinate[] = [
  {
    province: '北京市',
    latMin: 39.4,
    latMax: 41.1,
    lngMin: 115.4,
    lngMax: 117.5,
    centerLat: 39.9,
    centerLng: 116.4
  },
  {
    province: '天津市',
    latMin: 38.6,
    latMax: 40.3,
    lngMin: 116.7,
    lngMax: 118.1,
    centerLat: 39.1,
    centerLng: 117.2
  },
  {
    province: '上海市',
    latMin: 30.7,
    latMax: 31.9,
    lngMin: 120.9,
    lngMax: 122.0,
    centerLat: 31.2,
    centerLng: 121.5
  },
  {
    province: '重庆市',
    latMin: 28.2,
    latMax: 32.2,
    lngMin: 105.3,
    lngMax: 110.2,
    centerLat: 29.6,
    centerLng: 106.5
  },
  {
    province: '河北省',
    latMin: 36.1,
    latMax: 42.6,
    lngMin: 113.5,
    lngMax: 119.9,
    centerLat: 38.0,
    centerLng: 114.5
  },
  {
    province: '山西省',
    latMin: 34.6,
    latMax: 40.7,
    lngMin: 110.3,
    lngMax: 114.6,
    centerLat: 37.9,
    centerLng: 112.6
  },
  {
    province: '内蒙古自治区',
    latMin: 37.4,
    latMax: 53.3,
    lngMin: 97.2,
    lngMax: 126.0,
    centerLat: 40.8,
    centerLng: 111.7
  },
  {
    province: '辽宁省',
    latMin: 38.7,
    latMax: 43.5,
    lngMin: 118.9,
    lngMax: 125.5,
    centerLat: 41.8,
    centerLng: 123.4
  },
  {
    province: '吉林省',
    latMin: 40.9,
    latMax: 46.3,
    lngMin: 121.6,
    lngMax: 131.2,
    centerLat: 43.9,
    centerLng: 125.3
  },
  {
    province: '黑龙江省',
    latMin: 43.4,
    latMax: 53.6,
    lngMin: 121.2,
    lngMax: 135.1,
    centerLat: 45.8,
    centerLng: 126.6
  },
  {
    province: '江苏省',
    latMin: 30.8,
    latMax: 35.1,
    lngMin: 116.4,
    lngMax: 121.9,
    centerLat: 32.1,
    centerLng: 118.8
  },
  {
    province: '浙江省',
    latMin: 27.1,
    latMax: 31.2,
    lngMin: 118.0,
    lngMax: 123.0,
    centerLat: 30.3,
    centerLng: 120.2
  },
  {
    province: '安徽省',
    latMin: 29.4,
    latMax: 34.7,
    lngMin: 114.9,
    lngMax: 119.7,
    centerLat: 31.9,
    centerLng: 117.3
  },
  {
    province: '福建省',
    latMin: 23.5,
    latMax: 28.3,
    lngMin: 115.8,
    lngMax: 120.5,
    centerLat: 26.1,
    centerLng: 119.3
  },
  {
    province: '江西省',
    latMin: 24.5,
    latMax: 30.1,
    lngMin: 113.6,
    lngMax: 118.5,
    centerLat: 28.7,
    centerLng: 115.9
  },
  {
    province: '山东省',
    latMin: 34.4,
    latMax: 38.4,
    lngMin: 114.8,
    lngMax: 122.7,
    centerLat: 36.7,
    centerLng: 117.0
  },
  {
    province: '河南省',
    latMin: 31.4,
    latMax: 36.4,
    lngMin: 110.4,
    lngMax: 116.7,
    centerLat: 34.8,
    centerLng: 113.6
  },
  {
    province: '湖北省',
    latMin: 29.0,
    latMax: 33.3,
    lngMin: 108.4,
    lngMax: 116.1,
    centerLat: 30.6,
    centerLng: 114.3
  },
  {
    province: '湖南省',
    latMin: 24.6,
    latMax: 30.1,
    lngMin: 108.8,
    lngMax: 114.3,
    centerLat: 28.2,
    centerLng: 113.0
  },
  {
    province: '广东省',
    latMin: 20.2,
    latMax: 25.5,
    lngMin: 109.7,
    lngMax: 117.3,
    centerLat: 23.1,
    centerLng: 113.3
  },
  {
    province: '广西壮族自治区',
    latMin: 20.9,
    latMax: 26.4,
    lngMin: 104.3,
    lngMax: 112.1,
    centerLat: 22.8,
    centerLng: 108.3
  },
  {
    province: '海南省',
    latMin: 18.2,
    latMax: 20.2,
    lngMin: 108.6,
    lngMax: 111.1,
    centerLat: 20.0,
    centerLng: 110.3
  },
  {
    province: '四川省',
    latMin: 26.0,
    latMax: 34.3,
    lngMin: 97.4,
    lngMax: 108.5,
    centerLat: 30.7,
    centerLng: 104.1
  },
  {
    province: '贵州省',
    latMin: 24.6,
    latMax: 29.2,
    lngMin: 103.6,
    lngMax: 109.6,
    centerLat: 26.6,
    centerLng: 106.7
  },
  {
    province: '云南省',
    latMin: 21.1,
    latMax: 29.2,
    lngMin: 97.5,
    lngMax: 106.2,
    centerLat: 25.0,
    centerLng: 102.7
  },
  {
    province: '西藏自治区',
    latMin: 26.8,
    latMax: 36.5,
    lngMin: 78.4,
    lngMax: 99.1,
    centerLat: 29.7,
    centerLng: 91.1
  },
  {
    province: '陕西省',
    latMin: 31.7,
    latMax: 39.6,
    lngMin: 105.5,
    lngMax: 111.3,
    centerLat: 34.3,
    centerLng: 108.9
  },
  {
    province: '甘肃省',
    latMin: 32.6,
    latMax: 42.8,
    lngMin: 92.3,
    lngMax: 108.7,
    centerLat: 36.1,
    centerLng: 103.8
  },
  {
    province: '青海省',
    latMin: 31.6,
    latMax: 39.2,
    lngMin: 89.4,
    lngMax: 103.1,
    centerLat: 36.6,
    centerLng: 101.8
  },
  {
    province: '宁夏回族自治区',
    latMin: 35.2,
    latMax: 39.4,
    lngMin: 104.3,
    lngMax: 107.6,
    centerLat: 38.5,
    centerLng: 106.3
  },
  {
    province: '新疆维吾尔自治区',
    latMin: 34.3,
    latMax: 49.2,
    lngMin: 73.5,
    lngMax: 96.4,
    centerLat: 43.8,
    centerLng: 87.6
  },
  {
    province: '内蒙古自治区',
    latMin: 37.4,
    latMax: 53.3,
    lngMin: 97.2,
    lngMax: 126.1,
    centerLat: 40.8,
    centerLng: 111.7
  },
  {
    province: '台湾省',
    latMin: 21.9,
    latMax: 25.3,
    lngMin: 120.0,
    lngMax: 122.0,
    centerLat: 23.7,
    centerLng: 121.0
  },
  {
    province: '香港特别行政区',
    latMin: 22.2,
    latMax: 22.6,
    lngMin: 113.8,
    lngMax: 114.4,
    centerLat: 22.4,
    centerLng: 114.2
  },
  {
    province: '澳门特别行政区',
    latMin: 22.1,
    latMax: 22.2,
    lngMin: 113.5,
    lngMax: 113.6,
    centerLat: 22.2,
    centerLng: 113.5
  }
];

/**
 * 根据经纬度匹配省份
 * @param lat 纬度
 * @param lng 经度
 * @returns 匹配的省份名称，如果没有匹配则返回null
 */
export function matchProvinceByCoordinates(lat: number, lng: number): string | null {
  // 首先尝试精确匹配（在范围内）
  for (const province of provinceCoordinates) {
    if (
      lat >= province.latMin &&
      lat <= province.latMax &&
      lng >= province.lngMin &&
      lng <= province.lngMax
    ) {
      return province.province;
    }
  }

  // 如果没有精确匹配，找最近的省份（基于中心点距离）
  let minDistance = Infinity;
  let closestProvince: string | null = null;

  for (const province of provinceCoordinates) {
    const distance = Math.sqrt(
      Math.pow(lat - province.centerLat, 2) + Math.pow(lng - province.centerLng, 2)
    );
    if (distance < minDistance) {
      minDistance = distance;
      closestProvince = province.province;
    }
  }

  // 如果最近距离小于5度（约555公里），返回最近的省份
  if (minDistance < 5) {
    return closestProvince;
  }

  return null;
}

import HomePage from './pages/HomePage';
import UserInfoPage from './pages/UserInfoPage';
import PreScreeningQuestionPage from './pages/PreScreeningQuestionPage';
import PreScreeningResultPage from './pages/PreScreeningResultPage';
import ScaleSelectionPage from './pages/ScaleSelectionPage';
import SingleQuestionPage from './pages/SingleQuestionPage';
import ResultPage from './pages/ResultPage';
import ComprehensiveReportPage from './pages/ComprehensiveReportPage';
import type { ComponentType } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  component: ComponentType;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: '首页',
    path: '/',
    component: HomePage
  },
  {
    name: '信息收集',
    path: '/user-info',
    component: UserInfoPage
  },
  {
    name: '预筛问题',
    path: '/pre-screening/:questionId',
    component: PreScreeningQuestionPage
  },
  {
    name: '预筛结果',
    path: '/pre-screening-result',
    component: PreScreeningResultPage
  },
  {
    name: '量表选择',
    path: '/scales',
    component: ScaleSelectionPage
  },
  {
    name: '答题',
    path: '/question/:scaleId/:questionIndex',
    component: SingleQuestionPage
  },
  {
    name: '评估结果',
    path: '/result',
    component: ResultPage
  },
  {
    name: '综合报告',
    path: '/comprehensive-report',
    component: ComprehensiveReportPage
  }
];

export default routes;

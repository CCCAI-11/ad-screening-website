import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type { UserInfo, PreScreeningAnswer, ScaleAnswer, ScreeningData, ScaleType, ScaleResult } from '@/types/screening';
import { scalesInfo } from '@/data/scales';
import { safeGetItem, safeSetItem, safeRemoveItem } from '@/utils/localStorage';

interface ScreeningContextType {
  screeningData: ScreeningData;
  // 快速预筛
  updatePreScreeningAnswer: (answer: PreScreeningAnswer) => void;
  getPreScreeningYesCount: () => number;
  // 量表选择
  selectScale: (scaleId: ScaleType) => void;
  // 量表答题
  updateScaleAnswer: (scaleId: ScaleType, answer: ScaleAnswer) => void;
  getScaleAnswers: (scaleId: ScaleType) => ScaleAnswer[];
  calculateScaleScore: (scaleId: ScaleType) => number;
  // 保存量表结果（包含完成时间）
  saveScaleResult: (scaleId: ScaleType) => void;
  // 用户信息（可选）
  updateUserInfo: (info: UserInfo) => void;
  // 重置
  resetScreening: () => void;
  // 刷新数据（从localStorage重新加载）
  refreshData: () => void;
}

const STORAGE_KEY = 'alzheimer_screening_data';

const initialScreeningData: ScreeningData = {
  preScreening: [],
  selectedScale: null,
  scaleAnswers: {
    ad8: [],
    cdt: [],
    mmse: [],
    moca: [],
    adl: []
  },
  scaleResults: [],
  userInfo: null
};

// 从localStorage加载数据
const loadFromStorage = (): ScreeningData => {
  try {
    const stored = safeGetItem(STORAGE_KEY);
    if (stored) {
      const data = JSON.parse(stored);
      // 转换日期字符串为Date对象
      if (data.scaleResults) {
        data.scaleResults = data.scaleResults.map((result: ScaleResult) => ({
          ...result,
          completedAt: new Date(result.completedAt)
        }));
      }
      if (data.completedAt) {
        data.completedAt = new Date(data.completedAt);
      }
      console.log('从localStorage加载数据成功:', data);
      return data;
    }
  } catch (error) {
    console.error('从localStorage加载数据失败:', error);
  }
  return initialScreeningData;
};

// 保存数据到localStorage
const saveToStorage = (data: ScreeningData) => {
  try {
    const success = safeSetItem(STORAGE_KEY, JSON.stringify(data));
    if (success) {
      console.log('数据已保存到localStorage:', data);
    }
  } catch (error) {
    console.error('保存数据到localStorage失败:', error);
  }
};

const ScreeningContext = createContext<ScreeningContextType | undefined>(undefined);

export function ScreeningProvider({ children }: { children: ReactNode }) {
  const [screeningData, setScreeningData] = useState<ScreeningData>(() => loadFromStorage());

  // 每次数据更新时自动保存到localStorage
  useEffect(() => {
    saveToStorage(screeningData);
  }, [screeningData]);

  // 更新快速预筛答案
  const updatePreScreeningAnswer = (answer: PreScreeningAnswer) => {
    setScreeningData(prev => {
      const existingIndex = prev.preScreening.findIndex(a => a.questionId === answer.questionId);
      const newAnswers = existingIndex >= 0
        ? prev.preScreening.map((a, i) => i === existingIndex ? answer : a)
        : [...prev.preScreening, answer];
      
      return {
        ...prev,
        preScreening: newAnswers
      };
    });
  };

  // 获取快速预筛"是"的数量
  const getPreScreeningYesCount = () => {
    return screeningData.preScreening.filter(a => a.answer === 'yes').length;
  };

  // 选择量表
  const selectScale = (scaleId: ScaleType) => {
    setScreeningData(prev => ({
      ...prev,
      selectedScale: scaleId
    }));
  };

  // 更新量表答案
  const updateScaleAnswer = (scaleId: ScaleType, answer: ScaleAnswer) => {
    setScreeningData(prev => {
      const scaleAnswers = prev.scaleAnswers[scaleId];
      const existingIndex = scaleAnswers.findIndex(a => a.questionId === answer.questionId);
      const newAnswers = existingIndex >= 0
        ? scaleAnswers.map((a, i) => i === existingIndex ? answer : a)
        : [...scaleAnswers, answer];
      
      return {
        ...prev,
        scaleAnswers: {
          ...prev.scaleAnswers,
          [scaleId]: newAnswers
        }
      };
    });
  };

  // 获取指定量表的答案
  const getScaleAnswers = (scaleId: ScaleType) => {
    return screeningData.scaleAnswers[scaleId] || [];
  };

  // 计算指定量表的总分
  const calculateScaleScore = (scaleId: ScaleType) => {
    const answers = screeningData.scaleAnswers[scaleId] || [];
    return answers.reduce((sum, answer) => sum + answer.score, 0);
  };

  // 保存量表结果（包含完成时间和总分）
  const saveScaleResult = useCallback((scaleId: ScaleType) => {
    const scaleInfo = scalesInfo.find(s => s.id === scaleId);
    if (!scaleInfo) {
      console.error('未找到量表信息:', scaleId);
      return;
    }

    setScreeningData(prev => {
      const score = prev.scaleAnswers[scaleId]?.reduce((sum, answer) => sum + answer.score, 0) || 0;
      const answers = prev.scaleAnswers[scaleId] || [];

      const result: ScaleResult = {
        scaleId,
        scaleName: scaleInfo.name,
        score,
        completedAt: new Date(),
        answers
      };

      console.log(`保存${scaleInfo.name}结果:`, {
        scaleId,
        score,
        answersCount: answers.length,
        completedAt: result.completedAt
      });

      // 检查是否已存在该量表的结果，如果存在则更新，否则添加
      const existingIndex = prev.scaleResults.findIndex(r => r.scaleId === scaleId);
      const newResults = existingIndex >= 0
        ? prev.scaleResults.map((r, i) => i === existingIndex ? result : r)
        : [...prev.scaleResults, result];

      if (existingIndex >= 0) {
        console.log(`更新已存在的${scaleInfo.name}结果，旧分数:`, prev.scaleResults[existingIndex].score, '新分数:', score);
      } else {
        console.log(`添加新的${scaleInfo.name}结果`);
      }

      return {
        ...prev,
        scaleResults: newResults
      };
    });
  }, []);

  // 更新用户信息
  const updateUserInfo = (info: UserInfo) => {
    setScreeningData(prev => ({
      ...prev,
      userInfo: info,
      completedAt: new Date()
    }));
  };

  // 重置筛查
  const resetScreening = () => {
    setScreeningData(initialScreeningData);
    safeRemoveItem(STORAGE_KEY);
    console.log('筛查数据已重置');
  };

  // 刷新数据（从localStorage重新加载）
  const refreshData = useCallback(() => {
    const data = loadFromStorage();
    setScreeningData(data);
    console.log('数据已刷新');
  }, []);

  return (
    <ScreeningContext.Provider
      value={{
        screeningData,
        updatePreScreeningAnswer,
        getPreScreeningYesCount,
        selectScale,
        updateScaleAnswer,
        getScaleAnswers,
        calculateScaleScore,
        saveScaleResult,
        updateUserInfo,
        resetScreening,
        refreshData
      }}
    >
      {children}
    </ScreeningContext.Provider>
  );
}

export function useScreening() {
  const context = useContext(ScreeningContext);
  if (!context) {
    throw new Error('useScreening must be used within ScreeningProvider');
  }
  return context;
}

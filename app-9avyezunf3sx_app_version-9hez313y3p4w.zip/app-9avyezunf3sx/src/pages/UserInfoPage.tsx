import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, ArrowRight, Home } from 'lucide-react';
import { chinaRegions } from '@/data/chinaRegions';
import { createClient } from '@supabase/supabase-js';
import { safeGetItem, safeSetItem, safeRemoveItem } from '@/utils/localStorage';

// 初始化Supabase客户端
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// localStorage键名
const USER_PROFILE_KEY = 'user_profile'; // 永久档案（用户基本信息）
const USER_INFO_DRAFT_KEY = 'user_info_draft'; // 草稿数据（临时自动保存）
const USER_INFO_KEY = 'user_info'; // 正式数据（兼容旧版本）

interface UserBasicInfo {
  gender: string;
  ageRange: string;
  province: string;
  city: string;
}

export default function UserInfoPage() {
  const navigate = useNavigate();
  const [userInfo, setUserInfo] = useState<UserBasicInfo>({
    gender: '',
    ageRange: '',
    province: '',
    city: ''
  });
  const [isLocating, setIsLocating] = useState(false);
  const [locatingText, setLocatingText] = useState('获取当前位置');

  // 页面加载时恢复数据（优先加载永久档案，其次加载草稿）
  useEffect(() => {
    try {
      // 优先检查永久档案
      const profileData = safeGetItem(USER_PROFILE_KEY);
      if (profileData) {
        const parsed = JSON.parse(profileData) as UserBasicInfo;
        setUserInfo(parsed);
        console.log('已加载永久档案:', parsed);
        return; // 找到永久档案后直接返回
      }

      // 如果没有永久档案，则尝试加载草稿数据
      const draftData = safeGetItem(USER_INFO_DRAFT_KEY);
      if (draftData) {
        const parsed = JSON.parse(draftData) as UserBasicInfo;
        setUserInfo(parsed);
        console.log('已恢复草稿数据:', parsed);
      }
    } catch (error) {
      console.error('恢复数据失败:', error);
    }
  }, []);

  // 自动保存草稿数据
  const saveDraft = (data: UserBasicInfo) => {
    try {
      const success = safeSetItem(USER_INFO_DRAFT_KEY, JSON.stringify(data));
      if (success) {
        console.log('草稿已自动保存:', data);
      }
    } catch (error) {
      console.error('保存草稿失败:', error);
    }
  };

  // 获取选中省份的城市列表
  const selectedProvinceCities = chinaRegions.find(r => r.province === userInfo.province)?.cities || [];

  // 处理省份变化
  const handleProvinceChange = (province: string) => {
    const newUserInfo = {
      ...userInfo,
      province,
      city: '' // 重置城市选择
    };
    setUserInfo(newUserInfo);
    saveDraft(newUserInfo); // 自动保存草稿
  };

  // 处理城市变化
  const handleCityChange = (city: string) => {
    const newUserInfo = {
      ...userInfo,
      city
    };
    setUserInfo(newUserInfo);
    saveDraft(newUserInfo); // 自动保存草稿
  };

  // 处理性别变化
  const handleGenderChange = (gender: string) => {
    const newUserInfo = {
      ...userInfo,
      gender
    };
    setUserInfo(newUserInfo);
    saveDraft(newUserInfo); // 自动保存草稿
  };

  // 处理年龄区间变化
  const handleAgeRangeChange = (ageRange: string) => {
    const newUserInfo = {
      ...userInfo,
      ageRange
    };
    setUserInfo(newUserInfo);
    saveDraft(newUserInfo); // 自动保存草稿
  };

  // 自动获取位置并填充省市
  const handleAutoLocation = async () => {
    setIsLocating(true);
    setLocatingText('定位中...');

    if (!navigator.geolocation) {
      console.error('浏览器不支持定位功能');
      alert('您的浏览器不支持定位功能，请手动选择');
      setIsLocating(false);
      setLocatingText('获取当前位置');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        console.log('获取到位置:', { latitude, longitude });

        try {
          // 调用Edge Function进行逆地理编码
          const { data, error } = await supabase.functions.invoke('reverse-geocoding', {
            body: { latitude, longitude }
          });

          if (error) {
            console.error('逆地理编码失败:', error);
            alert('获取地址失败，请手动选择');
            setIsLocating(false);
            setLocatingText('获取当前位置');
            return;
          }

          console.log('逆地理编码成功:', data);

          const { province, city } = data;

          if (!province || !city) {
            console.error('返回的地址信息不完整:', data);
            alert('获取地址失败，请手动选择');
            setIsLocating(false);
            setLocatingText('获取当前位置');
            return;
          }

          // 同时填充省份和城市
          const newUserInfo = {
            ...userInfo,
            province,
            city
          };
          setUserInfo(newUserInfo);
          saveDraft(newUserInfo); // 自动保存草稿

          console.log('自动填充完成:', { province, city });

        } catch (err) {
          console.error('调用逆地理编码服务失败:', err);
          alert('获取地址失败，请手动选择');
        }

        setIsLocating(false);
        setLocatingText('获取当前位置');
      },
      (error) => {
        console.error('定位失败:', error);
        let errorMessage = '定位失败，请手动选择';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = '您拒绝了定位权限，请手动选择';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = '位置信息不可用，请手动选择';
            break;
          case error.TIMEOUT:
            errorMessage = '定位超时，请手动选择';
            break;
        }
        
        alert(errorMessage);
        setIsLocating(false);
        setLocatingText('获取当前位置');
      },
      {
        enableHighAccuracy: false,  // 不使用高精度定位，速度更快
        timeout: 15000,             // 15秒超时
        maximumAge: 60000           // 允许使用1分钟内的缓存位置
      }
    );
  };

  // 提交表单
  const handleSubmit = () => {
    // 验证必填项
    if (!userInfo.gender) {
      alert('请选择性别');
      return;
    }
    if (!userInfo.ageRange) {
      alert('请选择年龄区间');
      return;
    }
    if (!userInfo.province) {
      alert('请选择省份');
      return;
    }
    if (!userInfo.city) {
      alert('请选择城市');
      return;
    }

    // 保存到永久档案（user_profile）
    const profileData = {
      ...userInfo,
      lastUpdated: new Date().toISOString()
    };
    const profileSuccess = safeSetItem(USER_PROFILE_KEY, JSON.stringify(profileData));
    if (profileSuccess) {
      console.log('用户档案已保存:', profileData);
    } else {
      alert('保存用户信息失败，请重试');
      return;
    }

    // 同时保存到user_info（兼容旧版本）
    const dataToSave = {
      ...userInfo,
      filledDate: new Date().toISOString()
    };
    safeSetItem(USER_INFO_KEY, JSON.stringify(dataToSave));

    // 清空草稿数据（永久档案不清空）
    safeRemoveItem(USER_INFO_DRAFT_KEY);
    console.log('草稿数据已清空');

    // 跳转到预筛选页面
    navigate('/pre-screening/1');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="flex-1 container mx-auto px-4 py-8 max-w-3xl">
        <Card className="shadow-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl md:text-3xl text-center">
              请填写基本信息
            </CardTitle>
            <p className="text-center text-muted-foreground text-sm mt-1">
              获得更准确的评估报告
            </p>
          </CardHeader>

          <CardContent className="pt-3 space-y-6">
            {/* 重要提示 */}
            <Alert className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
              <AlertDescription className="space-y-2 text-sm">
                <p className="font-semibold text-blue-900 dark:text-blue-100">
                  📋 您的年龄、性别和地区信息对我们评估非常重要！
                </p>
                <ul className="space-y-1 text-blue-800 dark:text-blue-200">
                  <li>• 这些信息有助于我们提供更准确的评估结果和参考标准</li>
                  <li>• 我们承诺严格保护您的隐私，所有信息仅用于生成个性化报告</li>
                </ul>
              </AlertDescription>
            </Alert>

            {/* 性别选择 */}
            <div className="space-y-3">
              <Label className="text-lg font-semibold">性别 <span className="text-destructive">*</span></Label>
              <RadioGroup
                value={userInfo.gender}
                onValueChange={handleGenderChange}
                className="flex gap-6"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="male" className="h-5 w-5" />
                  <Label htmlFor="male" className="text-base cursor-pointer">男</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="female" className="h-5 w-5" />
                  <Label htmlFor="female" className="text-base cursor-pointer">女</Label>
                </div>
              </RadioGroup>
            </div>

            {/* 年龄区间选择 */}
            <div className="space-y-3">
              <Label htmlFor="age-range" className="text-lg font-semibold">
                年龄区间 <span className="text-destructive">*</span>
              </Label>
              <Select value={userInfo.ageRange} onValueChange={handleAgeRangeChange}>
                <SelectTrigger id="age-range" className="h-12 text-base">
                  <SelectValue placeholder="请选择年龄区间" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30-39">30-39岁</SelectItem>
                  <SelectItem value="40-49">40-49岁</SelectItem>
                  <SelectItem value="50-59">50-59岁</SelectItem>
                  <SelectItem value="60-69">60-69岁</SelectItem>
                  <SelectItem value="70-79">70-79岁</SelectItem>
                  <SelectItem value="80-89">80-89岁</SelectItem>
                  <SelectItem value="90-100">90-100岁</SelectItem>
                  <SelectItem value="100+">100岁以上</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 所在地选择 */}
            <div className="space-y-3">
              <Label className="text-lg font-semibold">
                所在地 <span className="text-destructive">*</span>
              </Label>

              {/* 省份选择（带定位按钮） */}
              <div className="space-y-2">
                <Label htmlFor="province" className="text-base">省份 <span className="text-destructive">*</span></Label>
                <div className="flex gap-2">
                  <Select value={userInfo.province} onValueChange={handleProvinceChange}>
                    <SelectTrigger id="province" className="h-12 text-base flex-1">
                      <SelectValue placeholder="请选择省份" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {chinaRegions.map((region) => (
                        <SelectItem key={region.province} value={region.province}>
                          {region.province}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAutoLocation}
                    disabled={isLocating}
                    className="h-12 shrink-0 whitespace-nowrap"
                  >
                    <MapPin className={`h-4 w-4 mr-1 ${isLocating ? 'animate-pulse' : ''}`} />
                    {locatingText}
                  </Button>
                </div>
              </div>

              {/* 城市选择 */}
              <div className="space-y-2">
                <Label htmlFor="city" className="text-base">城市 <span className="text-destructive">*</span></Label>
                <Select 
                  value={userInfo.city} 
                  onValueChange={handleCityChange}
                  disabled={!userInfo.province}
                >
                  <SelectTrigger id="city" className="h-12 text-base">
                    <SelectValue placeholder={userInfo.province ? "请选择城市" : "请先选择省份"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {selectedProvinceCities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* 隐私声明 */}
            <div className="pt-2">
              <p className="text-xs text-muted-foreground text-center">
                🔒 <strong>隐私保护承诺：</strong>您的所有信息将被严格保密，仅用于生成个性化评估报告。我们不会将您的信息用于其他用途或与第三方分享。
              </p>
            </div>

            {/* 提交按钮 */}
            <div className="pt-4 space-y-3">
              <Button
                onClick={handleSubmit}
                className="w-full h-12 text-base gap-2"
              >
                <ArrowRight className="h-5 w-5" />
                提交并继续
              </Button>
              
              {/* 返回首页按钮 */}
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/')}
                className="w-full h-12 text-base gap-2"
              >
                <Home className="h-5 w-5" />
                返回首页
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-6">
        <div className="container mx-auto px-4 max-w-3xl">
          <p className="text-xs text-muted-foreground text-center">
            免责声明：本工具仅供参考，不能替代专业医疗诊断。如有疑虑，请及时就医咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { ArrowLeft, ArrowRight, CheckCircle, Volume2 } from 'lucide-react';
import { AudioButton } from '@/components/ui/AudioButton';
import { getScaleQuestions } from '@/data/scales';
import { safeSpeak, stopVoice, initAudioContext } from '@/utils/voice';
import { 
  autoScoreTimeOrientation, 
  autoScoreMemory,
  autoScoreNumber,
  autoScoreText,
  generateYearOptions, 
  generateMonthOptions, 
  generateDayOptions,
  getFormattedCurrentDate
} from '@/utils/timeOrientation';
import type { ScaleType, ScaleAnswer } from '@/types/screening';

export default function SingleQuestionPage() {
  const navigate = useNavigate();
  const { scaleId, questionIndex } = useParams<{ scaleId: string; questionIndex: string }>();
  const { updateScaleAnswer, getScaleAnswers } = useScreening();

  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [multipleAnswers, setMultipleAnswers] = useState<string[]>(['', '', '']); // 用于多输入框题目
  const [selectedWords, setSelectedWords] = useState<string[]>([]); // 用于memory_recall类型
  const [showExitDialog, setShowExitDialog] = useState(false);

  const questions = getScaleQuestions(scaleId || '');
  const currentIndex = parseInt(questionIndex || '1') - 1;
  const currentQuestion = questions[currentIndex];
  const totalQuestions = questions.length;

  // 组件挂载时初始化音频上下文（移动端必需）
  useEffect(() => {
    const handleFirstInteraction = () => {
      initAudioContext();
      console.log('SingleQuestionPage: 音频上下文已初始化');
    };

    // 监听首次用户交互
    document.addEventListener('click', handleFirstInteraction, { once: true });
    document.addEventListener('touchstart', handleFirstInteraction, { once: true });

    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, []);

  // 加载已保存的答案
  useEffect(() => {
    if (scaleId && currentQuestion) {
      const savedAnswers = getScaleAnswers(scaleId as ScaleType);
      const savedAnswer = savedAnswers.find(a => a.questionId === currentQuestion.id);
      if (savedAnswer) {
        // 如果是多输入框题目，解析答案
        if (currentQuestion.type === 'memory_input' && savedAnswer.answer.includes('|')) {
          setMultipleAnswers(savedAnswer.answer.split('|'));
        } else if (currentQuestion.type === 'memory_recall' && savedAnswer.answer.includes('|')) {
          // 如果是memory_recall类型，解析答案
          setSelectedWords(savedAnswer.answer.split('|'));
        } else {
          setSelectedAnswer(savedAnswer.answer);
        }
      } else {
        setSelectedAnswer('');
        setMultipleAnswers(['', '', '']);
        setSelectedWords([]);
      }
    }
  }, [scaleId, currentQuestion, getScaleAnswers]);

  if (!scaleId || !currentQuestion) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">量表或问题不存在</p>
          <Button onClick={() => navigate('/scales')} className="mt-4">
            返回量表选择
          </Button>
        </div>
      </div>
    );
  }

  const handleSelectAnswer = (value: string) => {
    setSelectedAnswer(value);
    
    // 播放语音（使用安全的播报函数）
    const selectedOption = currentQuestion.options.find(opt => opt.value === value);
    if (selectedOption) {
      safeSpeak(selectedOption.label);
    }
  };

  const handleMultipleAnswerChange = (index: number, value: string) => {
    const newAnswers = [...multipleAnswers];
    newAnswers[index] = value;
    setMultipleAnswers(newAnswers);
  };

  const handleWordToggle = (word: string) => {
    setSelectedWords(prev => {
      if (prev.includes(word)) {
        return prev.filter(w => w !== word);
      } else {
        return [...prev, word];
      }
    });
  };

  const handleBackToScales = () => {
    // 停止所有语音播报
    stopVoice();
    setShowExitDialog(true);
  };

  const confirmBackToScales = () => {
    // 停止所有语音播报
    stopVoice();
    setShowExitDialog(false);
    navigate('/scales');
  };

  const handleNext = () => {
    // 指导语类型的题目不需要验证答案
    if (currentQuestion.type === 'instruction') {
      if (!selectedAnswer) {
        alert('请点击"我已记住，继续"按钮');
        return;
      }
    } else if (currentQuestion.type === 'memory_input') {
      // 多输入框题目，至少需要填写一个
      if (multipleAnswers.every(ans => !ans.trim())) {
        alert('请至少填写一个答案');
        return;
      }
    } else if (currentQuestion.type === 'memory_recall') {
      // memory_recall类型，至少需要选择一个词
      if (selectedWords.length === 0) {
        alert('请至少选择一个词');
        return;
      }
    } else {
      // 其他题目需要选择或输入答案
      if (!selectedAnswer) {
        alert('请选择或输入答案后再继续');
        return;
      }
    }

    // 保存答案
    let score = 0;
    let answerValue = selectedAnswer;
    
    // 根据题目类型计分
    if (currentQuestion.autoScore && currentQuestion.type) {
      switch (currentQuestion.type) {
        case 'year':
        case 'season':
        case 'month':
        case 'day':
        case 'weekday':
          // 时间定向力题目
          score = autoScoreTimeOrientation(currentQuestion.type, selectedAnswer);
          break;
        
        case 'memory_input':
          // 记忆力题目（多输入框）
          score = autoScoreMemory(multipleAnswers, currentQuestion.correctAnswers || []);
          answerValue = multipleAnswers.join('|'); // 用|分隔多个答案
          break;
        
        case 'memory_recall':
          // 延迟回忆题目（多选按钮）
          const correctAnswers = currentQuestion.correctAnswers || [];
          score = selectedWords.filter(word => correctAnswers.includes(word)).length;
          answerValue = selectedWords.join('|'); // 用|分隔多个答案
          break;
        
        case 'number_input':
          // 数字输入题目
          score = autoScoreNumber(selectedAnswer, currentQuestion.correctAnswers?.[0] || '');
          break;
        
        case 'text_input':
          // 文本输入题目
          score = autoScoreText(selectedAnswer, currentQuestion.correctAnswers || []);
          break;
        
        default:
          score = 0;
      }
    } else if (currentQuestion.type === 'instruction') {
      // 指导语题目不计分
      score = 0;
    } else {
      // 普通题目，从选项中获取分数
      const selectedOption = currentQuestion.options.find(opt => opt.value === selectedAnswer);
      score = selectedOption?.score || 0;
    }

    const answer: ScaleAnswer = {
      questionId: currentQuestion.id,
      answer: answerValue,
      score: score
    };
    updateScaleAnswer(scaleId as ScaleType, answer);

    // 判断是否是最后一题
    if (currentIndex < totalQuestions - 1) {
      // 跳转到下一题
      navigate(`/question/${scaleId}/${currentIndex + 2}`);
    } else {
      // 跳转到结果页
      navigate('/result');
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      navigate(`/question/${scaleId}/${currentIndex}`);
    } else {
      navigate('/scales');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 顶部进度 */}
      <header className="border-b bg-card py-6">
        <div className="container mx-auto px-4">
          <div className="relative">
            {/* 返回按钮 - 左上角 */}
            <div className="absolute left-0 top-0">
              <Button
                variant="ghost"
                onClick={handleBackToScales}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                返回大厅
              </Button>
            </div>

            {/* 进度信息 - 居中 */}
            <div className="text-center">
              <h1 className="text-3xl md:text-4xl font-bold text-primary mb-2">
                第 {currentIndex + 1} 题 / 共 {totalQuestions} 题
              </h1>
              <div className="w-full max-w-md mx-auto mt-4">
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary transition-all duration-300"
                    style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8 flex items-center justify-center">
        <div className="w-full max-w-3xl">
          {/* 问题卡片 */}
          <Card className="shadow-xl border-2 mb-8">
            <CardContent className="pt-8 pb-8">
              {/* 当前日期参考（仅对时间定向题目显示） */}
              {(currentQuestion.type === 'year' || 
                currentQuestion.type === 'season' || 
                currentQuestion.type === 'month' || 
                currentQuestion.type === 'day' || 
                currentQuestion.type === 'weekday') && (
                <div className="mb-6 p-4 bg-primary/5 rounded-lg border-2 border-primary/20">
                  <p className="text-center text-lg font-semibold text-primary">
                    📅 今天是：{getFormattedCurrentDate()}
                  </p>
                </div>
              )}

              {/* 问题文本 */}
              <div className="mb-8">
                <div className="flex items-start justify-between gap-4">
                  <h2 className="text-2xl md:text-3xl font-semibold text-foreground leading-relaxed text-center flex-1">
                    {currentQuestion.text}
                  </h2>
                  <AudioButton 
                    text={currentQuestion.text}
                    label="听题目"
                    className="shrink-0"
                  />
                </div>
              </div>

              {/* 选项区域 - 根据题目类型渲染不同的输入组件 */}
              <div className="space-y-4">
                {/* 年份选择器 */}
                {currentQuestion.type === 'year' && (
                  <div className="space-y-3">
                    <Label htmlFor="year-select" className="text-lg font-semibold">
                      请选择年份：
                    </Label>
                    <Select value={selectedAnswer} onValueChange={setSelectedAnswer}>
                      <SelectTrigger id="year-select" className="w-full h-14 text-xl">
                        <SelectValue placeholder="请选择年份" />
                      </SelectTrigger>
                      <SelectContent>
                        {generateYearOptions().map((option) => (
                          <SelectItem key={option.value} value={option.value} className="text-lg">
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* 季节单选按钮组 */}
                {currentQuestion.type === 'season' && (
                  <div className="space-y-3">
                    <Label className="text-lg font-semibold">请选择季节：</Label>
                    <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} className="grid grid-cols-2 gap-4">
                      {currentQuestion.options.map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} id={`season-${option.value}`} className="h-6 w-6" />
                          <Label
                            htmlFor={`season-${option.value}`}
                            className="text-xl font-semibold cursor-pointer flex-1 p-4 rounded-lg border-2 transition-all hover:border-primary hover:bg-primary/5"
                          >
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                )}

                {/* 月份选择器 */}
                {currentQuestion.type === 'month' && (
                  <div className="space-y-3">
                    <Label htmlFor="month-select" className="text-lg font-semibold">
                      请选择月份：
                    </Label>
                    <Select value={selectedAnswer} onValueChange={setSelectedAnswer}>
                      <SelectTrigger id="month-select" className="w-full h-14 text-xl">
                        <SelectValue placeholder="请选择月份" />
                      </SelectTrigger>
                      <SelectContent>
                        {generateMonthOptions().map((option) => (
                          <SelectItem key={option.value} value={option.value} className="text-lg">
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* 日期选择器 */}
                {currentQuestion.type === 'day' && (
                  <div className="space-y-3">
                    <Label htmlFor="day-select" className="text-lg font-semibold">
                      请选择日期：
                    </Label>
                    <Select value={selectedAnswer} onValueChange={setSelectedAnswer}>
                      <SelectTrigger id="day-select" className="w-full h-14 text-xl">
                        <SelectValue placeholder="请选择日期" />
                      </SelectTrigger>
                      <SelectContent>
                        {generateDayOptions().map((option) => (
                          <SelectItem key={option.value} value={option.value} className="text-lg">
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* 星期单选按钮组 */}
                {currentQuestion.type === 'weekday' && (
                  <div className="space-y-3">
                    <Label className="text-lg font-semibold">请选择星期：</Label>
                    <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} className="grid grid-cols-2 gap-4">
                      {currentQuestion.options.map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} id={`weekday-${option.value}`} className="h-6 w-6" />
                          <Label
                            htmlFor={`weekday-${option.value}`}
                            className="text-xl font-semibold cursor-pointer flex-1 p-4 rounded-lg border-2 transition-all hover:border-primary hover:bg-primary/5"
                          >
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                )}

                {/* 指导语页面 */}
                {currentQuestion.type === 'instruction' && (
                  <div className="space-y-6">
                    <div className="rounded-xl p-8">
                      <p className="text-2xl md:text-3xl font-bold text-center text-foreground whitespace-pre-line leading-relaxed">
                        {currentQuestion.instructionText}
                      </p>
                    </div>
                    <Button
                      onClick={() => setSelectedAnswer('understood')}
                      variant={selectedAnswer === 'understood' ? 'default' : 'outline'}
                      size="lg"
                      className="w-full text-xl py-6"
                    >
                      <CheckCircle className="h-6 w-6 mr-2" />
                      我已记住，继续
                    </Button>
                  </div>
                )}

                {/* 记忆力输入（多个输入框） */}
                {currentQuestion.type === 'memory_input' && (
                  <div className="space-y-4">
                    <Label className="text-lg font-semibold">
                      {currentQuestion.id === 10 ? '请输入您还记得的词语：' : '请输入您记住的三个词：'}
                    </Label>
                    <div className="space-y-3">
                      {[0, 1, 2].map((index) => (
                        <div key={index} className="space-y-2">
                          <Label htmlFor={`memory-${index}`} className="text-base text-muted-foreground">
                            词 {index + 1}：
                          </Label>
                          <Input
                            id={`memory-${index}`}
                            type="text"
                            value={multipleAnswers[index]}
                            onChange={(e) => handleMultipleAnswerChange(index, e.target.value)}
                            placeholder="请输入答案"
                            className="h-14 text-xl"
                          />
                        </div>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      提示：请按您记得的顺序填写，顺序不影响评分
                    </p>
                  </div>
                )}

                {/* 延迟回忆（多选按钮矩阵） */}
                {currentQuestion.type === 'memory_recall' && (
                  <div className="space-y-4">
                    <Label className="text-lg font-semibold">
                      请勾选您记得的词语（可以选择多个）：
                    </Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {currentQuestion.options.map((option) => (
                        <button
                          key={option.value}
                          onClick={() => handleWordToggle(option.label)}
                          className={`p-6 rounded-xl border-3 transition-all duration-200 flex items-center gap-3 ${
                            selectedWords.includes(option.label)
                              ? 'border-primary bg-primary/10 shadow-lg'
                              : 'border-border hover:border-primary/50 hover:bg-muted/50'
                          }`}
                        >
                          <Checkbox
                            checked={selectedWords.includes(option.label)}
                            className="h-6 w-6"
                          />
                          <span className={`text-xl font-semibold ${
                            selectedWords.includes(option.label)
                              ? 'text-primary'
                              : 'text-foreground'
                          }`}>
                            {option.label}
                          </span>
                        </button>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      已选择 {selectedWords.length} 个词语
                    </p>
                  </div>
                )}

                {/* 数字输入框 */}
                {currentQuestion.type === 'number_input' && (
                  <div className="space-y-3">
                    <Label htmlFor="number-input" className="text-lg font-semibold">
                      请输入您的答案：
                    </Label>
                    <Input
                      id="number-input"
                      type="number"
                      value={selectedAnswer}
                      onChange={(e) => setSelectedAnswer(e.target.value)}
                      placeholder="请输入数字"
                      className="h-14 text-xl"
                    />
                  </div>
                )}

                {/* 文本输入框（带图片） */}
                {currentQuestion.type === 'text_input' && (
                  <div className="space-y-4">
                    {/* 显示图片 */}
                    {currentQuestion.imageUrl && (
                      <div className="flex justify-center mb-6">
                        <img
                          src={currentQuestion.imageUrl}
                          alt="题目图片"
                          className="max-w-md w-full h-auto rounded-lg shadow-lg border-2 border-border"
                        />
                      </div>
                    )}
                    <Label htmlFor="text-input" className="text-lg font-semibold">
                      请输入您的答案：
                    </Label>
                    <Input
                      id="text-input"
                      type="text"
                      value={selectedAnswer}
                      onChange={(e) => setSelectedAnswer(e.target.value)}
                      placeholder="请输入答案"
                      className="h-14 text-xl"
                    />
                  </div>
                )}

                {/* 普通单选按钮（默认） */}
                {!currentQuestion.type && currentQuestion.options.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleSelectAnswer(option.value)}
                    className={`w-full p-6 md:p-8 rounded-xl border-3 transition-all duration-200 flex items-center justify-between group ${
                      selectedAnswer === option.value
                        ? 'border-primary bg-primary/10 shadow-lg scale-[1.02]'
                        : 'border-border hover:border-primary/50 hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      {/* 选中指示器 */}
                      <div className={`shrink-0 w-8 h-8 rounded-full border-3 flex items-center justify-center transition-all ${
                        selectedAnswer === option.value
                          ? 'border-primary bg-primary'
                          : 'border-muted-foreground/30'
                      }`}>
                        {selectedAnswer === option.value && (
                          <CheckCircle className="h-5 w-5 text-primary-foreground" />
                        )}
                      </div>
                      
                      {/* 选项文字 */}
                      <span className={`text-xl md:text-2xl font-semibold transition-colors text-left ${
                        selectedAnswer === option.value
                          ? 'text-primary'
                          : 'text-foreground group-hover:text-primary'
                      }`}>
                        {option.label}
                      </span>
                    </div>

                    {/* 小喇叭图标 */}
                    <Volume2 className={`h-6 w-6 shrink-0 transition-colors ${
                      selectedAnswer === option.value
                        ? 'text-primary'
                        : 'text-muted-foreground group-hover:text-primary'
                    }`} />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 导航按钮 */}
          <div className="flex items-center justify-between gap-4">
            {currentIndex > 0 ? (
              <Button
                variant="outline"
                size="lg"
                onClick={handlePrevious}
                className="gap-2 text-lg px-8 py-6"
              >
                <ArrowLeft className="h-5 w-5" />
                上一题
              </Button>
            ) : (
              <div className="w-32"></div>
            )}

            <Button
              size="lg"
              onClick={handleNext}
              disabled={
                currentQuestion.type === 'memory_input'
                  ? multipleAnswers.every(ans => !ans.trim()) // 记忆力题目：检查是否至少有一个输入框有内容
                  : currentQuestion.type === 'memory_recall'
                  ? selectedWords.length === 0 // 延迟回忆题目：检查是否至少选择了一个词
                  : !selectedAnswer // 其他题目：检查selectedAnswer
              }
              className="gap-2 text-lg px-8 py-6"
            >
              {currentIndex < totalQuestions - 1 ? (
                <>
                  下一题
                  <ArrowRight className="h-5 w-5" />
                </>
              ) : (
                <>
                  提交问卷
                  <CheckCircle className="h-5 w-5" />
                </>
              )}
            </Button>
          </div>
        </div>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-4">
        <div className="container mx-auto px-4">
          <p className="text-xs text-center text-muted-foreground">
            免责声明：本工具仅供初步筛查参考，不能替代专业医学诊断。如有疑虑，请及时咨询专业医生。
          </p>
        </div>
      </footer>

      {/* 返回确认对话框 */}
      <AlertDialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确定要返回量表大厅吗？</AlertDialogTitle>
            <AlertDialogDescription>
              当前答题进度已自动保存，您可以随时回来继续作答。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={confirmBackToScales}>
              确定返回
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

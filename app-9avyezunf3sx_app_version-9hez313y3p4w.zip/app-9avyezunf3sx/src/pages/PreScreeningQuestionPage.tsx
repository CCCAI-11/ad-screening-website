import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useScreening } from '@/contexts/ScreeningContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, ArrowRight, CheckCircle, Volume2, Home } from 'lucide-react';
import { AudioButton } from '@/components/ui/AudioButton';
import { preScreeningQuestions } from '@/data/preScreening';
import { playVoice } from '@/utils/voice';

export default function PreScreeningQuestionPage() {
  const navigate = useNavigate();
  const { questionId } = useParams<{ questionId: string }>();
  const { screeningData, updatePreScreeningAnswer } = useScreening();

  const currentQuestionIndex = parseInt(questionId || '1') - 1;
  const currentQuestion = preScreeningQuestions[currentQuestionIndex];
  const totalQuestions = preScreeningQuestions.length;

  const [selectedAnswer, setSelectedAnswer] = useState<'yes' | 'no' | ''>('');

  useEffect(() => {
    // 检查是否有效的问题ID
    if (!currentQuestion) {
      navigate('/pre-screening/1');
      return;
    }

    // 加载已保存的答案
    const savedAnswer = screeningData.preScreening.find(
      a => a.questionId === currentQuestion.id
    );
    if (savedAnswer) {
      setSelectedAnswer(savedAnswer.answer);
    } else {
      setSelectedAnswer('');
    }
  }, [currentQuestion, screeningData.preScreening, navigate]);

  const handleSelectAnswer = (answer: 'yes' | 'no') => {
    setSelectedAnswer(answer);
    // 保存答案
    updatePreScreeningAnswer({
      questionId: currentQuestion.id,
      answer
    });
    // 播放语音
    const option = currentQuestion.options.find(opt => opt.value === answer);
    if (option) {
      playVoice(option.label);
    }
  };

  const handleNext = () => {
    if (!selectedAnswer) {
      alert('请选择一个答案后再继续');
      return;
    }

    if (currentQuestionIndex < totalQuestions - 1) {
      // 跳转到下一题
      navigate(`/pre-screening/${currentQuestionIndex + 2}`);
    } else {
      // 最后一题，跳转到初步评估结果页
      navigate('/pre-screening-result');
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      navigate(`/pre-screening/${currentQuestionIndex}`);
    }
  };

  if (!currentQuestion) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 顶部进度 */}
      <header className="border-b bg-card py-6">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-primary mb-2">
              问题 {currentQuestionIndex + 1} / {totalQuestions}
            </h1>
            <div className="w-full max-w-md mx-auto mt-4">
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${((currentQuestionIndex + 1) / totalQuestions) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8 flex items-center justify-center">
        <div className="w-full max-w-3xl">
          {/* 第一题时显示说明 */}
          {currentQuestionIndex === 0 && (
            <Card className="shadow-lg border-2 border-primary/30 mb-6 bg-primary/5">
              <CardContent className="pt-6 pb-6">
                <h2 className="text-xl md:text-2xl font-bold text-primary mb-3">
                  预筛查问卷
                </h2>
                <div className="space-y-2 text-foreground">
                  <p>• 接下来，您将回答{totalQuestions}个简单的预筛查问题</p>
                  <p>• 这些问题将帮助我们初步了解您的认知状况</p>
                  <p>• 请根据您的实际情况如实回答</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 问题卡片 */}
          <Card className="shadow-xl border-2 mb-8">
            <CardContent className="pt-8 pb-8">
              {/* 问题文本 */}
              <div className="mb-8">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <h2 className="text-2xl md:text-3xl font-semibold text-foreground leading-relaxed flex-1">
                    {currentQuestion.text}
                  </h2>
                  <AudioButton 
                    text={currentQuestion.text}
                    className="shrink-0"
                  />
                </div>
              </div>

              {/* 选项按钮 */}
              <div className="space-y-4">
                {currentQuestion.options.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleSelectAnswer(option.value as 'yes' | 'no')}
                    className={`w-full p-6 md:p-8 rounded-xl border-3 transition-all duration-200 flex items-center justify-between group ${
                      selectedAnswer === option.value
                        ? 'border-primary bg-primary/10 shadow-lg scale-[1.02]'
                        : 'border-border hover:border-primary/50 hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      {/* 选中指示器 */}
                      <div className={`shrink-0 w-8 h-8 rounded-full border-3 flex items-center justify-center transition-all ${
                        selectedAnswer === option.value
                          ? 'border-primary bg-primary'
                          : 'border-muted-foreground/30'
                      }`}>
                        {selectedAnswer === option.value && (
                          <CheckCircle className="h-5 w-5 text-primary-foreground" />
                        )}
                      </div>
                      
                      {/* 选项文字 */}
                      <span className={`text-2xl md:text-3xl font-bold transition-colors ${
                        selectedAnswer === option.value
                          ? 'text-primary'
                          : 'text-foreground group-hover:text-primary'
                      }`}>
                        {option.label}
                      </span>
                    </div>

                    {/* 小喇叭图标 */}
                    <Volume2 className={`h-6 w-6 shrink-0 transition-colors ${
                      selectedAnswer === option.value
                        ? 'text-primary'
                        : 'text-muted-foreground group-hover:text-primary'
                    }`} />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 导航按钮 */}
          <div className="flex items-center justify-between gap-4">
            {/* 左侧按钮：第一题显示"返回首页"，其他题显示"上一题"或占位符 */}
            {currentQuestionIndex === 0 ? (
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => navigate('/')}
                className="gap-2 text-lg px-8 py-6"
              >
                <Home className="h-5 w-5" />
                返回首页
              </Button>
            ) : currentQuestionIndex > 0 ? (
              <Button
                variant="outline"
                size="lg"
                onClick={handlePrevious}
                className="gap-2 text-lg px-8 py-6"
              >
                <ArrowLeft className="h-5 w-5" />
                上一题
              </Button>
            ) : (
              <div className="w-32"></div>
            )}

            {/* 右侧按钮：下一题或完成预筛 */}
            <Button
              size="lg"
              onClick={handleNext}
              disabled={!selectedAnswer}
              className="gap-2 text-lg px-8 py-6"
            >
              {currentQuestionIndex < totalQuestions - 1 ? (
                <>
                  下一题
                  <ArrowRight className="h-5 w-5" />
                </>
              ) : (
                <>
                  完成预筛
                  <CheckCircle className="h-5 w-5" />
                </>
              )}
            </Button>
          </div>
        </div>
      </main>

      {/* 底部免责声明 */}
      <footer className="border-t bg-muted/30 py-4">
        <div className="container mx-auto px-4">
          <p className="text-xs text-center text-muted-foreground">
            免责声明：本工具仅供初步筛查参考，不能替代专业医学诊断。如有疑虑，请及时咨询专业医生。
          </p>
        </div>
      </footer>
    </div>
  );
}

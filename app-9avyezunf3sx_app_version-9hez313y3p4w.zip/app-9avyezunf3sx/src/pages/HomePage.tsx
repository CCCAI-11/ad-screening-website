import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Brain, Heart, Shield, ArrowRight } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();
  const [memoryAnswer, setMemoryAnswer] = useState<'yes' | 'no' | ''>('');

  const handleStartAssessment = () => {
    navigate('/user-info');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* 主要内容区 */}
      <main className="flex-1 container mx-auto px-4 py-8 md:py-12 max-w-4xl">
        {/* 海报区域 - 增加开场互动 */}
        <div className="relative bg-gradient-to-br from-sky-100 via-emerald-50 to-green-100 rounded-3xl overflow-hidden shadow-2xl mb-8">
          {/* 背景装饰图 */}
          <div className="absolute inset-0 opacity-90">
            <img 
              src="https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_bd6319f3-2738-4dc7-a083-132e3a537479.jpg"
              alt="认知筛查背景"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-white/20 to-white/60" />
          </div>

          {/* 内容层 */}
          <div className="relative z-10 p-8 md:p-12 text-center">
            <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 md:p-10 shadow-lg max-w-2xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold mb-6">
                <span className="bg-gradient-to-r from-emerald-600 to-green-500 bg-clip-text text-transparent">
                  认知筛查
                </span>
              </h1>
              
              {/* 开场互动问题 */}
              <div className="mb-8 p-6 bg-gradient-to-br from-emerald-50 to-green-50 rounded-xl border-2 border-emerald-200">
                <p className="text-lg font-medium text-gray-800 mb-5 leading-relaxed">
                  为了给您更合适的建议，请先回答：<br />
                  <span className="text-emerald-700 font-semibold">您最近是否感觉记忆力比半年前明显下降了？</span>
                </p>
                
                {/* 大按钮选项 */}
                <RadioGroup
                  value={memoryAnswer}
                  onValueChange={(value) => setMemoryAnswer(value as 'yes' | 'no')}
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="relative">
                    <RadioGroupItem
                      value="yes"
                      id="memory-yes"
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor="memory-yes"
                      className="flex items-center justify-center h-16 px-6 rounded-xl border-3 border-emerald-300 bg-white cursor-pointer transition-all hover:border-emerald-500 hover:bg-emerald-50 hover:shadow-lg peer-data-[state=checked]:border-emerald-600 peer-data-[state=checked]:bg-emerald-100 peer-data-[state=checked]:shadow-xl peer-data-[state=checked]:scale-105"
                    >
                      <span className="text-lg font-semibold text-gray-800">是</span>
                    </Label>
                  </div>
                  <div className="relative">
                    <RadioGroupItem
                      value="no"
                      id="memory-no"
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor="memory-no"
                      className="flex items-center justify-center h-16 px-6 rounded-xl border-3 border-emerald-300 bg-white cursor-pointer transition-all hover:border-emerald-500 hover:bg-emerald-50 hover:shadow-lg peer-data-[state=checked]:border-emerald-600 peer-data-[state=checked]:bg-emerald-100 peer-data-[state=checked]:shadow-xl peer-data-[state=checked]:scale-105"
                    >
                      <span className="text-lg font-semibold text-gray-800">否</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* 核心行动按钮 - 最突出的视觉元素 */}
              <Button 
                size="lg" 
                className="text-xl px-12 py-7 shadow-2xl hover:shadow-3xl transition-all duration-300 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-600 hover:via-green-600 hover:to-emerald-700 transform hover:scale-105 font-bold border-2 border-emerald-400 w-full md:w-auto"
                onClick={handleStartAssessment}
              >
                <span className="flex items-center gap-3">
                  开始完整评估
                  <ArrowRight className="h-6 w-6" />
                </span>
              </Button>

              {/* 提示文字 */}
              <p className="text-sm text-gray-600 mt-4">
                通过专业量表进行认知功能评估，帮助您及早发现认知障碍风险
              </p>
            </div>
          </div>
        </div>

        {/* 使用说明 - 移到特点介绍之前 */}
        <Card className="bg-gradient-to-br from-white to-emerald-50/50 border-2 border-emerald-200 shadow-lg mb-8">
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-6 text-center text-emerald-900">使用说明</h2>
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="flex gap-4 items-start bg-white/60 rounded-xl p-4 hover:shadow-md transition-shadow">
                <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-md">1</span>
                <div>
                  <p className="font-medium text-emerald-900 mb-1">快速预筛</p>
                  <p className="text-sm text-gray-600">5个简单问题，初步了解认知状况</p>
                </div>
              </div>
              <div className="flex gap-4 items-start bg-white/60 rounded-xl p-4 hover:shadow-md transition-shadow">
                <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-md">2</span>
                <div>
                  <p className="font-medium text-emerald-900 mb-1">选择量表</p>
                  <p className="text-sm text-gray-600">根据需求选择专业评估量表</p>
                </div>
              </div>
              <div className="flex gap-4 items-start bg-white/60 rounded-xl p-4 hover:shadow-md transition-shadow">
                <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-md">3</span>
                <div>
                  <p className="font-medium text-emerald-900 mb-1">查看结果</p>
                  <p className="text-sm text-gray-600">获取专业分析和健康建议</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 特点介绍 - 移到使用说明之后 */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="border-2 hover:border-emerald-400 transition-colors bg-gradient-to-br from-white to-emerald-50/30">
            <CardContent className="pt-6 text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-md">
                <Brain className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-base mb-1 text-emerald-900">便利性</h3>
              <p className="text-sm text-gray-600">
                3-10分钟快速筛查
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-emerald-400 transition-colors bg-gradient-to-br from-white to-emerald-50/30">
            <CardContent className="pt-6 text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-md">
                <Shield className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-base mb-1 text-emerald-900">权威性</h3>
              <p className="text-sm text-gray-600">
                医疗级测评工具
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-emerald-400 transition-colors bg-gradient-to-br from-white to-emerald-50/30">
            <CardContent className="pt-6 text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-md">
                <Heart className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-base mb-1 text-emerald-900">有效性</h3>
              <p className="text-sm text-gray-600">
                筛查准确率90%
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-emerald-400 transition-colors bg-gradient-to-br from-white to-emerald-50/30">
            <CardContent className="pt-6 text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-md">
                <Brain className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-base mb-1 text-emerald-900">专业性</h3>
              <p className="text-sm text-gray-600">
                国际通用量表
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* 免责声明 */}
      <footer className="bg-muted/30 border-t border-border py-6 mt-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <p className="text-xs text-muted-foreground text-center leading-relaxed">
            <strong className="text-foreground">免责声明：</strong>
            本筛查工具仅供参考，不能替代专业医疗诊断。如果您或您的家人出现认知功能下降的迹象，请及时咨询专业医生进行全面评估。早期发现、早期诊断、早期干预对于延缓疾病进展具有重要意义。
          </p>
        </div>
      </footer>
    </div>
  );
}

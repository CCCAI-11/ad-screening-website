/**
 * localStorage 工具函数
 * 提供兼容性检查和错误处理
 */

/**
 * 检查localStorage是否可用
 */
export const isLocalStorageAvailable = (): boolean => {
  try {
    if (typeof Storage === 'undefined') {
      return false;
    }
    const testKey = '__localStorage_test__';
    localStorage.setItem(testKey, 'test');
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * 安全地获取localStorage数据
 */
export const safeGetItem = (key: string): string | null => {
  try {
    if (!isLocalStorageAvailable()) {
      console.warn('localStorage不可用');
      return null;
    }
    return localStorage.getItem(key);
  } catch (error) {
    console.error('读取localStorage失败:', error);
    return null;
  }
};

/**
 * 安全地设置localStorage数据
 */
export const safeSetItem = (key: string, value: string): boolean => {
  try {
    if (!isLocalStorageAvailable()) {
      console.warn('localStorage不可用');
      return false;
    }
    
    // 检查存储空间
    const estimatedSize = new Blob([value]).size;
    if (estimatedSize > 4.5 * 1024 * 1024) { // 4.5MB警告阈值
      console.warn('数据大小接近localStorage限制:', estimatedSize / 1024 / 1024, 'MB');
    }
    
    localStorage.setItem(key, value);
    return true;
  } catch (error) {
    if (error instanceof DOMException) {
      if (error.name === 'QuotaExceededError') {
        console.error('localStorage存储空间已满');
        alert('存储空间不足，请清理浏览器缓存或删除部分历史记录');
      } else {
        console.error('localStorage写入失败:', error);
      }
    } else {
      console.error('localStorage写入失败:', error);
    }
    return false;
  }
};

/**
 * 安全地删除localStorage数据
 */
export const safeRemoveItem = (key: string): boolean => {
  try {
    if (!isLocalStorageAvailable()) {
      console.warn('localStorage不可用');
      return false;
    }
    localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error('删除localStorage数据失败:', error);
    return false;
  }
};

/**
 * 获取localStorage使用情况（估算）
 */
export const getLocalStorageUsage = (): { used: number; total: number; percentage: number } => {
  try {
    if (!isLocalStorageAvailable()) {
      return { used: 0, total: 0, percentage: 0 };
    }
    
    let totalSize = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        const value = localStorage.getItem(key);
        if (value) {
          totalSize += key.length + value.length;
        }
      }
    }
    
    // localStorage通常限制为5MB（5 * 1024 * 1024字节）
    const totalLimit = 5 * 1024 * 1024;
    const usedBytes = totalSize * 2; // 每个字符约2字节（UTF-16）
    const percentage = (usedBytes / totalLimit) * 100;
    
    return {
      used: usedBytes,
      total: totalLimit,
      percentage: Math.min(percentage, 100)
    };
  } catch (error) {
    console.error('获取localStorage使用情况失败:', error);
    return { used: 0, total: 0, percentage: 0 };
  }
};

/**
 * 清理localStorage中的大数据项
 */
export const cleanupLargeItems = (maxSizePerItem: number = 1024 * 1024): string[] => {
  const removedKeys: string[] = [];
  
  try {
    if (!isLocalStorageAvailable()) {
      return removedKeys;
    }
    
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        const value = localStorage.getItem(key);
        if (value) {
          const itemSize = (key.length + value.length) * 2; // UTF-16
          if (itemSize > maxSizePerItem) {
            console.warn(`清理大数据项: ${key} (${itemSize / 1024 / 1024}MB)`);
            localStorage.removeItem(key);
            removedKeys.push(key);
          }
        }
      }
    }
  } catch (error) {
    console.error('清理localStorage失败:', error);
  }
  
  return removedKeys;
};

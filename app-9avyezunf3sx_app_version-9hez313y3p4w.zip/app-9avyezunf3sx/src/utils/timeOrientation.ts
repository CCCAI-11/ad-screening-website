// 时间定向力智能判断工具函数

/**
 * 获取当前时间信息
 */
export function getCurrentTimeInfo() {
  const now = new Date();
  
  return {
    year: now.getFullYear(),
    month: now.getMonth() + 1, // 0-11 转换为 1-12
    day: now.getDate(),
    weekday: now.getDay(), // 0=星期日, 1=星期一, ..., 6=星期六
    season: getSeason(now.getMonth() + 1)
  };
}

/**
 * 获取格式化的当前日期字符串
 * @returns 格式化的日期字符串，如"2024年3月15日 星期五"
 */
export function getFormattedCurrentDate(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();
  const weekday = now.getDay();
  
  const weekdayNames = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
  const weekdayName = weekdayNames[weekday];
  
  return `${year}年${month}月${day}日 ${weekdayName}`;
}

/**
 * 根据月份判断季节
 * @param month 月份（1-12）
 * @returns 季节代码
 */
function getSeason(month: number): string {
  if (month >= 3 && month <= 5) {
    return 'spring'; // 春季：3-5月
  } else if (month >= 6 && month <= 8) {
    return 'summer'; // 夏季：6-8月
  } else if (month >= 9 && month <= 11) {
    return 'autumn'; // 秋季：9-11月
  } else {
    return 'winter'; // 冬季：12-2月
  }
}

/**
 * 判断年份答案是否正确
 * @param userAnswer 用户答案
 * @returns 是否正确
 */
export function checkYearAnswer(userAnswer: string): boolean {
  const currentYear = getCurrentTimeInfo().year;
  return userAnswer === currentYear.toString();
}

/**
 * 判断季节答案是否正确
 * @param userAnswer 用户答案
 * @returns 是否正确
 */
export function checkSeasonAnswer(userAnswer: string): boolean {
  const currentSeason = getCurrentTimeInfo().season;
  return userAnswer === currentSeason;
}

/**
 * 判断月份答案是否正确
 * @param userAnswer 用户答案
 * @returns 是否正确
 */
export function checkMonthAnswer(userAnswer: string): boolean {
  const currentMonth = getCurrentTimeInfo().month;
  return userAnswer === currentMonth.toString();
}

/**
 * 判断日期答案是否正确
 * @param userAnswer 用户答案
 * @returns 是否正确
 */
export function checkDayAnswer(userAnswer: string): boolean {
  const currentDay = getCurrentTimeInfo().day;
  return userAnswer === currentDay.toString();
}

/**
 * 判断星期答案是否正确
 * @param userAnswer 用户答案
 * @returns 是否正确
 */
export function checkWeekdayAnswer(userAnswer: string): boolean {
  const currentWeekday = getCurrentTimeInfo().weekday;
  return userAnswer === currentWeekday.toString();
}

/**
 * 根据题目类型自动判断答案并计分
 * @param questionType 题目类型
 * @param userAnswer 用户答案
 * @returns 得分（0或1）
 */
export function autoScoreTimeOrientation(questionType: string, userAnswer: string): number {
  if (!userAnswer) return 0;

  let isCorrect = false;

  switch (questionType) {
    case 'year':
      isCorrect = checkYearAnswer(userAnswer);
      break;
    case 'season':
      isCorrect = checkSeasonAnswer(userAnswer);
      break;
    case 'month':
      isCorrect = checkMonthAnswer(userAnswer);
      break;
    case 'day':
      isCorrect = checkDayAnswer(userAnswer);
      break;
    case 'weekday':
      isCorrect = checkWeekdayAnswer(userAnswer);
      break;
    default:
      return 0;
  }

  return isCorrect ? 1 : 0;
}

/**
 * 判断记忆力题目答案（多个输入框）
 * @param userAnswers 用户答案数组
 * @param correctAnswers 正确答案数组
 * @returns 得分（每对一个计1分）
 */
export function autoScoreMemory(userAnswers: string[], correctAnswers: string[]): number {
  let score = 0;
  
  // 标准化处理：去除空格、转换为小写
  const normalizedUserAnswers = userAnswers.map(ans => ans.trim().toLowerCase());
  const normalizedCorrectAnswers = correctAnswers.map(ans => ans.trim().toLowerCase());
  
  // 检查每个用户答案是否在正确答案列表中（忽略顺序）
  for (const userAns of normalizedUserAnswers) {
    if (userAns && normalizedCorrectAnswers.includes(userAns)) {
      score++;
      // 移除已匹配的答案，避免重复计分
      const index = normalizedCorrectAnswers.indexOf(userAns);
      normalizedCorrectAnswers.splice(index, 1);
    }
  }
  
  return score;
}

/**
 * 判断数字输入题目答案
 * @param userAnswer 用户答案
 * @param correctAnswer 正确答案
 * @returns 得分（0或1）
 */
export function autoScoreNumber(userAnswer: string, correctAnswer: string): number {
  if (!userAnswer) return 0;
  
  // 去除空格
  const normalizedUserAnswer = userAnswer.trim();
  const normalizedCorrectAnswer = correctAnswer.trim();
  
  return normalizedUserAnswer === normalizedCorrectAnswer ? 1 : 0;
}

/**
 * 判断文本输入题目答案（支持多个正确答案）
 * @param userAnswer 用户答案
 * @param correctAnswers 正确答案列表
 * @returns 得分（0或1）
 */
export function autoScoreText(userAnswer: string, correctAnswers: string[]): number {
  if (!userAnswer) return 0;
  
  // 标准化处理：去除空格、转换为小写
  const normalizedUserAnswer = userAnswer.trim().toLowerCase();
  
  // 检查用户答案是否包含任何一个正确答案
  for (const correctAns of correctAnswers) {
    const normalizedCorrectAns = correctAns.trim().toLowerCase();
    if (normalizedUserAnswer.includes(normalizedCorrectAns)) {
      return 1;
    }
  }
  
  return 0;
}

/**
 * 生成年份选项（当前年份前后2年，共5个选项）
 * @returns 年份选项数组
 */
export function generateYearOptions(): Array<{ value: string; label: string }> {
  const currentYear = new Date().getFullYear();
  const years: Array<{ value: string; label: string }> = [];
  
  for (let i = currentYear - 2; i <= currentYear + 2; i++) {
    years.push({
      value: i.toString(),
      label: `${i}年`
    });
  }
  
  return years;
}

/**
 * 生成月份选项（1-12月）
 * @returns 月份选项数组
 */
export function generateMonthOptions(): Array<{ value: string; label: string }> {
  const months: Array<{ value: string; label: string }> = [];
  
  for (let i = 1; i <= 12; i++) {
    months.push({
      value: i.toString(),
      label: `${i}月`
    });
  }
  
  return months;
}

/**
 * 生成日期选项（1-31日）
 * @returns 日期选项数组
 */
export function generateDayOptions(): Array<{ value: string; label: string }> {
  const days: Array<{ value: string; label: string }> = [];
  
  for (let i = 1; i <= 31; i++) {
    days.push({
      value: i.toString(),
      label: `${i}日`
    });
  }
  
  return days;
}

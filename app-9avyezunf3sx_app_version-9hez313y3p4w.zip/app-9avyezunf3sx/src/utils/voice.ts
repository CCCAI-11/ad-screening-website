// 统一的语音播报工具函数（移动端优化版）

// ========== 全局音频控制锁 ==========
let isSpeaking = false; // 标记当前是否有语音在播
let currentUtterance: SpeechSynthesisUtterance | null = null; // 存储当前语音实例
let isAudioContextInitialized = false; // 标记音频上下文是否已初始化
let availableVoices: SpeechSynthesisVoice[] = []; // 缓存可用的语音列表

// ========== 初始化语音列表 ==========
function initVoices() {
  availableVoices = window.speechSynthesis.getVoices();
  
  // 如果语音列表为空，监听voiceschanged事件
  if (availableVoices.length === 0) {
    window.speechSynthesis.addEventListener('voiceschanged', () => {
      availableVoices = window.speechSynthesis.getVoices();
      console.log('语音列表已加载:', availableVoices.length, '个语音');
    });
  }
}

// 页面加载时初始化语音列表
if (typeof window !== 'undefined') {
  initVoices();
}

// ========== 预加载音频上下文（移动端必需） ==========
/**
 * 初始化音频上下文，必须在用户交互后调用
 * 这个函数会创建一个静音的语音实例来"唤醒"音频上下文
 */
export function initAudioContext() {
  if (isAudioContextInitialized) {
    return;
  }

  try {
    // 创建一个静音的语音实例
    const silentUtterance = new SpeechSynthesisUtterance('');
    silentUtterance.volume = 0;
    silentUtterance.rate = 10; // 快速播放
    window.speechSynthesis.speak(silentUtterance);
    
    isAudioContextInitialized = true;
    console.log('音频上下文已初始化');
  } catch (error) {
    console.error('音频上下文初始化失败:', error);
  }
}

// ========== 选择最佳中文女声 ==========
function selectBestVoice(): SpeechSynthesisVoice | null {
  if (availableVoices.length === 0) {
    availableVoices = window.speechSynthesis.getVoices();
  }

  // 优先级列表（从高到低）
  const preferredVoices = [
    'Ting-Ting', // iOS中文女声
    'Yaoyao', // 部分Android设备
    'zh-CN', // 通用中文
    '女', // 包含"女"字的语音
    'Female', // 包含"Female"的语音
  ];

  for (const preferred of preferredVoices) {
    const voice = availableVoices.find(v => 
      v.lang.includes('zh') && 
      (v.name.includes(preferred) || v.lang.includes(preferred))
    );
    if (voice) {
      console.log('选择语音:', voice.name);
      return voice;
    }
  }

  // 如果没有找到，返回第一个中文语音
  const chineseVoice = availableVoices.find(v => v.lang.includes('zh'));
  if (chineseVoice) {
    console.log('使用默认中文语音:', chineseVoice.name);
    return chineseVoice;
  }

  return null;
}

// ========== 核心播报函数（带全局控制锁） ==========
/**
 * 安全播放语音（自动处理冲突）
 * @param text 要播放的文本
 * @param options 可选的语音参数
 * @returns 语音实例或null
 */
export function safeSpeak(text: string, options?: {
  rate?: number;
  pitch?: number;
  volume?: number;
  onEnd?: () => void;
  onError?: (error: SpeechSynthesisErrorEvent) => void;
}): SpeechSynthesisUtterance | null {
  try {
    // 如果正在播报，立即停止当前播报
    if (isSpeaking && currentUtterance) {
      console.log('停止当前播报，开始新播报');
      window.speechSynthesis.cancel();
      isSpeaking = false;
      currentUtterance = null;
    }

    // 创建新实例
    const utterance = new SpeechSynthesisUtterance(text);
    
    // 设置语言为中文
    utterance.lang = 'zh-CN';
    
    // 设置语速（0.8倍标准语速，适中偏慢）
    utterance.rate = options?.rate ?? 0.8;
    
    // 设置音调（1.1稍高，更亲切自然）
    utterance.pitch = options?.pitch ?? 1.1;
    
    // 设置音量
    utterance.volume = options?.volume ?? 1.0;

    // 选择最佳语音
    const voice = selectBestVoice();
    if (voice) {
      utterance.voice = voice;
    }

    // 更新全局状态
    currentUtterance = utterance;
    isSpeaking = true;

    // 绑定事件：播报结束时重置状态
    utterance.onend = () => {
      console.log('语音播报结束');
      isSpeaking = false;
      currentUtterance = null;
      options?.onEnd?.();
    };

    // 绑定错误事件
    utterance.onerror = (event) => {
      console.error('语音播报失败:', event.error, event);
      isSpeaking = false;
      currentUtterance = null;
      options?.onError?.(event);
    };

    // 开始播报
    console.log('开始播报:', text.substring(0, 50));
    window.speechSynthesis.speak(utterance);
    
    return utterance;
  } catch (error) {
    console.error('语音播放失败:', error);
    isSpeaking = false;
    currentUtterance = null;
    return null;
  }
}

// ========== 兼容旧版本的playVoice函数 ==========
/**
 * 播放语音（兼容旧版本）
 * @param text 要播放的文本
 * @param options 可选的语音参数
 */
export function playVoice(text: string, options?: {
  rate?: number;
  pitch?: number;
  volume?: number;
}) {
  // 首次调用时初始化音频上下文
  if (!isAudioContextInitialized) {
    initAudioContext();
  }

  return safeSpeak(text, options);
}

// ========== 停止当前播放 ==========
/**
 * 停止当前播放
 */
export function stopVoice() {
  try {
    window.speechSynthesis.cancel();
    isSpeaking = false;
    currentUtterance = null;
    console.log('语音播报已停止');
  } catch (error) {
    console.error('停止语音失败:', error);
  }
}

// ========== 检查是否正在播放 ==========
/**
 * 检查是否正在播放
 */
export function isVoicePlaying(): boolean {
  return isSpeaking;
}

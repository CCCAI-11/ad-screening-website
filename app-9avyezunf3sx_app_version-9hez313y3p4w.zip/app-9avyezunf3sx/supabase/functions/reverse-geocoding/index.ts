// 百度地图逆地理编码Edge Function
// 将经纬度坐标转换为省份和城市信息

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ReverseGeocodeRequest {
  latitude: number;
  longitude: number;
}

interface ReverseGeocodeResponse {
  province: string;
  city: string;
  district: string;
  formatted_address: string;
}

Deno.serve(async (req) => {
  // 处理CORS预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // 获取请求参数
    const { latitude, longitude }: ReverseGeocodeRequest = await req.json();

    if (!latitude || !longitude) {
      return new Response(
        JSON.stringify({ error: '缺少经纬度参数' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('收到逆地理编码请求:', { latitude, longitude });

    // 获取API密钥
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      console.error('未配置INTEGRATIONS_API_KEY');
      return new Response(
        JSON.stringify({ error: 'API密钥未配置' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 构建百度地图API请求URL
    // 注意：百度地图API的location参数格式为"纬度,经度"
    const location = `${latitude},${longitude}`;
    const apiUrl = `https://app-9avyezunf3sx-api-baBwZEjbe1X9-gateway.appmiaoda.com/reverse_geocoding/v3?location=${location}&coordtype=wgs84ll&extensions_poi=0&output=json&language=zh-CN`;

    console.log('调用百度地图API:', apiUrl);

    // 调用百度地图逆地理编码API
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      console.error('百度地图API请求失败:', response.status, response.statusText);
      return new Response(
        JSON.stringify({ error: '百度地图API请求失败' }),
        { 
          status: response.status, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const data = await response.json();
    console.log('百度地图API返回数据:', JSON.stringify(data));

    // 检查API返回状态
    if (data.status !== 0) {
      console.error('百度地图API返回错误:', data.message);
      return new Response(
        JSON.stringify({ error: data.message || '逆地理编码失败' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 解析地址信息
    const addressComponent = data.result?.addressComponent;
    if (!addressComponent) {
      console.error('无法解析地址信息');
      return new Response(
        JSON.stringify({ error: '无法解析地址信息' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // 提取省份和城市
    let province = addressComponent.province || '';
    let city = addressComponent.city || '';
    const district = addressComponent.district || '';
    const formatted_address = data.result?.formatted_address || '';

    // 处理直辖市情况（province和city相同）
    if (province === city) {
      // 对于直辖市，city使用district
      city = district;
    }

    // 处理空城市的情况
    if (!city && district) {
      city = district;
    }

    console.log('解析结果:', { province, city, district, formatted_address });

    // 返回结果
    const result: ReverseGeocodeResponse = {
      province,
      city,
      district,
      formatted_address,
    };

    return new Response(
      JSON.stringify(result),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Edge Function执行错误:', error);
    return new Response(
      JSON.stringify({ error: error.message || '服务器内部错误' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

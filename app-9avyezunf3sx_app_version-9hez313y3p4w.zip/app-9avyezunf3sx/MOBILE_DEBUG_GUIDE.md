# 📱 移动端调试工具使用指南

## 🎯 功能概述

这是一个完整的移动端调试解决方案，包含以下功能：

1. **自动检测移动端环境并加载 vConsole**
2. **错误捕获与显示面板**（在页面顶部显示错误）
3. **环境检测**（浏览器类型、JS API 支持情况）
4. **网络请求监控**（Fetch 和 XHR）

---

## 🚀 快速开始

### 自动启用（推荐）

调试工具会在以下环境自动启用：

- ✅ `localhost`
- ✅ `127.0.0.1`
- ✅ `192.168.x.x`（局域网）
- ✅ `10.0.x.x`（局域网）
- ✅ URL 包含 `?debug=true`

### 手动启用

在生产环境中，可以通过在 URL 后添加 `?debug=true` 来启用调试工具：

```
https://app-9avyezunf3sx.appmiaoda.com?debug=true
```

---

## 📋 功能详解

### 1. vConsole（移动端控制台）

**自动加载条件**：
- 检测到移动端环境
- 在开发环境或 URL 包含 `?debug=true`

**功能**：
- 📊 **System** - 系统信息
- 🌐 **Network** - 网络请求
- 🔍 **Element** - DOM 元素查看
- 💾 **Storage** - 本地存储查看
- 🌍 **环境** - 自定义环境信息面板

**使用方法**：
1. 在移动端打开网站
2. 点击右下角绿色的 "vConsole" 按钮
3. 选择对应的标签页查看信息

**截图示例**：
```
┌─────────────────────────┐
│  System | Network | ... │
├─────────────────────────┤
│                         │
│  控制台输出内容          │
│                         │
└─────────────────────────┘
```

---

### 2. 错误面板

**功能**：
- 在页面顶部显示所有 JavaScript 错误
- 自动捕获全局错误、Promise 错误、console.error
- 显示错误类型、消息、文件位置、堆栈信息
- 最多显示 10 个错误

**显示位置**：
```
┌─────────────────────────────────────┐
│ 🐛 错误面板 (2)              [隐藏] │
├─────────────────────────────────────┤
│ Error                    14:30:25   │
│ Cannot read property 'x' of null    │
│ 📄 app.tsx:123:45                   │
│ ▶ 堆栈信息                          │
└─────────────────────────────────────┘
```

**操作**：
- 点击 **[隐藏]** 按钮可以临时隐藏面板
- 点击 **▶ 堆栈信息** 可以展开查看详细堆栈
- 新错误会自动显示面板

**清除错误**：
```javascript
window.MobileDebug.clearErrors();
```

---

### 3. 环境检测

**检测内容**：

#### 基本信息
- 是否为移动端
- 浏览器类型（微信、QQ、UC、Safari、Chrome 等）
- 操作系统（iOS、Android 版本）
- 屏幕尺寸
- 视口尺寸
- 设备像素比
- 语言
- 在线状态

#### API 支持情况（25+ API）
- ✅ Promise
- ✅ fetch
- ✅ localStorage / sessionStorage
- ✅ IndexedDB
- ✅ WebSocket
- ✅ Geolocation
- ✅ ServiceWorker
- ✅ WebWorker
- ✅ WebRTC
- ✅ WebGL
- ✅ SpeechSynthesis
- ✅ SpeechRecognition
- ✅ Notification
- ✅ Vibration
- ✅ Battery
- ✅ DeviceOrientation
- ✅ DeviceMotion
- ✅ TouchEvents
- ✅ PointerEvents
- ✅ IntersectionObserver
- ✅ MutationObserver
- ✅ ResizeObserver
- ✅ PerformanceObserver

**查看方式**：

1. **控制台输出**：
   - 打开 vConsole
   - 查看 Console 标签页
   - 找到 "📱 环境信息" 和 "🔧 API 支持情况" 分组

2. **vConsole 环境标签**：
   - 打开 vConsole
   - 点击 "环境" 标签页
   - 查看完整的环境信息

3. **编程方式**：
   ```javascript
   const envInfo = window.MobileDebug.getEnvInfo();
   console.log(envInfo);
   ```

**输出示例**：
```javascript
{
  isMobile: true,
  browser: "微信浏览器",
  os: "iOS 15.0",
  screenSize: "375x667",
  viewportSize: "375x667",
  devicePixelRatio: 2,
  language: "zh-CN",
  platform: "iPhone",
  cookieEnabled: true,
  onLine: true,
  apiSupport: {
    Promise: true,
    fetch: true,
    localStorage: true,
    // ... 更多 API
  }
}
```

---

### 4. 网络请求监控

**监控类型**：
- Fetch API
- XMLHttpRequest (XHR)

**监控信息**：
- 请求方法（GET、POST 等）
- 请求 URL
- 响应状态码
- 响应时间（毫秒）
- 错误信息（如果失败）

**控制台输出示例**：
```
🌐 [Fetch] GET https://api.example.com/data
✅ [Fetch] GET https://api.example.com/data - 200 (234ms)

🌐 [XHR] POST https://api.example.com/submit
✅ [XHR] POST https://api.example.com/submit - 201 (456ms)

🌐 [Fetch] GET https://api.example.com/error
❌ [Fetch] GET https://api.example.com/error - Error (123ms)
```

**查看方式**：

1. **vConsole Network 标签**：
   - 打开 vConsole
   - 点击 "Network" 标签页
   - 查看所有网络请求

2. **编程方式**：
   ```javascript
   const requests = window.MobileDebug.getRequests();
   console.log(requests);
   ```

**清除请求记录**：
```javascript
window.MobileDebug.clearRequests();
```

---

## 🔧 API 参考

### 全局对象

```javascript
window.MobileDebug
```

### 配置对象

```javascript
window.MobileDebug.config = {
  enableVConsole: true,        // 是否启用 vConsole
  enableErrorPanel: true,      // 是否启用错误面板
  enableEnvDetection: true,    // 是否启用环境检测
  enableNetworkMonitor: true,  // 是否启用网络监控
  vConsoleUrl: 'https://unpkg.com/vconsole@latest/dist/vconsole.min.js',
  maxErrors: 10,               // 最多显示的错误数量
}
```

### 方法

#### 1. 清除错误

```javascript
window.MobileDebug.clearErrors();
```

#### 2. 获取环境信息

```javascript
const envInfo = window.MobileDebug.getEnvInfo();
console.log(envInfo);
```

返回值：
```javascript
{
  isMobile: boolean,
  browser: string,
  os: string,
  userAgent: string,
  screenSize: string,
  viewportSize: string,
  devicePixelRatio: number,
  language: string,
  platform: string,
  cookieEnabled: boolean,
  onLine: boolean,
  apiSupport: {
    [apiName: string]: boolean
  }
}
```

#### 3. 获取网络请求记录

```javascript
const requests = window.MobileDebug.getRequests();
console.log(requests);
```

返回值：
```javascript
[
  {
    type: 'fetch' | 'xhr',
    method: string,
    url: string,
    status: number,
    statusText: string,
    duration: number,
    time: Date,
    error?: string
  },
  // ...
]
```

#### 4. 清除网络请求记录

```javascript
window.MobileDebug.clearRequests();
```

#### 5. 访问子模块

```javascript
// 错误面板
window.MobileDebug.errorPanel

// 环境检测
window.MobileDebug.envDetection

// 网络监控
window.MobileDebug.networkMonitor

// vConsole 加载器
window.MobileDebug.vConsoleLoader
```

---

## 📱 使用场景

### 场景1：调试移动端布局问题

1. 在手机浏览器打开网站
2. 点击 vConsole 按钮
3. 切换到 "Element" 标签
4. 查看 DOM 结构和样式

### 场景2：调试 JavaScript 错误

1. 错误会自动显示在页面顶部的错误面板
2. 点击展开查看详细堆栈信息
3. 在 vConsole 的 Console 标签查看完整日志

### 场景3：检查 API 兼容性

1. 打开 vConsole
2. 切换到 "环境" 标签
3. 查看 "API 支持情况" 部分
4. 确认目标 API 是否支持

### 场景4：调试网络请求

1. 打开 vConsole
2. 切换到 "Network" 标签
3. 查看所有请求的状态和响应时间
4. 点击请求查看详细信息

### 场景5：检查浏览器环境

1. 打开 vConsole
2. 切换到 "环境" 标签
3. 查看浏览器类型、操作系统版本等信息
4. 确认是否为目标环境

---

## 🎨 自定义配置

### 修改配置

在 `public/mobile-debug.js` 文件顶部修改 `CONFIG` 对象：

```javascript
const CONFIG = {
  enableVConsole: true,        // 关闭 vConsole: false
  enableErrorPanel: true,      // 关闭错误面板: false
  enableEnvDetection: true,    // 关闭环境检测: false
  enableNetworkMonitor: true,  // 关闭网络监控: false
  vConsoleUrl: 'https://unpkg.com/vconsole@latest/dist/vconsole.min.js',
  maxErrors: 10,               // 修改最大错误数量
};
```

### 修改启用条件

在 `index.html` 中修改 `isDev` 判断条件：

```javascript
const isDev = window.location.hostname === 'localhost' || 
              window.location.hostname === '127.0.0.1' || 
              window.location.hostname.includes('192.168') ||
              window.location.hostname.includes('10.0') ||
              window.location.search.includes('debug=true');
```

例如，只在 localhost 启用：

```javascript
const isDev = window.location.hostname === 'localhost';
```

或者，始终启用：

```javascript
const isDev = true;
```

---

## 🐛 故障排查

### 问题1：vConsole 没有显示

**可能原因**：
- 不是移动端环境
- 不是开发环境
- vConsole CDN 加载失败

**解决方案**：
1. 确认是在移动端浏览器打开
2. 确认 URL 包含 `?debug=true`
3. 检查网络连接
4. 查看控制台是否有加载错误

### 问题2：错误面板没有显示

**可能原因**：
- 没有发生错误
- 错误面板被隐藏

**解决方案**：
1. 触发一个错误测试
2. 刷新页面重新显示
3. 检查 `CONFIG.enableErrorPanel` 是否为 `true`

### 问题3：网络请求没有被监控

**可能原因**：
- 请求在调试工具初始化之前发送
- 使用了其他请求库

**解决方案**：
1. 确保调试脚本在最前面加载
2. 检查 `CONFIG.enableNetworkMonitor` 是否为 `true`
3. 查看 vConsole 的 Network 标签

### 问题4：环境信息不准确

**可能原因**：
- 浏览器 User-Agent 被修改
- 某些 API 在特定环境被禁用

**解决方案**：
1. 查看原始 User-Agent
2. 在真机上测试
3. 检查浏览器设置

---

## 📊 性能影响

### 文件大小
- `mobile-debug.js`: ~15KB (未压缩)
- vConsole CDN: ~200KB (首次加载)

### 性能开销
- 错误捕获: 极小（仅在错误发生时）
- 环境检测: 极小（仅初始化时执行一次）
- 网络监控: 小（每个请求增加 ~1ms）
- vConsole: 中等（增加 ~50-100ms 初始化时间）

### 建议
- ✅ 仅在开发环境启用
- ✅ 生产环境通过 `?debug=true` 按需启用
- ✅ 发布前确认调试代码已禁用

---

## 🔒 安全注意事项

### 1. 不要在生产环境默认启用

调试工具会暴露敏感信息：
- 网络请求 URL 和参数
- 错误堆栈信息
- 环境和设备信息

### 2. 使用条件加载

推荐使用当前的条件加载方式：
```javascript
const isDev = window.location.hostname === 'localhost' || 
              window.location.search.includes('debug=true');
```

### 3. 清理敏感信息

在生产环境使用时，注意清理：
- API 密钥
- 用户数据
- 内部 URL

---

## 📚 相关资源

### vConsole
- 官方文档: https://github.com/Tencent/vConsole
- CDN: https://unpkg.com/vconsole@latest/dist/vconsole.min.js

### 浏览器兼容性
- Can I Use: https://caniuse.com/
- MDN Web Docs: https://developer.mozilla.org/

### 移动端调试
- Chrome Remote Debugging: https://developer.chrome.com/docs/devtools/remote-debugging/
- Safari Web Inspector: https://webkit.org/web-inspector/

---

## 🎯 最佳实践

### 1. 开发阶段
- ✅ 启用所有调试功能
- ✅ 使用真机测试
- ✅ 检查 API 兼容性
- ✅ 监控网络请求

### 2. 测试阶段
- ✅ 在多种设备上测试
- ✅ 测试不同浏览器
- ✅ 检查错误处理
- ✅ 验证性能影响

### 3. 生产阶段
- ✅ 默认禁用调试工具
- ✅ 保留 `?debug=true` 入口
- ✅ 监控错误日志
- ✅ 定期检查兼容性

---

## 💡 提示与技巧

### 技巧1：快速启用调试

在浏览器地址栏输入：
```javascript
javascript:window.location.href=window.location.href+(window.location.search?'&':'?')+'debug=true'
```

### 技巧2：导出环境信息

```javascript
const envInfo = window.MobileDebug.getEnvInfo();
console.log(JSON.stringify(envInfo, null, 2));
// 复制控制台输出，发送给开发者
```

### 技巧3：监控特定请求

```javascript
const requests = window.MobileDebug.getRequests();
const apiRequests = requests.filter(r => r.url.includes('/api/'));
console.table(apiRequests);
```

### 技巧4：自动截图错误

```javascript
window.addEventListener('error', () => {
  // 使用 html2canvas 等库截图
  console.log('错误发生，可以在这里添加截图逻辑');
});
```

---

## 📞 技术支持

如果遇到问题，请提供以下信息：

1. **设备信息**：
   - 手机型号
   - 操作系统版本
   - 浏览器类型和版本

2. **环境信息**：
   ```javascript
   window.MobileDebug.getEnvInfo()
   ```

3. **错误信息**：
   - 控制台截图
   - 错误面板截图
   - 网络请求记录

4. **复现步骤**：
   - 详细的操作步骤
   - 预期结果
   - 实际结果

---

**文档版本**: v1.0  
**最后更新**: 2026-02-06  
**适用项目**: 老年痴呆早期筛查网站  
**调试工具状态**: ✅ 已集成

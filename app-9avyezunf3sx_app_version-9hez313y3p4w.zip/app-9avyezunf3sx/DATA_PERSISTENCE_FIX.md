# 数据保存修复与预筛选页面导航功能说明

## 功能概述

修复"基本信息"页面的数据保存逻辑，将用户信息作为永久档案保存，并在预筛选问卷页面添加返回首页按钮，提升用户体验和数据持久性。

## 问题分析

### 问题1：数据保存不一致
- **现象**：用户提交信息并完成预筛选后，再次进入时信息丢失
- **原因**：原有逻辑将用户信息视为临时数据，提交后清空草稿，导致数据无法持久化
- **影响**：用户需要重复填写基本信息，体验不佳

### 问题2：导航缺失
- **现象**：预筛选问卷页面缺少返回首页的导航
- **原因**：页面只有"上一题"和"下一题"按钮，没有退出入口
- **影响**：用户无法中途退出，必须完成所有问题或关闭页面

## 解决方案

### 一、修复"基本信息"页面数据保存逻辑

#### 1. 数据分层策略

将数据分为三个层级，各司其职：

| 层级 | 键名 | 用途 | 生命周期 |
|------|------|------|----------|
| **永久档案** | `user_profile` | 用户基本信息（性别、年龄区间、省份、城市） | 长期有效，除非用户主动修改 |
| **自动草稿** | `user_info_draft` | 临时自动保存的填写进度 | 提交后清空 |
| **兼容数据** | `user_info` | 兼容旧版本的数据格式 | 与永久档案同步更新 |

#### 2. 修改提交逻辑

**原逻辑**：
```typescript
// 保存到localStorage（正式数据）
localStorage.setItem('user_info', JSON.stringify(dataToSave));
// 清空草稿数据
localStorage.removeItem('user_info_draft');
```

**新逻辑**：
```typescript
// 保存到永久档案（user_profile）
const profileData = {
  ...userInfo,
  lastUpdated: new Date().toISOString()
};
localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profileData));

// 同时保存到user_info（兼容旧版本）
localStorage.setItem(USER_INFO_KEY, JSON.stringify(dataToSave));

// 清空草稿数据（永久档案不清空）
localStorage.removeItem(USER_INFO_DRAFT_KEY);
```

**关键改进**：
- ✅ 新增`user_profile`作为永久档案
- ✅ 提交后不清空永久档案
- ✅ 添加`lastUpdated`时间戳
- ✅ 保持向后兼容性

#### 3. 修改页面加载逻辑

**原逻辑**：
```typescript
// 页面加载时恢复草稿数据
useEffect(() => {
  const draftData = localStorage.getItem('user_info_draft');
  if (draftData) {
    setUserInfo(JSON.parse(draftData));
  }
}, []);
```

**新逻辑**：
```typescript
// 页面加载时恢复数据（优先加载永久档案，其次加载草稿）
useEffect(() => {
  // 优先检查永久档案
  const profileData = localStorage.getItem(USER_PROFILE_KEY);
  if (profileData) {
    setUserInfo(JSON.parse(profileData));
    console.log('已加载永久档案');
    return; // 找到永久档案后直接返回
  }

  // 如果没有永久档案，则尝试加载草稿数据
  const draftData = localStorage.getItem(USER_INFO_DRAFT_KEY);
  if (draftData) {
    setUserInfo(JSON.parse(draftData));
    console.log('已恢复草稿数据');
  }
}, []);
```

**关键改进**：
- ✅ 优先加载永久档案
- ✅ 永久档案不存在时才加载草稿
- ✅ 清晰的加载优先级
- ✅ 控制台日志区分数据来源

#### 4. 数据隔离

**永久档案（user_profile）**：
- 用途：用户基本信息的长期存储
- 更新时机：用户点击"提交并继续"时
- 清空时机：永不自动清空（除非用户主动修改）
- 数据结构：
  ```json
  {
    "gender": "male",
    "ageRange": "60-69",
    "province": "北京市",
    "city": "北京市",
    "lastUpdated": "2026-02-05T10:30:00.000Z"
  }
  ```

**自动草稿（user_info_draft）**：
- 用途：临时自动保存用户填写进度
- 更新时机：每次字段变化时
- 清空时机：用户提交表单后
- 数据结构：
  ```json
  {
    "gender": "male",
    "ageRange": "60-69",
    "province": "",
    "city": ""
  }
  ```

**兼容数据（user_info）**：
- 用途：兼容旧版本代码
- 更新时机：与永久档案同步
- 清空时机：与永久档案同步
- 数据结构：
  ```json
  {
    "gender": "male",
    "ageRange": "60-69",
    "province": "北京市",
    "city": "北京市",
    "filledDate": "2026-02-05T10:30:00.000Z"
  }
  ```

#### 5. 页面状态转换

**首次访问**：
- localStorage中无任何数据
- 表单为空
- 页面状态：新建档案

**填写中途离开**：
- localStorage中有`user_info_draft`
- 再次进入时自动恢复草稿
- 页面状态：继续填写

**提交后再次访问**：
- localStorage中有`user_profile`
- 自动填充所有字段
- 页面状态：查看/编辑个人资料

**修改档案**：
- 用户可以修改任何字段
- 点击"提交并继续"更新永久档案
- `lastUpdated`时间戳更新

### 二、在"预筛选问卷"页面增加"返回首页"按钮

#### 1. 按钮位置
- 位于导航按钮区域的下方
- 在"上一题"/"下一题"按钮之后
- 独立成行，全宽显示

#### 2. 按钮样式
- **变体**：outline（次要按钮样式）
- **宽度**：w-full（全宽）
- **高度**：py-5（适中高度）
- **字号**：text-base
- **图标**：Home（房子图标，5x5）
- **文字**："返回首页"
- **间距**：gap-2

#### 3. 按钮功能
- 点击后跳转到网站首页（路径：/）
- 使用React Router的navigate函数
- 不影响答题进度（答题数据已自动保存）

#### 4. 视觉区分
- 使用outline样式，与主要的"下一题"按钮有所区分
- 独立成行，避免与答题按钮混淆
- 清晰可辨，易于点击

#### 5. 布局调整
- 原导航按钮区域：`<div className="flex items-center justify-between gap-4">`
- 新布局结构：
  ```tsx
  <div className="space-y-3">
    {/* 原有的上一题/下一题按钮 */}
    <div className="flex items-center justify-between gap-4">
      {/* 上一题按钮 */}
      {/* 下一题/完成预筛按钮 */}
    </div>
    
    {/* 返回首页按钮 */}
    <Button variant="outline" onClick={() => navigate('/')}>
      返回首页
    </Button>
  </div>
  ```

## 技术实现

### 文件修改
1. `src/pages/UserInfoPage.tsx` - 基本信息页面
2. `src/pages/PreScreeningQuestionPage.tsx` - 预筛选问卷页面

### 核心代码

#### 1. localStorage键名常量（UserInfoPage.tsx）
```typescript
// localStorage键名
const USER_PROFILE_KEY = 'user_profile'; // 永久档案（用户基本信息）
const USER_INFO_DRAFT_KEY = 'user_info_draft'; // 草稿数据（临时自动保存）
const USER_INFO_KEY = 'user_info'; // 正式数据（兼容旧版本）
```

#### 2. 页面加载时恢复数据（UserInfoPage.tsx）
```typescript
// 页面加载时恢复数据（优先加载永久档案，其次加载草稿）
useEffect(() => {
  try {
    // 优先检查永久档案
    const profileData = localStorage.getItem(USER_PROFILE_KEY);
    if (profileData) {
      const parsed = JSON.parse(profileData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已加载永久档案:', parsed);
      return; // 找到永久档案后直接返回
    }

    // 如果没有永久档案，则尝试加载草稿数据
    const draftData = localStorage.getItem(USER_INFO_DRAFT_KEY);
    if (draftData) {
      const parsed = JSON.parse(draftData) as UserBasicInfo;
      setUserInfo(parsed);
      console.log('已恢复草稿数据:', parsed);
    }
  } catch (error) {
    console.error('恢复数据失败:', error);
  }
}, []);
```

#### 3. 提交表单（UserInfoPage.tsx）
```typescript
const handleSubmit = () => {
  // ... 验证逻辑 ...

  // 保存到永久档案（user_profile）
  const profileData = {
    ...userInfo,
    lastUpdated: new Date().toISOString()
  };
  localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profileData));
  console.log('用户档案已保存:', profileData);

  // 同时保存到user_info（兼容旧版本）
  const dataToSave = {
    ...userInfo,
    filledDate: new Date().toISOString()
  };
  localStorage.setItem(USER_INFO_KEY, JSON.stringify(dataToSave));

  // 清空草稿数据（永久档案不清空）
  localStorage.removeItem(USER_INFO_DRAFT_KEY);
  console.log('草稿数据已清空');

  // 跳转到预筛选页面
  navigate('/pre-screening/1');
};
```

#### 4. 导入Home图标（PreScreeningQuestionPage.tsx）
```typescript
import { ArrowLeft, ArrowRight, CheckCircle, Volume2, Home } from 'lucide-react';
```

#### 5. 添加返回首页按钮（PreScreeningQuestionPage.tsx）
```typescript
{/* 导航按钮 */}
<div className="space-y-3">
  <div className="flex items-center justify-between gap-4">
    {/* 上一题按钮 */}
    {/* 下一题/完成预筛按钮 */}
  </div>

  {/* 返回首页按钮 */}
  <Button
    type="button"
    variant="outline"
    onClick={() => navigate('/')}
    className="w-full gap-2 text-base py-5"
  >
    <Home className="h-5 w-5" />
    返回首页
  </Button>
</div>
```

## 用户使用流程

### 场景1：首次填写信息
1. 用户进入基本信息页面（表单为空）
2. 填写性别、年龄区间、省份、城市（每次变化自动保存草稿）
3. 点击"提交并继续"
4. 保存到永久档案（user_profile）
5. 清空草稿数据（user_info_draft）
6. 跳转到预筛选页面

### 场景2：中途离开后返回
1. 用户填写部分信息（自动保存草稿）
2. 关闭页面或浏览器
3. 再次进入基本信息页面
4. 自动恢复草稿数据（因为没有永久档案）
5. 继续填写并提交
6. 保存到永久档案

### 场景3：提交后再次访问
1. 用户已提交过信息（永久档案存在）
2. 再次进入基本信息页面
3. **自动加载永久档案，所有字段自动填充**
4. 页面状态：查看/编辑个人资料
5. 用户可以修改任何字段
6. 点击"提交并继续"更新永久档案

### 场景4：预筛选中途退出
1. 用户在预筛选问卷页面答题
2. 点击"返回首页"按钮
3. 跳转到首页
4. 答题进度已自动保存（通过ScreeningContext）
5. 用户可以稍后返回继续答题

## 数据流转图

```
首次访问
  ↓
填写信息 → 自动保存草稿(user_info_draft)
  ↓
提交表单
  ↓
保存永久档案(user_profile) + 兼容数据(user_info)
  ↓
清空草稿(user_info_draft)
  ↓
跳转预筛选
  ↓
再次访问基本信息页面
  ↓
加载永久档案(user_profile) → 自动填充表单
  ↓
修改信息 → 自动保存草稿(user_info_draft)
  ↓
提交表单 → 更新永久档案(user_profile)
```

## 注意事项

### 1. 数据优先级
- 永久档案 > 自动草稿
- 页面加载时优先检查永久档案
- 永久档案存在时不加载草稿

### 2. 数据隔离
- 三个localStorage键名各司其职
- 互不干扰，避免冲突
- 清晰的数据生命周期

### 3. 向后兼容
- 保留`user_info`键名
- 与永久档案同步更新
- 兼容旧版本代码

### 4. 错误处理
- 所有localStorage操作包含try-catch
- 失败时输出错误日志
- 不影响页面正常使用

### 5. 预筛选页面导航
- 返回首页按钮不影响答题逻辑
- 答题进度已通过ScreeningContext自动保存
- 用户可以随时退出和返回

### 6. 时间戳
- 永久档案包含`lastUpdated`时间戳
- 兼容数据包含`filledDate`时间戳
- 便于追踪数据更新时间

## 测试建议

### 功能测试

#### 基本信息页面
1. **首次填写测试**：
   - 清空localStorage
   - 填写完整信息并提交
   - 检查localStorage中是否有user_profile
   - 检查user_info_draft是否已清空

2. **永久档案加载测试**：
   - 提交信息后
   - 刷新页面或重新进入
   - 检查表单是否自动填充
   - 检查控制台日志："已加载永久档案"

3. **档案修改测试**：
   - 加载永久档案后
   - 修改任何字段
   - 提交表单
   - 检查永久档案是否更新
   - 检查lastUpdated时间戳是否更新

4. **草稿优先级测试**：
   - 同时存在user_profile和user_info_draft
   - 刷新页面
   - 检查是否加载user_profile（优先级更高）

5. **向后兼容测试**：
   - 检查user_info是否与user_profile同步
   - 检查旧版本代码是否正常工作

#### 预筛选问卷页面
1. **返回首页按钮测试**：
   - 进入预筛选问卷页面
   - 点击"返回首页"按钮
   - 检查是否跳转到首页

2. **答题进度保存测试**：
   - 答几道题
   - 点击"返回首页"
   - 再次进入预筛选页面
   - 检查答题进度是否保留

3. **按钮样式测试**：
   - 检查返回首页按钮是否使用outline样式
   - 检查是否与答题按钮有视觉区分
   - 检查移动端显示是否正常

### 边界测试
1. localStorage不可用时的行为
2. 永久档案数据格式错误时的处理
3. 同时打开多个标签页
4. 快速连续提交表单

### 用户体验测试
1. 永久档案加载是否及时
2. 数据恢复是否准确
3. 返回首页按钮是否易于找到
4. 按钮样式是否清晰区分
5. 移动端适配是否良好

## 控制台日志

### 正常流程日志

#### 首次填写
```
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: ""}
草稿已自动保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市"}
用户档案已保存: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
草稿数据已清空
```

#### 再次访问
```
已加载永久档案: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
```

#### 修改档案
```
已加载永久档案: {gender: "male", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T10:30:00.000Z"}
草稿已自动保存: {gender: "female", ageRange: "60-69", province: "北京市", city: "北京市"}
用户档案已保存: {gender: "female", ageRange: "60-69", province: "北京市", city: "北京市", lastUpdated: "2026-02-05T11:00:00.000Z"}
草稿数据已清空
```

### 错误日志
```
恢复数据失败: SyntaxError: Unexpected token...
```

## 总结

数据保存修复与预筛选页面导航功能已完整实现，包括：
- ✅ 永久档案（user_profile）作为用户基本信息的长期存储
- ✅ 页面加载时优先加载永久档案
- ✅ 提交后不清空永久档案，实现数据持久化
- ✅ 数据分层策略（永久档案、自动草稿、兼容数据）
- ✅ 清晰的数据优先级和生命周期
- ✅ 向后兼容性（保留user_info键名）
- ✅ 预筛选问卷页面添加返回首页按钮
- ✅ 返回首页按钮使用outline样式，视觉区分明确
- ✅ 不影响答题逻辑和进度保存
- ✅ 完善的错误处理和控制台日志

用户可以在提交信息后再次访问时自动加载永久档案，无需重复填写。预筛选问卷页面提供了便捷的返回首页功能，用户可以随时退出和返回，答题进度自动保存。整体用户体验得到显著提升。

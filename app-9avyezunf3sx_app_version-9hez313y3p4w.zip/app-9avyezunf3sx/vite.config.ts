import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';
import path from 'path';

import { miaodaDevPlugin } from "miaoda-sc-plugin";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), svgr({
      svgrOptions: {
        icon: true, exportType: 'named', namedExport: 'ReactComponent', }, }), miaodaDevPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
    dedupe: ['react', 'react-dom'],
  },
  optimizeDeps: {
    include: ['react', 'react-dom', 'react-router-dom'],
  },
  build: {
    target: 'es2015', // 确保移动端兼容性
    cssTarget: 'chrome61', // 支持较旧的移动浏览器
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: false, // 保留console以便调试
      },
    },
  },
  server: {
    host: '0.0.0.0', // 【核心配置】允许局域网访问，手机可通过电脑IP访问
    port: 5173, // 开发服务器端口（Vite默认端口）
    strictPort: true, // 确保端口固定，如果端口被占用则报错而不是自动切换
    open: false, // 不自动打开浏览器
  },
});

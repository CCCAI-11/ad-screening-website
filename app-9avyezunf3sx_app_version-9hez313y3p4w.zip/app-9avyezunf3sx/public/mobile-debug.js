/**
 * 移动端调试工具
 * 功能：
 * 1. 自动检测移动端环境并加载 vConsole
 * 2. 错误捕获与显示面板
 * 3. 环境检测（浏览器类型、JS API 支持情况）
 * 4. 网络请求监控
 */

(function() {
  'use strict';

  // ==================== 配置 ====================
  const CONFIG = {
    enableVConsole: true,        // 是否启用 vConsole
    enableErrorPanel: true,      // 是否启用错误面板
    enableEnvDetection: true,    // 是否启用环境检测
    enableNetworkMonitor: true,  // 是否启用网络监控
    vConsoleUrl: 'https://unpkg.com/vconsole@latest/dist/vconsole.min.js',
    maxErrors: 10,               // 最多显示的错误数量
  };

  // ==================== 工具函数 ====================
  
  /**
   * 检测是否为移动端
   */
  function isMobile() {
    const ua = navigator.userAgent;
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
  }

  /**
   * 检测浏览器类型
   */
  function detectBrowser() {
    const ua = navigator.userAgent;
    
    if (ua.indexOf('MicroMessenger') > -1) {
      return '微信浏览器';
    } else if (ua.indexOf('QQ') > -1 && ua.indexOf('MQQBrowser') > -1) {
      return 'QQ浏览器';
    } else if (ua.indexOf('UCBrowser') > -1) {
      return 'UC浏览器';
    } else if (ua.indexOf('Quark') > -1) {
      return '夸克浏览器';
    } else if (ua.indexOf('Huawei') > -1) {
      return '华为浏览器';
    } else if (ua.indexOf('MiuiBrowser') > -1) {
      return '小米浏览器';
    } else if (ua.indexOf('OppoBrowser') > -1) {
      return 'OPPO浏览器';
    } else if (ua.indexOf('VivoBrowser') > -1) {
      return 'vivo浏览器';
    } else if (ua.indexOf('Safari') > -1 && ua.indexOf('Chrome') === -1) {
      return 'Safari';
    } else if (ua.indexOf('Chrome') > -1) {
      return 'Chrome';
    } else if (ua.indexOf('Firefox') > -1) {
      return 'Firefox';
    }
    return '未知浏览器';
  }

  /**
   * 检测操作系统
   */
  function detectOS() {
    const ua = navigator.userAgent;
    
    if (/iPhone|iPad|iPod/i.test(ua)) {
      const match = ua.match(/OS (\d+)_(\d+)_?(\d+)?/);
      if (match) {
        return `iOS ${match[1]}.${match[2]}${match[3] ? '.' + match[3] : ''}`;
      }
      return 'iOS';
    } else if (/Android/i.test(ua)) {
      const match = ua.match(/Android (\d+\.?\d*)/);
      if (match) {
        return `Android ${match[1]}`;
      }
      return 'Android';
    }
    return '未知系统';
  }

  /**
   * 检测 JavaScript API 支持情况
   */
  function detectAPISupport() {
    const apis = {
      'Promise': typeof Promise !== 'undefined',
      'fetch': typeof fetch !== 'undefined',
      'localStorage': (function() {
        try {
          return typeof localStorage !== 'undefined' && localStorage !== null;
        } catch (e) {
          return false;
        }
      })(),
      'sessionStorage': (function() {
        try {
          return typeof sessionStorage !== 'undefined' && sessionStorage !== null;
        } catch (e) {
          return false;
        }
      })(),
      'IndexedDB': typeof indexedDB !== 'undefined',
      'WebSocket': typeof WebSocket !== 'undefined',
      'Geolocation': 'geolocation' in navigator,
      'ServiceWorker': 'serviceWorker' in navigator,
      'WebWorker': typeof Worker !== 'undefined',
      'WebRTC': typeof RTCPeerConnection !== 'undefined',
      'WebGL': (function() {
        try {
          const canvas = document.createElement('canvas');
          return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
        } catch (e) {
          return false;
        }
      })(),
      'SpeechSynthesis': 'speechSynthesis' in window,
      'SpeechRecognition': 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window,
      'Notification': 'Notification' in window,
      'Vibration': 'vibrate' in navigator,
      'Battery': 'getBattery' in navigator,
      'DeviceOrientation': 'DeviceOrientationEvent' in window,
      'DeviceMotion': 'DeviceMotionEvent' in window,
      'TouchEvents': 'ontouchstart' in window,
      'PointerEvents': 'PointerEvent' in window,
      'IntersectionObserver': 'IntersectionObserver' in window,
      'MutationObserver': 'MutationObserver' in window,
      'ResizeObserver': 'ResizeObserver' in window,
      'PerformanceObserver': 'PerformanceObserver' in window,
    };

    return apis;
  }

  /**
   * 格式化时间
   */
  function formatTime(date) {
    const pad = (n) => n < 10 ? '0' + n : n;
    return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${date.getMilliseconds()}`;
  }

  // ==================== 错误面板 ====================
  
  const ErrorPanel = {
    errors: [],
    panel: null,
    
    init() {
      if (!CONFIG.enableErrorPanel) return;
      
      this.createPanel();
      this.captureErrors();
      console.log('✅ 错误面板已初始化');
    },
    
    createPanel() {
      // 创建面板容器
      this.panel = document.createElement('div');
      this.panel.id = 'mobile-debug-error-panel';
      this.panel.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        max-height: 200px;
        overflow-y: auto;
        background: rgba(220, 38, 38, 0.95);
        color: white;
        font-size: 12px;
        font-family: monospace;
        z-index: 999999;
        padding: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        display: none;
      `;
      
      // 添加到页面
      if (document.body) {
        document.body.appendChild(this.panel);
      } else {
        document.addEventListener('DOMContentLoaded', () => {
          document.body.appendChild(this.panel);
        });
      }
    },
    
    captureErrors() {
      // 捕获全局错误
      window.addEventListener('error', (event) => {
        this.addError({
          type: 'Error',
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          stack: event.error ? event.error.stack : '',
          time: new Date(),
        });
      });
      
      // 捕获 Promise 错误
      window.addEventListener('unhandledrejection', (event) => {
        this.addError({
          type: 'Promise Rejection',
          message: event.reason ? event.reason.message || event.reason : 'Unknown error',
          stack: event.reason ? event.reason.stack : '',
          time: new Date(),
        });
      });
      
      // 捕获 console.error
      const originalError = console.error;
      console.error = (...args) => {
        this.addError({
          type: 'Console Error',
          message: args.map(arg => 
            typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
          ).join(' '),
          time: new Date(),
        });
        originalError.apply(console, args);
      };
    },
    
    addError(error) {
      this.errors.push(error);
      
      // 限制错误数量
      if (this.errors.length > CONFIG.maxErrors) {
        this.errors.shift();
      }
      
      this.render();
    },
    
    render() {
      if (!this.panel) return;
      
      if (this.errors.length === 0) {
        this.panel.style.display = 'none';
        return;
      }
      
      this.panel.style.display = 'block';
      
      const html = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.3); padding-bottom: 5px;">
          <strong>🐛 错误面板 (${this.errors.length})</strong>
          <button onclick="document.getElementById('mobile-debug-error-panel').style.display='none'" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 2px 8px; border-radius: 3px; cursor: pointer;">隐藏</button>
        </div>
        ${this.errors.map((error, index) => `
          <div style="margin-bottom: 10px; padding: 8px; background: rgba(0,0,0,0.2); border-radius: 4px; border-left: 3px solid #fff;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <strong style="color: #fef08a;">${error.type}</strong>
              <span style="color: #d1d5db; font-size: 10px;">${formatTime(error.time)}</span>
            </div>
            <div style="color: #fecaca; margin-bottom: 5px;">${this.escapeHtml(error.message)}</div>
            ${error.filename ? `<div style="color: #d1d5db; font-size: 10px;">📄 ${error.filename}:${error.lineno}:${error.colno}</div>` : ''}
            ${error.stack ? `<details style="margin-top: 5px;"><summary style="cursor: pointer; color: #d1d5db;">堆栈信息</summary><pre style="margin: 5px 0 0 0; font-size: 10px; color: #e5e7eb; overflow-x: auto;">${this.escapeHtml(error.stack)}</pre></details>` : ''}
          </div>
        `).join('')}
      `;
      
      this.panel.innerHTML = html;
    },
    
    escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    },
    
    clear() {
      this.errors = [];
      this.render();
    }
  };

  // ==================== 环境检测 ====================
  
  const EnvDetection = {
    info: null,
    
    init() {
      if (!CONFIG.enableEnvDetection) return;
      
      this.info = {
        isMobile: isMobile(),
        browser: detectBrowser(),
        os: detectOS(),
        userAgent: navigator.userAgent,
        screenSize: `${window.screen.width}x${window.screen.height}`,
        viewportSize: `${window.innerWidth}x${window.innerHeight}`,
        devicePixelRatio: window.devicePixelRatio || 1,
        language: navigator.language,
        platform: navigator.platform,
        cookieEnabled: navigator.cookieEnabled,
        onLine: navigator.onLine,
        apiSupport: detectAPISupport(),
      };
      
      this.logInfo();
      console.log('✅ 环境检测已完成');
    },
    
    logInfo() {
      console.group('📱 环境信息');
      console.log('移动端:', this.info.isMobile ? '是' : '否');
      console.log('浏览器:', this.info.browser);
      console.log('操作系统:', this.info.os);
      console.log('屏幕尺寸:', this.info.screenSize);
      console.log('视口尺寸:', this.info.viewportSize);
      console.log('设备像素比:', this.info.devicePixelRatio);
      console.log('语言:', this.info.language);
      console.log('平台:', this.info.platform);
      console.log('Cookie启用:', this.info.cookieEnabled ? '是' : '否');
      console.log('在线状态:', this.info.onLine ? '在线' : '离线');
      console.groupEnd();
      
      console.group('🔧 API 支持情况');
      const supported = [];
      const unsupported = [];
      
      for (const [api, isSupported] of Object.entries(this.info.apiSupport)) {
        if (isSupported) {
          supported.push(api);
        } else {
          unsupported.push(api);
        }
      }
      
      console.log(`✅ 支持 (${supported.length}):`, supported.join(', '));
      console.log(`❌ 不支持 (${unsupported.length}):`, unsupported.join(', '));
      console.groupEnd();
    },
    
    getInfo() {
      return this.info;
    }
  };

  // ==================== 网络请求监控 ====================
  
  const NetworkMonitor = {
    requests: [],
    
    init() {
      if (!CONFIG.enableNetworkMonitor) return;
      
      this.monitorFetch();
      this.monitorXHR();
      console.log('✅ 网络请求监控已启动');
    },
    
    monitorFetch() {
      if (typeof fetch === 'undefined') return;
      
      const originalFetch = window.fetch;
      window.fetch = async (...args) => {
        const startTime = Date.now();
        const url = typeof args[0] === 'string' ? args[0] : args[0].url;
        const method = args[1]?.method || 'GET';
        
        console.log(`🌐 [Fetch] ${method} ${url}`);
        
        try {
          const response = await originalFetch(...args);
          const duration = Date.now() - startTime;
          
          console.log(`✅ [Fetch] ${method} ${url} - ${response.status} (${duration}ms)`);
          
          this.addRequest({
            type: 'fetch',
            method,
            url,
            status: response.status,
            statusText: response.statusText,
            duration,
            time: new Date(),
          });
          
          return response;
        } catch (error) {
          const duration = Date.now() - startTime;
          
          console.error(`❌ [Fetch] ${method} ${url} - Error (${duration}ms)`, error);
          
          this.addRequest({
            type: 'fetch',
            method,
            url,
            status: 0,
            statusText: 'Error',
            error: error.message,
            duration,
            time: new Date(),
          });
          
          throw error;
        }
      };
    },
    
    monitorXHR() {
      const originalOpen = XMLHttpRequest.prototype.open;
      const originalSend = XMLHttpRequest.prototype.send;
      
      XMLHttpRequest.prototype.open = function(method, url, ...args) {
        this._debugInfo = {
          method,
          url,
          startTime: Date.now(),
        };
        
        console.log(`🌐 [XHR] ${method} ${url}`);
        
        return originalOpen.call(this, method, url, ...args);
      };
      
      XMLHttpRequest.prototype.send = function(...args) {
        const xhr = this;
        
        xhr.addEventListener('load', function() {
          if (!xhr._debugInfo) return;
          
          const duration = Date.now() - xhr._debugInfo.startTime;
          
          console.log(`✅ [XHR] ${xhr._debugInfo.method} ${xhr._debugInfo.url} - ${xhr.status} (${duration}ms)`);
          
          NetworkMonitor.addRequest({
            type: 'xhr',
            method: xhr._debugInfo.method,
            url: xhr._debugInfo.url,
            status: xhr.status,
            statusText: xhr.statusText,
            duration,
            time: new Date(),
          });
        });
        
        xhr.addEventListener('error', function() {
          if (!xhr._debugInfo) return;
          
          const duration = Date.now() - xhr._debugInfo.startTime;
          
          console.error(`❌ [XHR] ${xhr._debugInfo.method} ${xhr._debugInfo.url} - Error (${duration}ms)`);
          
          NetworkMonitor.addRequest({
            type: 'xhr',
            method: xhr._debugInfo.method,
            url: xhr._debugInfo.url,
            status: 0,
            statusText: 'Error',
            error: 'Network Error',
            duration,
            time: new Date(),
          });
        });
        
        return originalSend.apply(this, args);
      };
    },
    
    addRequest(request) {
      this.requests.push(request);
      
      // 限制请求数量
      if (this.requests.length > 100) {
        this.requests.shift();
      }
    },
    
    getRequests() {
      return this.requests;
    },
    
    clear() {
      this.requests = [];
    }
  };

  // ==================== vConsole 加载 ====================
  
  const VConsoleLoader = {
    loaded: false,
    
    init() {
      if (!CONFIG.enableVConsole) return;
      if (!isMobile()) {
        console.log('⚠️ 非移动端环境，跳过 vConsole 加载');
        return;
      }
      
      this.load();
    },
    
    load() {
      console.log('📦 正在加载 vConsole...');
      
      const script = document.createElement('script');
      script.src = CONFIG.vConsoleUrl;
      script.onload = () => {
        if (typeof window.VConsole !== 'undefined') {
          const vConsole = new window.VConsole({
            defaultPlugins: ['system', 'network', 'element', 'storage'],
            maxLogNumber: 1000,
          });
          
          this.loaded = true;
          console.log('✅ vConsole 加载成功');
          
          // 添加自定义插件：环境信息
          if (CONFIG.enableEnvDetection && EnvDetection.info) {
            this.addEnvPlugin(vConsole);
          }
        }
      };
      script.onerror = () => {
        console.error('❌ vConsole 加载失败');
      };
      
      document.head.appendChild(script);
    },
    
    addEnvPlugin(vConsole) {
      const envPlugin = new window.VConsole.VConsolePlugin('env', '环境');
      
      envPlugin.on('renderTab', (callback) => {
        const info = EnvDetection.info;
        
        let html = '<div style="padding: 10px; font-size: 12px;">';
        
        // 基本信息
        html += '<h3 style="margin: 10px 0; color: #07c160;">基本信息</h3>';
        html += `<p><strong>移动端:</strong> ${info.isMobile ? '是' : '否'}</p>`;
        html += `<p><strong>浏览器:</strong> ${info.browser}</p>`;
        html += `<p><strong>操作系统:</strong> ${info.os}</p>`;
        html += `<p><strong>屏幕尺寸:</strong> ${info.screenSize}</p>`;
        html += `<p><strong>视口尺寸:</strong> ${info.viewportSize}</p>`;
        html += `<p><strong>设备像素比:</strong> ${info.devicePixelRatio}</p>`;
        html += `<p><strong>语言:</strong> ${info.language}</p>`;
        html += `<p><strong>在线状态:</strong> ${info.onLine ? '在线' : '离线'}</p>`;
        
        // API 支持情况
        html += '<h3 style="margin: 20px 0 10px 0; color: #07c160;">API 支持情况</h3>';
        
        const supported = [];
        const unsupported = [];
        
        for (const [api, isSupported] of Object.entries(info.apiSupport)) {
          if (isSupported) {
            supported.push(api);
          } else {
            unsupported.push(api);
          }
        }
        
        html += `<p style="color: #07c160;"><strong>✅ 支持 (${supported.length}):</strong></p>`;
        html += `<p style="font-size: 11px; color: #666;">${supported.join(', ')}</p>`;
        
        html += `<p style="color: #fa5151; margin-top: 10px;"><strong>❌ 不支持 (${unsupported.length}):</strong></p>`;
        html += `<p style="font-size: 11px; color: #666;">${unsupported.join(', ')}</p>`;
        
        html += '</div>';
        
        callback(html);
      });
      
      vConsole.addPlugin(envPlugin);
    }
  };

  // ==================== 主初始化 ====================
  
  function init() {
    console.log('🚀 移动端调试工具初始化中...');
    console.log('配置:', CONFIG);
    
    // 初始化各个模块
    ErrorPanel.init();
    EnvDetection.init();
    NetworkMonitor.init();
    VConsoleLoader.init();
    
    // 暴露全局接口
    window.MobileDebug = {
      config: CONFIG,
      errorPanel: ErrorPanel,
      envDetection: EnvDetection,
      networkMonitor: NetworkMonitor,
      vConsoleLoader: VConsoleLoader,
      
      // 便捷方法
      clearErrors: () => ErrorPanel.clear(),
      getEnvInfo: () => EnvDetection.getInfo(),
      getRequests: () => NetworkMonitor.getRequests(),
      clearRequests: () => NetworkMonitor.clear(),
    };
    
    console.log('✅ 移动端调试工具初始化完成');
    console.log('💡 使用 window.MobileDebug 访问调试工具');
  }

  // 等待 DOM 加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
